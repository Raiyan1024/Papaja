# Your Tailoring House — store

A multi-page made-to-measure shop: catalogue by line (suits, blazers, trousers, shirts), colour ×
design variants with their own prices, a checkout that takes a cloth choice and a "let's discuss it"
brief, two payment options (৳150 non-refundable visit advance, or the full amount), customer
accounts with saved measurements, and an admin panel for orders, prices and fabric stock.

Next.js 15 (App Router, JavaScript) · Postgres · deployed on Antideploy · money by bKash/Nagad Send Money
(with a built-in mock mode so it runs before your merchant account is live).

---

## What's in it

**Shop**

| Page | What it does |
|------|--------------|
| `/` | Home: the four lines, featured pieces, cloth on the shelf, the 40% fit promise, the two payment options |
| `/suits` `/blazers` `/trousers` `/shirts` | One page per line, every style with its colour swatches and "from" price |
| `/product/[slug]` | Colour chips, design options with their own price and cloth, a brief box, quantity, add to order |
| `/cart` | Lines, quantities, removal, subtotal — prices re-read from the database on every render |
| `/order` | Checkout: contact, cloth choice, "combine a design with any colour" brief, **request a discussion**, how to get the size, payment option, live totals |
| `/pay/[tranId]` | The mock gateway (only exists while `PAYMENTS_MODE=mock`) |
| `/order/[code]` | Confirmation: what happens next, payment state, pay-now if unpaid |

**Accounts** — `/account`: register or sign in, save eight measurements and notes, keep your details,
see past orders. Guests can order without an account.

**Admin** — `/admin` (shop owner only)

- **Overview** — orders, order value, outstanding money, fabric at or below its reorder level,
  latest orders, recent stock movements
- **Orders** — filter by status, open one to see the pieces, the cloth asked for, the discussion
  topic, the measurements, the payment attempts; move the status along; mark paid or refunded
  (for money that arrives outside the gateway)
- **Products & prices** — edit copy, and per colour × design row: price, stock, visibility
- **Fabric stock** — price per yard, yards on the shelf, reorder level, quick ± adjustment with a
  reason, and a running log of every movement
- **Customers** — accounts, orders, value, measurements on file

**Data model** (`sql/schema.sql`): `users`, `measurements`, `categories`, `fabrics`, `products`,
`product_variants` (the colour × design price/stock row), `orders`, `order_items`, `payments`,
`stock_movements`, `settings`.

---

## Run it locally

```bash
cd storefront
cp .env.example .env.local        # fill in DATABASE_URL and SESSION_SECRET
npm install
npm run db:setup                  # creates the schema and seeds 13 products, 11 fabrics, an admin
npm run dev                       # http://localhost:3000
```

`npm run db:setup -- --reset` wipes and reseeds (dev only). The seed prints the admin login —
by default `admin@tailoring.local` / `ChangeMe123!`. **Change it before launch.**

Any Postgres works locally (Docker one-liner):

```bash
docker run --name tailoring-db -e POSTGRES_PASSWORD=tailor -e POSTGRES_USER=tailor \
  -e POSTGRES_DB=tailoring -p 5432:5432 -d postgres:17
# DATABASE_URL="postgresql://tailor:tailor@127.0.0.1:5432/tailoring"
```

---

## Deploy on Vercel

1. **Database** — create a free Postgres at [Neon](https://neon.tech) (or Vercel Postgres /
   Supabase). Copy the **pooled** connection string; it ends with `?sslmode=require`.
2. **Push the repo** to GitHub and import it in Vercel. If the app lives in a subfolder, set
   **Root Directory** to `storefront`.
3. **Environment variables** (Project → Settings → Environment Variables):

   | Key | Value |
   |-----|-------|
   | `DATABASE_URL` | the pooled Postgres URL |
   | `SESSION_SECRET` | `openssl rand -base64 48` |
   | `NEXT_PUBLIC_SITE_URL` | `https://your-domain.com` (no trailing slash) |
   | `PAYMENTS_MODE` | `manual` — bKash/Nagad Send Money, released in `/admin` |
   | `NEXT_PUBLIC_BKASH_NUMBER`, `NEXT_PUBLIC_NAGAD_NUMBER` | where the money is sent |
   | `NEXT_PUBLIC_VISIT_FEE`, `NEXT_PUBLIC_VISIT_FEE_OUTSIDE` | `150` and `400` |
   | `REFUND_RATE` | `0.60` |

4. **Create the tables once**, from your machine against the Neon URL:

   ```bash
   DATABASE_URL="postgresql://…neon.tech/neondb?sslmode=require" npm run db:setup
   ```

   Then sign in at `/admin/login` with the seeded admin and rotate the password:
   `npm run admin:pass 'a-long-new-password'`.

---

## Payments

Money is bKash / Nagad Send Money with the TrxID checked by the shop. The full flow — who types
what, what the admin sees, and why a pasted TrxID is never treated as money — is in
*How money is taken* above and in `DEPLOY.md`.

**The two payment options at checkout**

- **৳150 visit advance** — offered when the customer asks for a home visit. Non-refundable, and the
  copy says so. It pays for the visit, not the garment.
- **Full payment now** — the whole order total through the gateway.

The advance cannot be selected without choosing a home visit (enforced server-side, not just in the UI).

---

## Where the money numbers live

Every price is read from `product_variants.price` at render time and re-read again when the order is
created — the form can never send a price the shop didn't set. Changing a price in the admin panel
changes the shop immediately; there is no rebuild step.

`NEXT_PUBLIC_VISIT_FEE` is the single source for the ৳150 visit advance, and the seeded `settings`
row keeps a copy for the admin side.

---

## Notes and limits

- **No delivery calculation, no VAT/tax line, no invoice PDF** — the totals are pieces + visit fee.
  If you need tax or delivery, add it in `lib/orders.js` (`createOrder`) and the checkout summary.
- **Stock is decremented per variant on order.** Fabric yards are *not* auto-deducted from a cut —
  the tailor takes them out from the admin fabric page with a reason, which is logged. If you want
  automatic deduction, add a "yards per piece" column to `products` and subtract it in `createOrder`.
- **Guest orders** are supported (the order keeps the contact details); they do not appear in an
  account until that person registers with the same email.
- **The phone number and the address are still placeholders.** `NEXT_PUBLIC_PHONE` and
  `NEXT_PUBLIC_SHOP_ADDRESS` drive every WhatsApp button, every call link and the footer — set the two
  real values on Antideploy and redeploy, and the whole site follows. Everything else (name, photographs,
  prices, cloth) is real content now.
- The original one-page site is still in the parent folder (`index.html`); this app supersedes it.

---

## How money is taken — bKash and Nagad, no gateway at all

There is no payment gateway in this project, no merchant account, no API key and no percentage
taken from a sale. There is also no free bKash *API* in Bangladesh: bKash's Payment/Checkout API,
and every card gateway, need an approved merchant account with a trade licence. What is free is
Send Money — so that is the flow:

1. At checkout the customer picks **bKash**, **Nagad** or **card**.
2. bKash/Nagad: `/pay/<tran>` shows the shop's number, the exact amount and the order code as the
   reference, with the three steps and the TrxID box.
3. Pasting a TrxID marks the payment **`submitted`**, never paid. The order page says
   "We are checking your payment" and nothing is cut.
4. Admin → **Payments to check** on the dashboard lists every claim with the TrxID, amount and
   phone. One look at the bKash/Nagad statement, then *Money is in — release*: `amount_paid`
   accumulates, `amount_due` falls, an advance order becomes `partial` and the balance stays
   visible. *Does not match* records the reason and lets the customer try again.
5. A TrxID is unique across the table, so one screenshot cannot release two orders.
6. Card: the order is saved and the customer is told we call with a secure link — honest, rather
   than a button that fails.

`PAYMENTS_MODE=mock` exists for tests only; in production it is ignored unless
`ALLOW_MOCK_PAYMENTS=true`, so a stray console value cannot walk a customer through a "payment"
that moves no money. Set the receiving numbers with `NEXT_PUBLIC_BKASH_NUMBER` and
`NEXT_PUBLIC_NAGAD_NUMBER`; blank falls back to `NEXT_PUBLIC_PHONE`.

## Automatic TrxID checking — no API, no clicking

bKash has no free API to ask "is this TrxID real?". The shop's own phone already knows: it gets
one SMS per payment, and that SMS carries the amount, the TrxID and the payer's number. So the
site listens for it.

- **`/admin/payments`** shows a forwarding URL that carries a rotating token.
- Install a free SMS-forwarder app on the shop phone, point it at that URL for the bKash and
  Nagad senders, POST the message body. Every receipt is read on arrival (`lib/payments/parse.js`)
  and matched against the order waiting on that TrxID (`lib/payments/auto.js`).
- **The amount is the gate.** Exact money releases the order and sets `verified_by=auto:sms`.
  One taka short, or more than asked, is never auto-released — it goes to *Waiting for a person*
  with both figures, because quietly keeping a difference is how a shop loses a customer.
- A repeated SMS is recognised as a duplicate and changes nothing. A TrxID belongs to one payment.
- **Statement paste**: the same matching runs over a pasted TrxID list, for a day the phone was
  off. One line per payment, e.g. `9F7A2KD10X 150`.
- Every forwarded message is kept in `payment_inbox` with its outcome, so nothing vanishes.
- The token lives in `settings.payment_sms_token`, is shown only behind the admin sign-in, and
  **Rotate the token** kills the old URL instantly.

If the shop ever opens a merchant account, the same tables accept a real gateway callback and the
TrxID becomes instant — but nothing here needs that to work today.

## Adding a new piece from the phone — with photographs

1. Sign in at `/admin/login` (the link is not on the shop front any more; only you know the address).
2. **Add a design** in the admin menu (or **Products & prices → + Add a design or a style**).
   That screen has two tabs: **New design on an existing piece** — pick the piece, then colour,
   design name, price, stock and (if you have one) its own photo; and **New piece (a new style)**
   — the whole piece with its photographs.
3. Pick the line (Suits, Blazers, Trousers, Shirts, Uniforms), type the name, the one line under it,
   the small caps line and the description.
4. Press **Choose a photo**. Take the picture there and then. The browser shrinks it to 1400px and
   uploads it; you see the picture straight away. Its own photo per design is optional.
5. Add one line per colour + design: colour name, design name, price, how many you can cut.
   The swatch colour is guessed from the colour name (type "bottle green" and you get a green dot);
   you can change it later.
6. **Save the new piece.** It is in the shop immediately, with the same card, the same photo
   treatment and the same colour/design picking as the twenty pieces that were already there.

Photographs are stored in the database (`product_images`, served at `/api/img/<key>`), not on the
container's disk, so they survive every redeploy. Nothing to configure, no S3 bucket, no bill.

Editing an existing piece is the same screen: the words, the main photo, each design's photo,
price, stock, "take off sale", and "add a colour or design".

## Cancellations — asked, accepted, cancelled

- The customer presses **Ask to cancel this order** on `/order/<code>`, optionally says why.
- The shop sees it on the admin overview and in **Orders → Cancellation requests**, and presses
  **Accept** or **Decline** (a note can be added).
- The answer is written on the order for good: *Cancellation asked — waiting for the shop*,
  *Cancelled — accepted by the shop*, or *Cancellation declined — the order stands*.
  Accepting also sets the order status to `cancelled`. The customer can withdraw a request.

## The catalogue, the photos and how people find the shop

- **Four pieces from every line** on the front page: Suits, Blazers, Trousers, Shirts, Uniforms.
  The five-line boxes are gone; each line has its own block with a "See all" link.
- **A side line under the hero**: "Made for tailoring, not for ready-made."
- **A photograph for each colour and each design**, not one picture cropped five ways, plus a
  close-up strip on every piece page: Front · Pocket · Cuff · Back · Lining. Tap any of them and it
  opens full size.
- **No cloth shelf on the uniform pages** — uniform cloth is agreed with the school.
- **Search and sharing** (see `lib/seo.js`): ClothingStore, Product, BreadcrumbList and FAQPage
  structured data, per-page titles and descriptions, canonical URLs, Open Graph and Twitter cards,
  a sitemap that carries the photographs, and `lang` that follows the language toggle.
- **Thumbnails**: `public/products/thumbs/` holds a 400px version of every photograph, and cards
  and gallery buttons ask for those instead of the full file (a piece page went from 881 KB to
  243 KB).

`node scripts/catalogue-gallery.js` fills in the per-colour and per-design photographs, the
close-up gallery and the extra pieces in the thin lines. Safe to run again.

## What the shop is now

- **Five lines**: suits, blazers, trousers, shirts and uniforms — twenty styles, 127 colour × design
  combinations, each with its own price and stock. Uniforms carry the scout set (full set, shirt,
  trousers, neckerchief and belt) in two uniform colours.
- **Every colour is a chip you press, every design is a box with its own photograph**, and the price
  follows the pair you choose. A design box that cannot be cut in the chosen cloth says so instead of
  pretending.
- **The front window turns over every two seconds** through the house's own pieces — suits, blazers,
  the scout uniform and the rest.
- **The order button floats in the lower-right corner** from the top of the page, with WhatsApp and a
  call beside it. It steps aside on `/admin` and `/pay`.
- **English ⇄ বাংলা** on every page; the choice rides a `th_lang` cookie.
- **Nobody signs up.** An order carries a name and a phone number and that is the customer record;
  `admin/customers` is built from orders. The customer dashboard is gone.
- **Contact is WhatsApp or a call**, never a dead end.
- **Admin** (`/admin`, behind `/admin/login`): orders with status, payment, size source and due,
  products with price and stock per variant, cloth stock with a logged reason for every change,
  and the customer list.

## Checks

`tests/e2e-store.js` (in the parent folder, updated as `tests/v2-checks.js`) drives the whole thing in a real browser: catalogue →
variant price change → cart → checkout with the visit advance → mock payment → confirmation →
register + save measurements → admin login → price edit reflected in the shop → fabric stock
adjustment logged → order visible in admin → status change. 23 checks, all passing against the
seeded database.

## Deploying on Antideploy

The live copy of this shop runs on Antideploy, on the account `raiyan1024@gmail.com` (Google sign-in).

| | |
|---|---|
| Address | https://freemans.antideploy.app |
| Application id | `8bfa856f-9ce2-47c8-88ed-0dbfb770eba8` (saved in `.antideploy.json`) |
| Dashboard | https://antideploy.com/app/8bfa856f-9ce2-47c8-88ed-0dbfb770eba8 |
| Database | its own Postgres, created by the platform; `DATABASE_URL` + `PG*` are injected into the container |
| Admin login | `admin@tailoring.local` / `ChangeMe123!` |

The platform sets `DATABASE_URL`, `SESSION_SECRET` and the app's own address on every deploy, so
none of those need to be pushed. `.env` holds the database variables for local work and is gitignored;
`.env` and `.env.local` are excluded from the deploy archive so they can never override the live values.

Redeploy after a code or variable change:

    tar czf - --exclude=.git --exclude=node_modules --exclude=.next \
              --exclude=.env --exclude=.env.local --exclude=.vercel --exclude='*.zip' . \
      | curl -s -X POST "https://antideploy.com/api/v1/deploy?applicationId=$(python3 -c "import json;print(json.load(open('.antideploy.json'))['applicationId'])")" \
          -H "Authorization: Bearer $TOKEN" -F "archive=@-;filename=app.tar.gz"

or `POST /api/v1/redeploy` with `{"applicationId":"..."}` to rebuild the last version.

The account token lives at `~/.antideploy/config.json` (mode 0600) and can be revoked at
https://antideploy.com/tokens.
