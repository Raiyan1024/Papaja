export const dynamic = 'force-dynamic';

/** /robots.txt — keep the admin panel and the payment callback out of the index. */
export default function robots() {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || 'https://freemans.antideploy.app').replace(/\/+$/, '');
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/admin', '/admin/', '/pay/', '/api/', '/order/']
      }
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base
  };
}
