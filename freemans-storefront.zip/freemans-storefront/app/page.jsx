import Link from 'next/link';
import ProductCard from '@/components/product-card';
import { getCategories, listProducts, listFabrics, productCountsByCategory } from '@/lib/catalogue';
import { taka, VISIT_FEE, VISIT_FEE_OUTSIDE, REFUND_PCT } from '@/lib/money';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { telLink, waLink, PHONE_PRETTY } from '@/lib/contact';

export const dynamic = 'force-dynamic';

/** The four pictures on the front page: the scout uniform first, then a jacket, a trouser and a shirt. */
const TILE_ORDER = [
  ['uniforms', 'uniform'],
  ['blazers', 'blazer'],
  ['trousers', 'trouser'],
  ['shirts', 'shirt'],
  ['suits', 'suit']
];

export default async function HomePage() {
  const lang = await getLang();
  const [categories, featured, fabrics, counts] = await Promise.all([
    getCategories(),
    listProducts(null),
    listFabrics(),
    productCountsByCategory()
  ]);

  const tiles = [];
  for (const [slug, key] of TILE_ORDER) {
    const pick = featured.find(p => p.category_slug === slug && p.image);
    if (pick) tiles.push({ ...pick, key });
    if (tiles.length === 4) break;
  }

  // "What we make most" — four pieces from every line, so the wall is not just suits.
  const lines = categories
    .map(category => ({
      category,
      pieces: featured.filter(p => p.category_slug === category.slug).slice(0, 4)
    }))
    .filter(line => line.pieces.length);

  return (
    <>
      <section className="wrap hero">
        <div>
          <p className="eyebrow">{t(lang, 'hero.eyebrow')}</p>
          <h1>
            {t(lang, 'hero.titleA')}<br />
            <em>{t(lang, 'hero.titleB')}</em>
          </h1>
          <p className="muted" style={{ marginTop: 14 }}>{t(lang, 'hero.sub')}</p>

          <div className="pledge">
            <b>{t(lang, 'hero.pledgePay')}</b>
            <span>{t(lang, 'hero.pledgeFit')}</span>
          </div>

          <div className="stat-row small">
            <div>
              <b>{taka(VISIT_FEE)}</b>
              <span>{t(lang, 'hero.statVisit')} · {taka(VISIT_FEE_OUTSIDE)} {lang === 'bn' ? 'ঢাকার বাইরে' : 'outside Dhaka'}</span>
            </div>
            <div>
              <b>S – XXXL</b>
              <span>{t(lang, 'hero.statSize')}</span>
            </div>
            <div>
              <b>{categories.length} {lang === 'bn' ? 'লাইন' : 'lines'}</b>
              <span>{t(lang, 'hero.statLines')}</span>
            </div>
          </div>

          <div className="row" style={{ marginTop: 22, flexWrap: 'wrap' }}>
            <Link href="/suits" className="btn">{t(lang, 'hero.browse')}</Link>
            <Link href="/visit" className="btn outline">{t(lang, 'hero.bookVisit')}</Link>
            <a href={waLink(lang === 'bn' ? 'আসসালামু আলাইকুম, অর্ডার নিয়ে কথা বলতে চাই।' : 'Hello, I would like to talk about an order.')}
               target="_blank" rel="noreferrer" className="btn ghost wa-btn">
              {t(lang, 'common.whatsapp')}
            </a>
          </div>
        </div>

        {/* Four pieces, four pictures — the scout uniform first, because that is what sells. */}
        <div className="hero-tiles">
          {tiles.map((tile, i) => (
            <Link key={tile.id} href={`/product/${tile.slug}`} className={`hero-tile ${i === 0 ? 'lead' : ''}`}>
              <img src={tile.image} alt={tile.name} loading={i === 0 ? 'eager' : 'lazy'} />
              <span className="hero-tile-tag">{lang === 'bn' && tile.category_name_bn ? tile.category_name_bn : tile.category_name}</span>
              <span className="hero-tile-name">{tile.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* The line the shop asked for: this is a tailoring house, not a ready-made shop. */}
      <div className="side-line">
        <div className="wrap side-line-inner">
          <span>{lang === 'bn' ? 'বানানো হয় মাপে — রেডিমেড নয়' : 'Made for tailoring, not for ready-made'}</span>
          <span className="muted small">
            {lang === 'bn'
              ? 'প্রতিটি পোশাক আপনার মাপে কাটা হয় · ঢাকায় বাসায় মাপ ৳১৫০'
              : 'Every piece cut to your measure · home visit ৳150 in Dhaka'}
          </span>
        </div>
      </div>

      <section className="wrap tight" style={{ paddingBottom: 4 }}>
        <div className="between">
          <p className="eyebrow" style={{ margin: 0 }}>01 / {t(lang, 'cat.eyebrow')}</p>
          <p className="muted small" style={{ margin: 0 }}>
            {featured.length} {t(lang, 'common.styles')} · {t(lang, 'hero.statLines')}
          </p>
        </div>
        <h2 style={{ margin: '12px 0 4px' }}>{t(lang, 'cat.whatWeMake')}</h2>
        <p className="muted small" style={{ margin: '0 0 18px' }}>
          {lang === 'bn' ? 'প্রতি লাইন থেকে চারটি — সবগুলো দেখতে লাইনের নাম চাপুন' : 'Four from every line — press a line to see all of it'}
        </p>
      </section>

      <section className="wrap" style={{ paddingTop: 10 }}>
        {lines.map(({ category, pieces }) => (
          <div key={category.slug} className="line-block">
            <div className="between" style={{ marginBottom: 14 }}>
              <div>
                <h2 style={{ margin: 0 }}>{lang === 'bn' && category.name_bn ? category.name_bn : category.name}</h2>
                <p className="muted small" style={{ margin: '4px 0 0' }}>{category.tagline}</p>
              </div>
              <Link href={`/${category.slug}`} className="btn outline small">
                {t(lang, 'common.seeAll')} → {category.name}
              </Link>
            </div>
            <div className="grid-4 compact-cards">
              {pieces.map(product => <ProductCard key={product.id} product={product} lang={lang} />)}
            </div>
          </div>
        ))}
      </section>

      <section className="wrap">
        <div className="split">
          <div>
            <p className="eyebrow">02 / {t(lang, 'cloth.eyebrow')}</p>
            <h2>{t(lang, 'cloth.title')}</h2>
            <p style={{ marginTop: 16 }}>{t(lang, 'cloth.body')}</p>
            <div className="row" style={{ marginTop: 20, flexWrap: 'wrap' }}>
              <Link href="/order" className="btn">{t(lang, 'cloth.choose')}</Link>
              <Link href="/visit" className="btn outline">{t(lang, 'cloth.measure')}</Link>
            </div>
          </div>
          <div className="panel flat">
            {fabrics.slice(0, 8).map(fabric => (
              <div className="kv" key={fabric.id}>
                <span className="row" style={{ gap: 10 }}>
                  <span className="swatch" style={{ background: fabric.colour_hex }} />
                  {fabric.colour} · {fabric.name}
                </span>
                <span className="muted">{taka(fabric.price_per_yard)} / yd</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="wrap">
        <div className="panel" style={{ padding: '34px 34px' }}>
          <div className="split" style={{ gap: 40 }}>
            <div>
              <p className="eyebrow">03 / {t(lang, 'refund.eyebrow')}</p>
              <h2>{t(lang, 'refund.title', { pct: REFUND_PCT })}</h2>
              <p style={{ marginTop: 16 }}>{t(lang, 'refund.body', { pct: REFUND_PCT })}</p>
            </div>
            <div>
              <div className="kv"><b>{REFUND_PCT}%</b><span className="muted">{t(lang, 'refund.k1', { pct: REFUND_PCT })}</span></div>
              <div className="kv"><b>{lang === 'bn' ? '২ ঘণ্টা' : '2 hours'}</b><span className="muted">{t(lang, 'refund.k2')}</span></div>
              <div className="kv"><b>{lang === 'bn' ? 'সম্পূর্ণ' : 'Complete'}</b><span className="muted">{t(lang, 'refund.k3')}</span></div>
              <p className="hint" style={{ marginTop: 14 }}>{t(lang, 'refund.hint')}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="wrap">
        <div className="grid-3">
          <div className="panel">
            <p className="panel-title">{t(lang, 'pay.advance')}</p>
            <b style={{ fontFamily: 'var(--serif)', fontSize: 26 }}>{taka(VISIT_FEE)}</b>
            <p className="muted small" style={{ marginTop: 10 }}>{t(lang, 'pay.advanceBody')}</p>
            <Link href="/visit" className="btn outline small">{t(lang, 'pay.visitHow')}</Link>
          </div>
          <div className="panel">
            <p className="panel-title">{t(lang, 'pay.full')}</p>
            <b style={{ fontFamily: 'var(--serif)', fontSize: 26 }}>{lang === 'bn' ? 'অর্ডারের মোট' : 'Cart total'}</b>
            <p className="muted small" style={{ marginTop: 10 }}>{t(lang, 'pay.fullBody')}</p>
            <Link href="/order" className="btn outline small">{t(lang, 'pay.start')}</Link>
          </div>
          <div className="panel">
            <p className="panel-title">{t(lang, 'pay.talk')}</p>
            <b style={{ fontFamily: 'var(--serif)', fontSize: 26 }}>{lang === 'bn' ? 'কথা বলুন' : 'Talk it through'}</b>
            <p className="muted small" style={{ marginTop: 10 }}>{t(lang, 'pay.talkBody')}</p>
            <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
              <a href={waLink(lang === 'bn' ? 'ডিজাইন নিয়ে কথা বলতে চাই।' : 'I would like to discuss a design.')} target="_blank" rel="noreferrer" className="btn outline small wa-btn">
                {t(lang, 'common.whatsapp')}
              </a>
              <a href={telLink()} className="btn ghost small">{PHONE_PRETTY}</a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
