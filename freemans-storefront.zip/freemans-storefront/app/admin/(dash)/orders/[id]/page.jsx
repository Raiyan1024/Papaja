import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getOrderById, ORDER_STATUSES } from '@/lib/orders';
import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';
import { changeOrderStatus, changePaymentStatus, verifyManualPayment, rejectManualPayment, decideCancellation } from '@/app/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminOrder({ params }) {
  const { id } = await params;
  const order = await getOrderById(Number(id));
  if (!order) notFound();

  const customer = order.user_id
    ? (await safeQ('select id, email, name, phone from users where id = $1', [order.user_id]))[0]
    : null;
  const measurements = customer
    ? await safeQ('select * from measurements where user_id = $1 order by updated_at desc', [customer.id])
    : [];

  return (
    <>
      <div className="between">
        <div>
          <Link href="/admin/orders" className="muted small">← All orders</Link>
          <h3 style={{ marginTop: 6 }}>{order.code}</h3>
          <p className="muted small" style={{ margin: 0 }}>{new Date(order.created_at).toLocaleString()}</p>
        </div>
        <span className={`pill ${order.payment_status === 'paid' ? 'good' : 'warn'}`}>
          {order.payment_option === 'advance' ? 'Visit advance' : 'Full payment'} · {order.payment_status}
        </span>
      </div>

      {order.cancel_state ? (
        <div className={`alert ${order.cancel_state === 'accepted' ? 'bad' : order.cancel_state === 'rejected' ? 'good' : 'warn'}`} style={{ marginTop: 16 }}>
          <div className="between" style={{ alignItems: 'flex-start', gap: 12 }}>
            <div>
              <b>
                {order.cancel_state === 'requested'
                  ? 'The customer asked to cancel this order.'
                  : order.cancel_state === 'accepted'
                    ? 'Cancelled — you accepted the request.'
                    : 'Cancellation declined — the order stands.'}
              </b>
              {order.cancel_reason ? <div className="small" style={{ marginTop: 4 }}>Reason: {order.cancel_reason}</div> : null}
              {order.cancel_note ? <div className="small" style={{ marginTop: 4 }}>Note: {order.cancel_note}</div> : null}
              {order.cancel_requested_at ? (
                <div className="small muted" style={{ marginTop: 4 }}>
                  Asked {new Date(order.cancel_requested_at).toLocaleString()}
                  {order.cancel_decided_at ? ` · answered ${new Date(order.cancel_decided_at).toLocaleString()}` : ''}
                </div>
              ) : null}
            </div>
            <span className={`pill ${order.cancel_state === 'accepted' ? 'bad' : order.cancel_state === 'rejected' ? 'good' : 'warn'}`}>
              {order.cancel_state}
            </span>
          </div>
          {order.cancel_state === 'requested' ? (
            <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
              <form action={decideCancellation}>
                <input type="hidden" name="id" value={order.id} />
                <input type="hidden" name="decision" value="accepted" />
                <button className="btn small" type="submit">Accept — mark cancelled</button>
              </form>
              <form action={decideCancellation} className="row" style={{ gap: 6 }}>
                <input type="hidden" name="id" value={order.id} />
                <input type="hidden" name="decision" value="rejected" />
                <input name="note" placeholder="Tell the customer why (optional)" style={{ width: 260, padding: '5px 8px', fontSize: 12 }} />
                <button className="btn ghost small" type="submit">Decline the request</button>
              </form>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="split" style={{ marginTop: 18, alignItems: 'start', gap: 26 }}>
        <div>
          <div className="panel">
            <p className="panel-title">Pieces</p>
            <table className="table">
              <thead><tr><th>Piece</th><th>Colour / design</th><th className="num">Qty</th><th className="num">Price</th></tr></thead>
              <tbody>
                {order.items.map(item => (
                  <tr key={item.id}>
                    <td>{item.title}</td>
                    <td className="muted small">{item.colour}<br />{item.design}</td>
                    <td className="num">{item.qty}</td>
                    <td className="num">{taka(item.unit_price * item.qty)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="kv" style={{ marginTop: 12 }}><span>Pieces</span><b>{taka(order.subtotal)}</b></div>
            {order.visit_fee ? <div className="kv"><span>Home visit</span><b>{taka(order.visit_fee)}</b></div> : null}
            <div className="kv total"><span>Total</span><b>{taka(order.total)}</b></div>
            <div className="kv"><span>Due</span><b>{taka(order.amount_due)}</b></div>
          </div>

          <div className="panel" style={{ marginTop: 16 }}>
            <p className="panel-title">What the customer asked for</p>
            <div className="kv"><span>Size</span><span>{order.measurement_mode.replace('_', ' ')}</span></div>
            {order.measurement_note ? <div className="kv"><span>Measurements</span><span style={{ maxWidth: 320, textAlign: 'right' }}>{order.measurement_note}</span></div> : null}
            {order.cloth_choice ? <div className="kv"><span>Cloth</span><span>{order.cloth_choice}</span></div> : null}
            {order.wants_discussion ? <div className="kv"><span>Discussion</span><span className="pill warn">Requested</span></div> : null}
            {order.discussion_topic ? <div className="kv"><span>Topic</span><span style={{ maxWidth: 320, textAlign: 'right' }}>{order.discussion_topic}</span></div> : null}
            {order.notes ? <div className="kv"><span>Notes</span><span style={{ maxWidth: 320, textAlign: 'right' }}>{order.notes}</span></div> : null}
            {order.items.some(i => i.custom_brief) ? (
              <div className="kv"><span>Item brief</span><span style={{ maxWidth: 320, textAlign: 'right' }}>{order.items.find(i => i.custom_brief)?.custom_brief}</span></div>
            ) : null}
          </div>

          {measurements.length ? (
            <div className="panel" style={{ marginTop: 16 }}>
              <p className="panel-title">Measurements on file</p>
              {measurements.map(m => (
                <div className="kv" key={m.id}>
                  <span className="muted small">
                    {['chest', 'waist', 'hip', 'shoulder', 'sleeve', 'length', 'inseam', 'collar']
                      .filter(k => m[k])
                      .map(k => `${k} ${Number(m[k])}`)
                      .join(' · ') || 'No numbers saved'}
                  </span>
                  <span className="muted small">{m.notes}</span>
                </div>
              ))}
            </div>
          ) : null}
        </div>

        <aside>
          <div className="panel">
            <p className="panel-title">Customer</p>
            <div className="kv"><span>Name</span><b>{order.customer_name}</b></div>
            <div className="kv"><span>Phone</span><b>{order.customer_phone}</b></div>
            {order.customer_email ? <div className="kv"><span>Email</span><span>{order.customer_email}</span></div> : null}
            {order.area ? <div className="kv"><span>Area</span><span>{order.area}</span></div> : null}
            {order.address ? <div className="kv"><span>Address</span><span style={{ maxWidth: 200, textAlign: 'right' }}>{order.address}</span></div> : null}
            {customer ? <div className="kv"><span>Account</span><span className="muted small">{customer.email}</span></div> : null}
          </div>

          <div className="panel" style={{ marginTop: 16 }}>
            <p className="panel-title">Status</p>
            <form action={changeOrderStatus} className="stack">
              <input type="hidden" name="id" value={order.id} />
              <select name="status" defaultValue={order.status}>
                {ORDER_STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
              </select>
              <button className="btn small" type="submit">Update order status</button>
            </form>

            <form action={changePaymentStatus} className="stack" style={{ marginTop: 14 }}>
              <input type="hidden" name="id" value={order.id} />
              <select name="status" defaultValue={order.payment_status}>
                <option value="unpaid">unpaid</option>
                <option value="partial">partial (advance paid, balance due)</option>
                <option value="paid">paid</option>
                <option value="refunded">refunded</option>
              </select>
              <button className="btn outline small" type="submit">Set payment status</button>
            </form>
            <p className="hint" style={{ marginTop: 10 }}>
              Use “paid” when money arrives outside the gateway (bKash to the shop number, cash on the visit).
            </p>
          </div>

          <div className="panel" style={{ marginTop: 16 }}>
            <p className="panel-title">Payments</p>
            {order.payments.length === 0 ? <p className="muted small" style={{ margin: 0 }}>No payment attempts yet.</p> : null}
            {order.payments.map(p => (
              <div key={p.id} style={{ borderTop: '1px solid var(--line)', paddingTop: 10, marginTop: 10 }}>
                <div className="kv" style={{ marginBottom: 6 }}>
                  <span>
                    <b>{taka(p.amount)}</b>
                    <span className="muted small" style={{ display: 'block' }}>
                      {p.method || p.provider} · {new Date(p.created_at).toLocaleString()}
                    </span>
                  </span>
                  <span className={`pill ${p.status === 'paid' ? 'good' : p.status === 'submitted' || p.status === 'initiated' ? 'warn' : 'bad'}`}>
                    {p.status}
                  </span>
                </div>

                {p.gateway_ref ? (
                  <div className="kv">
                    <span className="muted small">TrxID{p.sender_number ? ` · from ${p.sender_number}` : ''}</span>
                    <b style={{ letterSpacing: 1 }}>{p.gateway_ref}</b>
                  </div>
                ) : null}

                {p.status === 'submitted' ? (
                  <div className="stack" style={{ gap: 8, marginTop: 10 }}>
                    <p className="hint" style={{ margin: 0 }}>
                      Open bKash/Nagad, search this TrxID, check the amount is {taka(p.amount)}, then release the order.
                    </p>
                    <form action={verifyManualPayment} className="row" style={{ gap: 8 }}>
                      <input type="hidden" name="tran_id" value={p.tran_id} />
                      <input type="hidden" name="order_id" value={order.id} />
                      <button className="btn small" type="submit">Money is in — release</button>
                    </form>
                    <form action={rejectManualPayment} className="row" style={{ gap: 8 }}>
                      <input type="hidden" name="tran_id" value={p.tran_id} />
                      <input type="hidden" name="order_id" value={order.id} />
                      <input name="reason" placeholder="reason (optional)" style={{ flex: 1, minWidth: 140 }} />
                      <button className="btn outline small" type="submit">Does not match</button>
                    </form>
                  </div>
                ) : null}

                {p.status === 'paid' && p.checked_at ? (
                  <p className="hint" style={{ margin: 0 }}>
                    Checked by {p.checked_by || 'admin'} · {new Date(p.checked_at).toLocaleString()}
                  </p>
                ) : null}
                {p.note ? <p className="hint" style={{ margin: 0 }}>Note: {p.note}</p> : null}
              </div>
            ))}
          </div>
        </aside>
      </div>
    </>
  );
}
