import Link from 'next/link';
import { listAllOrders, ORDER_STATUSES, listCancellationRequests } from '@/lib/orders';
import { taka } from '@/lib/money';
import { changeOrderStatus, decideCancellation } from '@/app/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminOrders({ searchParams }) {
  const sp = await searchParams;
  const status = ORDER_STATUSES.includes(sp?.status) ? sp.status : null;
  const orders = await listAllOrders({ status, limit: 200 });
  const requests = await listCancellationRequests().catch(() => []);

  return (
    <>
      <div className="between">
        <h3>Orders</h3>
        <div className="row" style={{ gap: 6 }}>
          <Link href="/admin/orders" className={`btn small ${status ? 'outline' : ''}`}>All</Link>
          {ORDER_STATUSES.map(s => (
            <Link key={s} href={`/admin/orders?status=${s}`} className={`btn small ${status === s ? '' : 'outline'}`}>
              {s.replace('_', ' ')}
            </Link>
          ))}
        </div>
      </div>

      {requests.length ? (
        <div className="panel" style={{ marginTop: 14, borderColor: '#6b2b2b' }}>
          <h3 style={{ marginTop: 0 }}>Cancellation requests · {requests.length}</h3>
          <table className="table">
            <thead><tr><th>Order</th><th>Customer</th><th>Reason</th><th className="num">Total</th><th>Answer</th></tr></thead>
            <tbody>
              {requests.map(order => (
                <tr key={order.id}>
                  <td><Link href={`/admin/orders/${order.id}`} style={{ color: 'var(--blue)' }}>{order.code}</Link></td>
                  <td>{order.customer_name}<div className="muted small">{order.customer_phone}</div></td>
                  <td className="small">{order.cancel_reason || '—'}</td>
                  <td className="num">{taka(order.total)}</td>
                  <td>
                    <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                      <form action={decideCancellation}>
                        <input type="hidden" name="id" value={order.id} />
                        <input type="hidden" name="decision" value="accepted" />
                        <button className="btn small" type="submit">Accept</button>
                      </form>
                      <form action={decideCancellation}>
                        <input type="hidden" name="id" value={order.id} />
                        <input type="hidden" name="decision" value="rejected" />
                        <button className="btn ghost small" type="submit">Decline</button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      <div className="panel" style={{ padding: 0, marginTop: 14 }}>
        <table className="table">
          <thead>
            <tr><th>Order</th><th>Customer</th><th>Size</th><th>Pay</th><th className="num">Total</th><th className="num">Due</th><th>Status</th></tr>
          </thead>
          <tbody>
            {orders.length === 0 ? <tr><td colSpan={7} className="muted">No orders in this view.</td></tr> : null}
            {orders.map(order => (
              <tr key={order.id}>
                <td>
                  <Link href={`/admin/orders/${order.id}`} style={{ color: 'var(--blue)' }}>{order.code}</Link>
                  <div className="muted small">{new Date(order.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</div>
                </td>
                <td>{order.customer_name}<div className="muted small">{order.customer_phone}</div></td>
                <td className="muted small">{order.measurement_mode.replace('_', ' ')}{order.wants_discussion ? ' · discuss' : ''}</td>
                <td>
                  <span className={`pill ${order.payment_status === 'paid' ? 'good' : order.payment_status === 'refunded' ? 'bad' : 'warn'}`}>
                    {order.payment_option === 'advance' ? 'advance' : 'full'} · {order.payment_status}
                  </span>
                </td>
                <td className="num">{taka(order.total)}</td>
                <td className="num">{taka(order.amount_due)}</td>
                <td>
                  {order.cancel_state ? (
                    <span className={`pill ${order.cancel_state === 'accepted' ? 'bad' : order.cancel_state === 'rejected' ? 'good' : 'warn'}`} style={{ marginBottom: 6 }}>
                      cancel {order.cancel_state}
                    </span>
                  ) : null}
                  <form action={changeOrderStatus} className="row" style={{ gap: 6 }}>
                    <input type="hidden" name="id" value={order.id} />
                    <select name="status" defaultValue={order.status} style={{ width: 132, padding: '5px 7px', fontSize: 12 }}>
                      {ORDER_STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                    </select>
                    <button className="btn ghost small" type="submit">Set</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
