import Link from 'next/link';
import { safeQ } from '@/lib/db';
import NewProductForm from '@/components/admin/new-product-form';
import AddDesignForm from '@/components/admin/add-design-form';
import Tabs from '@/components/admin/tabs';

export const dynamic = 'force-dynamic';

/**
 * One screen for both jobs the shop actually does:
 *   · a new design inside a piece that already exists
 *   · a whole new piece (a style) with its own photographs
 * Either way what you save appears in the boxes on the shop front straight away.
 */
export default async function AdminDesigns({ searchParams }) {
  const sp = await searchParams;
  const products = await safeQ(
    `select p.id, p.name, p.active, c.name as category_name
       from products p join categories c on c.id = p.category_id
      order by c.position, p.position, p.name`
  );
  const variants = await safeQ('select id, product_id, colour, design, price, stock from product_variants where active order by product_id, colour');
  const categories = await safeQ('select id, name, slug from categories order by position, name');

  const byProduct = new Map();
  for (const v of variants) {
    if (!byProduct.has(v.product_id)) byProduct.set(v.product_id, []);
    byProduct.get(v.product_id).push(v);
  }
  const withDesigns = products.map(p => ({ ...p, designs: byProduct.get(p.id) || [] }));

  const openProduct = sp?.product ? Number(sp.product) : withDesigns[0]?.id;

  return (
    <>
      <div className="between">
        <div>
          <p className="eyebrow" style={{ marginBottom: 6 }}>Products &amp; prices</p>
          <h3 style={{ margin: 0 }}>Add a design or a style</h3>
        </div>
        <Link href="/admin/products" className="btn outline small">← The list of everything</Link>
      </div>

      {sp?.added ? (
        <div className="alert good" style={{ marginTop: 12 }}>
          Saved — the design is in that piece's boxes on the shop already.
          {' '}<Link href="/admin/products">See it in the list →</Link>
        </div>
      ) : null}

      <p className="hint" style={{ marginTop: 10 }}>
        A <b>design</b> is one more colour-and-cutting inside a piece that already exists. A <b>style</b>
        is a whole new piece with its own page, its own photograph and its own designs. Both show up in
        the shop the moment you save — no code, no waiting.
      </p>

      <div style={{ marginTop: 18 }}>
        <Tabs
          initial={sp?.style ? 1 : 0}
          tabs={[
            {
              key: 'design',
              label: 'New design on an existing piece',
              content: <AddDesignForm products={withDesigns} defaultProduct={openProduct} />
            },
            {
              key: 'style',
              label: 'New piece (a new style)',
              content: <NewProductForm categories={categories} defaultCategory={categories[0]?.id} />
            }
          ]}
        />
      </div>
    </>
  );
}
