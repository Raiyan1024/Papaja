import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';
import { saveFabric, adjustFabricStock } from '@/app/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminFabrics() {
  const fabrics = await safeQ('select * from fabrics order by active desc, colour');
  const movements = await safeQ(
    `select m.*, f.colour, f.name from stock_movements m left join fabrics f on f.id = m.fabric_id
      where m.fabric_id is not null order by m.created_at desc limit 20`
  );
  const low = fabrics.filter(f => f.active && Number(f.yards_in_stock) <= Number(f.reorder_level));

  return (
    <>
      <div className="between">
        <h3>Fabric stock</h3>
        <span className={`pill ${low.length ? 'warn' : 'good'}`}>{low.length ? `${low.length} need reordering` : 'All above reorder level'}</span>
      </div>
      <p className="hint" style={{ marginTop: 6 }}>
        Yards on the shelf, price per yard, and the level at which the shop should reorder. Every change is logged.
      </p>

      <div className="panel" style={{ padding: 0, marginTop: 14 }}>
        <table className="table">
          <thead>
            <tr><th>Cloth</th><th>Composition</th><th className="num">৳ / yd</th><th className="num">Yards</th><th className="num">Reorder at</th><th>Quick take</th><th className="num">Save</th></tr>
          </thead>
          <tbody>
            {fabrics.map(fabric => (
              <tr key={fabric.id}>
                <td>
                  <span className="row" style={{ gap: 8 }}>
                    <span className="swatch" style={{ background: fabric.colour_hex }} />
                    <span><b style={{ fontFamily: 'var(--serif)' }}>{fabric.colour}</b><div className="muted small">{fabric.name} · {fabric.code}</div></span>
                  </span>
                </td>
                <td className="muted small">{fabric.composition}</td>
                <td colSpan={5}>
                  <div className="row" style={{ gap: 8, justifyContent: 'flex-end' }}>
                    <form action={adjustFabricStock} className="row" style={{ gap: 6 }}>
                      <input type="hidden" name="id" value={fabric.id} />
                      <input name="delta" type="number" step="0.5" placeholder="± yds" style={{ width: 84 }} aria-label="Adjust yards" />
                      <input name="reason" placeholder="reason" style={{ width: 110 }} aria-label="Reason" />
                      <button className="btn ghost small" type="submit">Apply</button>
                    </form>
                    <form action={saveFabric} className="row" style={{ gap: 6 }}>
                      <input type="hidden" name="id" value={fabric.id} />
                      <input name="price_per_yard" type="number" min="0" step="10" defaultValue={fabric.price_per_yard} style={{ width: 92 }} aria-label="Price per yard" />
                      <input name="yards_in_stock" type="number" min="0" step="0.5" defaultValue={Number(fabric.yards_in_stock)} style={{ width: 82 }} aria-label="Yards in stock" />
                      <input name="reorder_level" type="number" min="0" step="0.5" defaultValue={Number(fabric.reorder_level)} style={{ width: 72 }} aria-label="Reorder level" />
                      <label className="row" style={{ gap: 5, fontSize: 11 }}>
                        <input type="checkbox" name="active" defaultChecked={fabric.active} style={{ width: 14, height: 14 }} /> on
                      </label>
                      <button className="btn small" type="submit">Save</button>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h3 style={{ margin: '26px 0 10px' }}>Recent movements</h3>
      <div className="panel">
        {movements.length === 0 ? <p className="muted small" style={{ margin: 0 }}>Nothing logged yet.</p> : null}
        {movements.map(m => (
          <div className="kv" key={m.id}>
            <span>
              <b>{m.colour || '—'} {m.name || ''}</b>
              <span className="muted small" style={{ display: 'block' }}>{new Date(m.created_at).toLocaleString()} · {m.reason}</span>
            </span>
            <span style={{ color: Number(m.delta) < 0 ? 'var(--bad)' : 'var(--good)' }}>
              {Number(m.delta) > 0 ? '+' : ''}{Number(m.delta)} yd
            </span>
          </div>
        ))}
      </div>
    </>
  );
}
