import Link from 'next/link';
import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';

export const dynamic = 'force-dynamic';

/**
 * Nobody signs up on this shop any more, so the customer list is simply the people
 * who have ordered — one row per phone number, built from the orders themselves.
 */
export default async function AdminCustomersPage() {
  const rows = await safeQ(
    `select customer_name, customer_phone, customer_email,
            count(*)::int                        as orders,
            coalesce(sum(total), 0)::int          as spent,
            coalesce(sum(case when payment_status = 'paid' then total else 0 end), 0)::int as paid,
            max(created_at)                      as last_order,
            min(created_at)                      as first_order
       from orders
      group by customer_name, customer_phone, customer_email
      order by max(created_at) desc
      limit 200`
  );

  return (
    <div>
      <div className="between" style={{ marginBottom: 16 }}>
        <h3 style={{ margin: 0 }}>Customers</h3>
        <span className="muted small">{rows.length} people, from the orders themselves</span>
      </div>

      {rows.length === 0 ? (
        <div className="alert warn">
          No orders yet. The first one placed on the site appears here with the phone number to call back on.
        </div>
      ) : (
        <div className="panel flat" style={{ overflowX: 'auto' }}>
          <table className="admin-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Orders</th>
                <th>Value</th>
                <th>Collected</th>
                <th>Last order</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(row => (
                <tr key={row.customer_phone + row.customer_name}>
                  <td>
                    <b>{row.customer_name}</b>
                    {row.customer_email ? <span className="muted small" style={{ display: 'block' }}>{row.customer_email}</span> : null}
                  </td>
                  <td><a href={`tel:${row.customer_phone}`}>{row.customer_phone}</a></td>
                  <td>{row.orders}</td>
                  <td>{taka(row.spent)}</td>
                  <td>{taka(row.paid)}</td>
                  <td className="muted small">{new Date(row.last_order).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="hint" style={{ marginTop: 14 }}>
        There is no sign-up on this shop: an order carries the name and the phone number, and that is the whole
        customer record. <Link href="/admin/orders">See the orders →</Link>
      </p>
    </div>
  );
}
