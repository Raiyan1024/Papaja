import Link from 'next/link';
import { requireAdmin } from '@/lib/auth';
import { logout } from '@/app/actions/auth';

export const dynamic = 'force-dynamic';

const ITEMS = [
  ['/admin', 'Overview'],
  ['/admin/orders', 'Orders'],
  ['/admin/products', 'Products & prices'],
  ['/admin/designs', 'Add a design'],
  ['/admin/fabrics', 'Fabric stock'],
  ['/admin/payments', 'Payments'],
  ['/admin/customers', 'Customers']
];

export default async function AdminLayout({ children }) {
  const user = await requireAdmin();
  return (
    <section className="wrap" style={{ paddingTop: 34 }}>
      <div className="between" style={{ marginBottom: 22 }}>
        <div>
          <p className="eyebrow" style={{ marginBottom: 8 }}>Shop admin</p>
          <h1 style={{ fontSize: 30 }}>Behind the counter</h1>
        </div>
        <div className="row">
          <span className="pill">{user.email}</span>
          <Link href="/" className="btn outline small">View the site</Link>
          <form action={logout}><button className="btn ghost small" type="submit">Sign out</button></form>
        </div>
      </div>
      <div className="admin-shell">
        <nav className="admin-nav" aria-label="Admin">
          {ITEMS.map(([href, label]) => <Link key={href} href={href}>{label}</Link>)}
        </nav>
        <div>{children}</div>
      </div>
    </section>
  );
}
