import Link from 'next/link';
import { safeQ } from '@/lib/db';
import NewProductForm from '@/components/admin/new-product-form';

export const dynamic = 'force-dynamic';

export default async function NewProductPage({ searchParams }) {
  const sp = await searchParams;
  const categories = await safeQ('select id, name, slug from categories order by position, name');
  const defaultCategory = sp?.category ? Number(sp.category) : categories[0]?.id;

  return (
    <>
      <div className="between">
        <div>
          <p className="eyebrow" style={{ marginBottom: 6 }}>Products &amp; prices</p>
          <h3 style={{ margin: 0 }}>Add a new piece</h3>
        </div>
        <Link href="/admin/products" className="btn outline small">← Back to the list</Link>
      </div>

      <p className="hint" style={{ marginTop: 10 }}>
        Fill this in the way you would explain the piece to a customer: the name, one line about it,
        the photo, then each colour and design with its own price and how many you can cut.
      </p>

      <div style={{ marginTop: 18 }}>
        <NewProductForm categories={categories} defaultCategory={defaultCategory} />
      </div>
    </>
  );
}
