import Link from 'next/link';
import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';
import {
  saveVariant,
  saveProduct,
  setProductImage,
  setVariantImage,
  addVariant,
  hideVariant,
  toggleProduct
} from '@/app/actions/admin';
import ImageSwapForm from '@/components/admin/image-swap-form';
import ImageField from '@/components/admin/image-field';

export const dynamic = 'force-dynamic';

const FLASH = {
  created: 'Saved. The new piece is in the shop already.',
  added: 'That colour and design is on the shelf.',
  saved: 'Saved.'
};

export default async function AdminProducts({ searchParams }) {
  const sp = await searchParams;
  const products = await safeQ(
    `select p.*, c.name as category_name from products p join categories c on c.id = p.category_id
      order by c.position, p.position`
  );
  const variants = await safeQ(
    `select v.*, f.code as fabric_code from product_variants v left join fabrics f on f.id = v.fabric_id order by v.id`
  );
  const byProduct = new Map();
  for (const v of variants) {
    if (!byProduct.has(v.product_id)) byProduct.set(v.product_id, []);
    byProduct.get(v.product_id).push(v);
  }
  const openId = sp?.open ? Number(sp.open) : products[0]?.id;
  const flash = Object.entries(FLASH).find(([key]) => sp?.[key]);

  return (
    <>
      <div className="between">
        <h3>Products, designs and prices</h3>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <p className="hint" style={{ margin: 0 }}>{products.length} pieces · {variants.length} colour × design</p>
          <Link href="/admin/designs" className="btn small">+ Add a design or a style</Link>
        </div>
      </div>

      {flash ? <div className="alert good" style={{ marginTop: 12 }}>{flash[1]}</div> : null}

      <div className="panel" style={{ padding: 0, marginTop: 14 }}>
        <table className="table">
          <thead>
            <tr><th>Photo</th><th>Piece</th><th>Line</th><th className="num">Designs</th><th className="num">From</th><th className="num">Stock</th><th /></tr>
          </thead>
          <tbody>
            {products.map(product => {
              const list = byProduct.get(product.id) || [];
              const from = list.length ? Math.min(...list.map(v => v.price)) : 0;
              return (
                <tr key={product.id} style={product.active ? undefined : { opacity: 0.55 }}>
                  <td style={{ width: 64 }}>
                    {product.image ? (
                      <img src={product.image} alt="" style={{ width: 46, height: 58, objectFit: 'cover', borderRadius: 6 }} />
                    ) : (
                      <span className="muted small">—</span>
                    )}
                  </td>
                  <td>
                    <b style={{ fontFamily: 'var(--serif)' }}>{product.name}</b>
                    <div className="muted small">{product.slug}{product.active ? '' : ' · hidden'}</div>
                  </td>
                  <td className="muted small">{product.category_name}</td>
                  <td className="num">{list.length}</td>
                  <td className="num">{taka(from)}</td>
                  <td className="num">{list.reduce((sum, v) => sum + v.stock, 0)}</td>
                  <td className="num"><Link className="btn ghost small" href={`/admin/products?open=${product.id}`}>Edit</Link></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {products.filter(p => p.id === openId).map(product => {
        const list = byProduct.get(product.id) || [];
        return (
          <div key={product.id} className="stack" style={{ gap: 16, marginTop: 22 }}>
            <div className="panel">
              <div className="between">
                <p className="panel-title" style={{ margin: 0, padding: 0 }}>Words — {product.name}</p>
                <form action={toggleProduct}>
                  <input type="hidden" name="id" value={product.id} />
                  <button className="btn ghost small" type="submit">
                    {product.active ? 'Hide this piece from the shop' : 'Show it in the shop again'}
                  </button>
                </form>
              </div>
              <form action={saveProduct} className="form-grid" style={{ marginTop: 12 }}>
                <input type="hidden" name="id" value={product.id} />
                <div className="field"><label htmlFor={`n-${product.id}`}>Name</label><input id={`n-${product.id}`} name="name" defaultValue={product.name} /></div>
                <div className="field"><label htmlFor={`s-${product.id}`}>One-line summary</label><input id={`s-${product.id}`} name="summary" defaultValue={product.summary || ''} /></div>
                <div className="field"><label htmlFor={`sp-${product.id}`}>Small caps line</label><input id={`sp-${product.id}`} name="spec" defaultValue={product.spec || ''} /></div>
                <div className="field"><label className="row" style={{ gap: 8 }}><input type="checkbox" name="active" defaultChecked={product.active} style={{ width: 15, height: 15 }} /> Visible in the shop</label></div>
                <div className="field full"><label htmlFor={`d-${product.id}`}>Description</label><textarea id={`d-${product.id}`} name="description" defaultValue={product.description || ''} /></div>
                <div className="full"><button className="btn small" type="submit">Save words</button></div>
              </form>
            </div>

            <div className="panel">
              <p className="panel-title">Main photo</p>
              <ImageSwapForm action={setProductImage} id={product.id} value={product.image || ''} label={product.name} />
            </div>

            <div className="panel" style={{ padding: 0 }}>
              <p className="panel-title" style={{ padding: '16px 16px 0' }}>Colour × design — price, stock and photo</p>
              <table className="table">
                <thead><tr><th>Photo</th><th>Colour</th><th>Design</th><th>Cloth</th><th className="num">Price (৳)</th><th className="num">Ready</th><th>On sale</th><th /></tr></thead>
                <tbody>
                  {list.length === 0 ? <tr><td colSpan={8} className="muted">No colours yet. Add the first one below.</td></tr> : null}
                  {list.map(variant => (
                    <tr key={variant.id} style={variant.active ? undefined : { opacity: 0.5 }}>
                      <td style={{ width: 58 }}>
                        {variant.image ? (
                          <img src={variant.image} alt="" style={{ width: 40, height: 50, objectFit: 'cover', borderRadius: 5 }} />
                        ) : (
                          <span className="muted small">—</span>
                        )}
                      </td>
                      <td>
                        <span className="row" style={{ gap: 8 }}>
                          <span className="swatch" style={{ background: variant.colour_hex }} />
                          {variant.colour}
                        </span>
                      </td>
                      <td style={{ minWidth: 150 }}>{variant.design}</td>
                      <td className="muted small">{variant.fabric_code || '—'}</td>
                      <td colSpan={4}>
                        <div className="row" style={{ gap: 8, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                          <form action={saveVariant} className="row" style={{ gap: 6 }}>
                            <input type="hidden" name="id" value={variant.id} />
                            <input name="price" type="number" min="0" step="50" defaultValue={variant.price} style={{ width: 100 }} aria-label="Price" />
                            <input name="stock" type="number" min="0" step="1" defaultValue={variant.stock} style={{ width: 70 }} aria-label="Stock" />
                            <label className="row" style={{ gap: 5, fontSize: 11 }}>
                              <input type="checkbox" name="active" defaultChecked={variant.active} style={{ width: 14, height: 14 }} />
                              on
                            </label>
                            <button className="btn small" type="submit">Save</button>
                          </form>
                          {variant.active ? (
                            <form action={hideVariant}>
                              <input type="hidden" name="id" value={variant.id} />
                              <input type="hidden" name="product_id" value={product.id} />
                              <button className="btn ghost small" type="submit">Take off sale</button>
                            </form>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div style={{ padding: 16, borderTop: '1px solid var(--line)' }}>
                <div className="between" style={{ alignItems: 'baseline' }}>
                  <p className="panel-title" style={{ marginTop: 0 }}>Add a colour or design to this piece</p>
                  <Link href={`/admin/designs?product=${product.id}`} className="small" style={{ color: 'var(--blue)' }}>
                    with a big photo instead →
                  </Link>
                </div>
                <form action={addVariant} className="row" style={{ gap: 8, flexWrap: 'wrap', alignItems: 'flex-end' }}>
                  <input type="hidden" name="product_id" value={product.id} />
                  <div className="field" style={{ width: 130 }}><label htmlFor={`nc-${product.id}`}>Colour</label><input id={`nc-${product.id}`} name="colour" placeholder="Olive" required /></div>
                  <div className="field" style={{ width: 170 }}><label htmlFor={`nd-${product.id}`}>Design</label><input id={`nd-${product.id}`} name="design" placeholder="House style" /></div>
                  <div className="field" style={{ width: 110 }}><label htmlFor={`np-${product.id}`}>Price ৳</label><input id={`np-${product.id}`} name="price" type="number" min="0" step="50" placeholder="12500" required /></div>
                  <div className="field" style={{ width: 90 }}><label htmlFor={`ns-${product.id}`}>Ready</label><input id={`ns-${product.id}`} name="stock" type="number" min="0" step="1" placeholder="2" /></div>
                  <div className="field" style={{ minWidth: 200 }}>
                    <label>Photo (optional)</label>
                    <ImageField name="image" />
                  </div>
                  <button className="btn small" type="submit">Add it</button>
                </form>
              </div>
            </div>

            {list.length ? (
              <div className="panel">
                <p className="panel-title">Photo for one design</p>
                <p className="hint" style={{ marginTop: 0 }}>
                  Pick a design below, choose its photo, save. Designs without their own photo use the main photo.
                </p>
                <div className="stack" style={{ gap: 14 }}>
                  {list.map(variant => (
                    <div key={variant.id}>
                      <b className="small">{variant.colour} · {variant.design}</b>
                      <ImageSwapForm
                        action={setVariantImage}
                        id={variant.id}
                        value={variant.image || ''}
                        label={`${variant.colour} ${variant.design}`}
                        submitLabel="Save photo"
                      />
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        );
      })}
    </>
  );
}
