import Link from 'next/link';
import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';
import { listPaymentsToCheck } from '@/lib/orders';
import { getSmsToken } from '@/lib/payments/auto';
import { paymentsMode } from '@/lib/payments';
import { verifyManualPayment, rejectManualPayment, matchStatement, rotatePaymentToken } from '@/app/actions/admin';
import { siteUrl } from '@/lib/site-url';

export const dynamic = 'force-dynamic';

/**
 * The money desk: what is waiting for a human, what the phone forwarded, and the one box that
 * takes a pasted bKash/Nagad statement. Everything that can be matched is matched before it
 * reaches this page.
 */
export default async function AdminPayments() {
  const [queue, inbox, token, site] = await Promise.all([
    listPaymentsToCheck({ limit: 50 }).catch(() => []),
    safeQ(
      `select i.*, p.tran_id, o.code, o.customer_name
         from payment_inbox i
         left join payments p on p.id = i.matched_payment_id
         left join orders o on o.id = p.order_id
        order by i.created_at desc limit 15`
    ).catch(() => []),
    getSmsToken().catch(() => null),
    siteUrl()
  ]);

  const webhook = token ? `${site}/api/payments/sms?token=${token}` : null;

  return (
    <div>
      <div className="between" style={{ marginBottom: 6 }}>
        <h3 style={{ margin: 0 }}>Payments</h3>
        <span className="muted small">
          {paymentsMode === 'manual' ? 'bKash / Nagad Send Money' : paymentsMode}
        </span>
      </div>

      <div className="panel" style={{ marginTop: 14 }}>
        <p className="panel-title">Automatic checking</p>
        <p className="muted small" style={{ marginTop: 0 }}>
          The shop phone already receives one SMS per bKash/Nagad payment. Forward those messages
          here and each order is released the moment the money lands — the amount must match, so a
          ৳10 message cannot clear a ৳12,000 order.
        </p>

        {webhook ? (
          <>
            <p className="label small-caps" style={{ marginTop: 14 }}>Forwarding URL</p>
            <pre style={{ fontSize: 12, overflowX: 'auto', background: 'rgba(255,255,255,0.04)', padding: 12, borderRadius: 6 }}>
{webhook}
            </pre>
            <p className="hint" style={{ marginBottom: 10 }}>
              Install any free SMS-forwarder app on the shop phone (for example “SMS Forwarder”),
              point it at this URL for the bKash and Nagad senders, and choose POST with the message
              as the body. The token is the password — do not post this URL anywhere public.
            </p>
            <form action={rotatePaymentToken}>
              <button className="btn outline small" type="submit">Rotate the token</button>
            </form>
          </>
        ) : (
          <p className="hint">The token could not be read. Run the database migrations.</p>
        )}
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        <p className="panel-title">Paste a statement</p>
        <p className="muted small" style={{ marginTop: 0 }}>
          Copy the TrxID list out of the bKash/Nagad statement — one payment per line, e.g.{' '}
          <code>9F7A2KD10X 150</code>. Every line that matches an unpaid order is released.
        </p>
        <form action={matchStatement} className="stack">
          <textarea
            name="statement"
            rows={5}
            placeholder={'9F7A2KD10X 150\nXK29FJ30Q1 400'}
            style={{ fontFamily: 'monospace', fontSize: 13 }}
          />
          <button className="btn small" type="submit" style={{ alignSelf: 'flex-start' }}>
            Check these TrxIDs
          </button>
        </form>
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        <div className="between" style={{ marginBottom: 10 }}>
          <p className="panel-title" style={{ margin: 0 }}>Waiting for a person · {queue.length}</p>
          <span className="muted small">TrxID does not match, or nothing was forwarded</span>
        </div>

        {queue.length === 0 ? (
          <p className="muted small" style={{ margin: 0 }}>Nothing waiting. Every payment is matched.</p>
        ) : (
          <div className="stack" style={{ gap: 12 }}>
            {queue.map(p => (
              <div key={p.id} style={{ borderTop: '1px solid var(--line)', paddingTop: 10 }}>
                <div className="kv">
                  <span>
                    <b>{taka(p.amount)}</b> · {p.method || p.provider}
                    <span className="muted small" style={{ display: 'block' }}>
                      {p.code} · {p.customer_name} · {p.customer_phone}
                    </span>
                  </span>
                  <b style={{ letterSpacing: 1 }}>{p.gateway_ref || '—'}</b>
                </div>
                <div className="row" style={{ gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                  <form action={verifyManualPayment}>
                    <input type="hidden" name="tran_id" value={p.tran_id} />
                    <input type="hidden" name="order_id" value={p.order_id} />
                    <button className="btn small" type="submit">Money is in — release</button>
                  </form>
                  <form action={rejectManualPayment} className="row" style={{ gap: 6 }}>
                    <input type="hidden" name="tran_id" value={p.tran_id} />
                    <input type="hidden" name="order_id" value={p.order_id} />
                    <input name="reason" placeholder="reason" style={{ width: 130 }} />
                    <button className="btn outline small" type="submit">No match</button>
                  </form>
                  <Link href={`/admin/orders/${p.order_id}`} className="btn ghost small">Open order →</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        <p className="panel-title">Last messages seen</p>
        {inbox.length === 0 ? (
          <p className="muted small" style={{ margin: 0 }}>Nothing forwarded yet.</p>
        ) : (
          <table className="admin-table">
            <thead>
              <tr><th>When</th><th>TrxID</th><th>Amount</th><th>From</th><th>Outcome</th></tr>
            </thead>
            <tbody>
              {inbox.map(row => (
                <tr key={row.id}>
                  <td className="muted small">{new Date(row.created_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                  <td>{row.trx_id || '—'}</td>
                  <td>{row.amount ? taka(row.amount) : '—'}</td>
                  <td className="muted small">{row.sender_number || '—'}</td>
                  <td>
                    <span className={`pill ${row.matched ? 'good' : 'warn'}`}>{row.matched ? 'matched' : 'not matched'}</span>
                    {row.note ? <span className="muted small" style={{ display: 'block' }}>{row.note}</span> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <p className="hint" style={{ marginTop: 16 }}>
        Why not call bKash directly? Their payment API needs an approved merchant account with a
        trade licence and takes a percentage of every sale. Forwarding the shop&apos;s own receipt SMS
        gives the same result for nothing, and the amount check is what keeps it honest.
      </p>
    </div>
  );
}
