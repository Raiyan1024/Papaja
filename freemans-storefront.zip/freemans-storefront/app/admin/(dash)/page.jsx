import Link from 'next/link';
import { orderStats, listAllOrders, listPaymentsToCheck, listCancellationRequests } from '@/lib/orders';
import { catalogueStats } from '@/lib/catalogue';
import { safeQ } from '@/lib/db';
import { taka } from '@/lib/money';
import { verifyManualPayment, rejectManualPayment, decideCancellation } from '@/app/actions/admin';

export const dynamic = 'force-dynamic';

export default async function AdminHome() {
  const [stats, cat, orders, lowFabrics, movements, toCheck, cancellations] = await Promise.all([
    orderStats(),
    catalogueStats(),
    listAllOrders({ limit: 8 }),
    safeQ('select * from fabrics where active and yards_in_stock <= reorder_level order by yards_in_stock'),
    safeQ(`select m.*, f.colour, f.name from stock_movements m left join fabrics f on f.id = m.fabric_id order by m.created_at desc limit 8`),
    listPaymentsToCheck({ limit: 20 }).catch(() => []),
    listCancellationRequests().catch(() => [])
  ]);

  return (
    <>
      <div className="grid-4">
        {[
          ['Orders', stats.total, `${stats.open} open · ${stats.ready} ready`],
          ['Order value', taka(stats.value), `${taka(stats.outstanding)} outstanding`],
          ['Paid', stats.paid, 'orders settled'],
          ['Low fabric', cat.low_stock, 'bolts at or below reorder level']
        ].map(([label, value, note]) => (
          <div className="panel" key={label}>
            <p className="panel-title">{label}</p>
            <b style={{ fontFamily: 'var(--serif)', fontSize: 24 }}>{value}</b>
            <p className="hint" style={{ marginTop: 6 }}>{note}</p>
          </div>
        ))}
      </div>

      {cancellations.length ? (
        <div className="panel" style={{ marginTop: 22, borderColor: '#6b2b2b' }}>
          <div className="between" style={{ marginBottom: 12 }}>
            <h3 style={{ margin: 0 }}>Cancellations to answer · {cancellations.length}</h3>
            <span className="hint" style={{ margin: 0 }}>No is an answer too — the customer sees it either way</span>
          </div>
          <div className="stack" style={{ gap: 12 }}>
            {cancellations.map(order => (
              <div key={order.id} style={{ borderTop: '1px solid var(--line)', paddingTop: 10 }}>
                <div className="kv">
                  <span>
                    <Link href={`/admin/orders/${order.id}`} style={{ color: 'var(--blue)' }}><b>{order.code}</b></Link>
                    <span className="muted small" style={{ display: 'block' }}>
                      {order.customer_name} · {order.customer_phone} · {taka(order.total)}
                    </span>
                  </span>
                  <span className="small" style={{ maxWidth: 320, textAlign: 'right' }}>{order.cancel_reason || 'No reason given'}</span>
                </div>
                <div className="row" style={{ gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                  <form action={decideCancellation}>
                    <input type="hidden" name="id" value={order.id} />
                    <input type="hidden" name="decision" value="accepted" />
                    <button className="btn small" type="submit">Accept — cancel it</button>
                  </form>
                  <form action={decideCancellation} className="row" style={{ gap: 6 }}>
                    <input type="hidden" name="id" value={order.id} />
                    <input type="hidden" name="decision" value="rejected" />
                    <input name="note" placeholder="Why not (optional)" style={{ width: 190, padding: '5px 8px', fontSize: 12 }} />
                    <button className="btn ghost small" type="submit">Decline</button>
                  </form>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {toCheck.length ? (
        <div className="panel" style={{ marginTop: 22, borderColor: '#6b5a25' }}>
          <div className="between" style={{ marginBottom: 12 }}>
            <h3 style={{ margin: 0 }}>Payments to check · {toCheck.length}</h3>
            <span className="hint" style={{ margin: 0 }}>Money the customer says they have sent</span>
          </div>
          <div className="stack" style={{ gap: 12 }}>
            {toCheck.map(p => (
              <div key={p.id} style={{ borderTop: '1px solid var(--line)', paddingTop: 10 }}>
                <div className="kv">
                  <span>
                    <b>{taka(p.amount)}</b> · {p.method || p.provider}
                    <span className="muted small" style={{ display: 'block' }}>
                      {p.code} · {p.customer_name} · {p.customer_phone}
                    </span>
                  </span>
                  <b style={{ letterSpacing: 1 }}>{p.gateway_ref}</b>
                </div>
                <div className="row" style={{ gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                  <form action={verifyManualPayment}>
                    <input type="hidden" name="tran_id" value={p.tran_id} />
                    <input type="hidden" name="order_id" value={p.order_id} />
                    <button className="btn small" type="submit">Money is in — release</button>
                  </form>
                  <form action={rejectManualPayment} className="row" style={{ gap: 6 }}>
                    <input type="hidden" name="tran_id" value={p.tran_id} />
                    <input type="hidden" name="order_id" value={p.order_id} />
                    <input name="reason" placeholder="reason" style={{ width: 130 }} />
                    <button className="btn outline small" type="submit">No match</button>
                  </form>
                  <Link href={`/admin/orders/${p.order_id}`} className="btn ghost small">Open order →</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="split" style={{ marginTop: 26, alignItems: 'start', gap: 26 }}>
        <div>
          <div className="between" style={{ marginBottom: 10 }}>
            <h3>Latest orders</h3>
            <Link href="/admin/orders" className="btn ghost small">All orders →</Link>
          </div>
          <div className="panel" style={{ padding: 0 }}>
            <table className="table">
              <thead><tr><th>Order</th><th>Customer</th><th>Status</th><th className="num">Total</th></tr></thead>
              <tbody>
                {orders.length === 0 ? (
                  <tr><td colSpan={4} className="muted">No orders yet.</td></tr>
                ) : orders.map(order => (
                  <tr key={order.id}>
                    <td><Link href={`/admin/orders/${order.id}`} style={{ color: 'var(--blue)' }}>{order.code}</Link></td>
                    <td>{order.customer_name}<div className="muted small">{order.measurement_mode.replace('_', ' ')}</div></td>
                    <td><span className={`pill ${order.payment_status === 'paid' ? 'good' : 'warn'}`}>{order.status.replace('_', ' ')}</span></td>
                    <td className="num">{taka(order.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <aside>
          <h3 style={{ marginBottom: 10 }}>Fabric to reorder</h3>
          <div className="panel">
            {lowFabrics.length === 0 ? <p className="muted small" style={{ margin: 0 }}>Everything is above its reorder level.</p> : null}
            {lowFabrics.map(fabric => (
              <div className="kv" key={fabric.id}>
                <span className="row" style={{ gap: 8 }}>
                  <span className="swatch" style={{ background: fabric.colour_hex }} />
                  {fabric.colour} {fabric.name}
                </span>
                <span className="pill warn">{Number(fabric.yards_in_stock)} yd</span>
              </div>
            ))}
            <Link href="/admin/fabrics" className="btn outline small" style={{ marginTop: 12 }}>Manage stock</Link>
          </div>

          <h3 style={{ margin: '24px 0 10px' }}>Stock movements</h3>
          <div className="panel">
            {movements.length === 0 ? <p className="muted small" style={{ margin: 0 }}>No movements yet.</p> : null}
            {movements.map(m => (
              <div className="kv" key={m.id}>
                <span className="small muted">{new Date(m.created_at).toLocaleDateString()} · {m.reason}</span>
                <span className={Number(m.delta) < 0 ? '' : ''} style={{ color: Number(m.delta) < 0 ? 'var(--bad)' : 'var(--good)' }}>
                  {Number(m.delta) > 0 ? '+' : ''}{Number(m.delta)}
                </span>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </>
  );
}
