import Link from 'next/link';
import { login } from '@/app/actions/auth';
import { currentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { hasDb } from '@/lib/db';
import { SHOP_NAME } from '@/lib/contact';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Shop sign-in — ' + SHOP_NAME };

export default async function AdminLoginPage({ searchParams }) {
  const sp = await searchParams;
  const user = await currentUser();
  if (user?.role === 'admin') redirect('/admin');

  return (
    <section className="wrap tight" style={{ maxWidth: 460 }}>
      <p className="eyebrow">Shop admin</p>
      <h1 style={{ fontSize: 30 }}>Behind the counter</h1>
      <p className="muted" style={{ marginTop: 10 }}>
        This sign-in is for the shop owner. Customers order without an account — no sign-up anywhere on the site.
      </p>

      {sp?.error ? <div className="alert bad" style={{ marginTop: 18 }}>{sp.error}</div> : null}

      <form action={login} className="panel stack" style={{ gap: 16, marginTop: 20 }}>
        <div className="field">
          <label htmlFor="login-email">Email</label>
          <input id="login-email" name="email" type="email" autoComplete="username" required />
        </div>
        <div className="field">
          <label htmlFor="login-password">Password</label>
          <input id="login-password" name="password" type="password" autoComplete="current-password" required />
        </div>
        <button className="btn" type="submit">Sign in</button>
        {!hasDb() ? <p className="hint">No database connected — run <code>npm run db:setup</code> first.</p> : null}
      </form>

      <p className="hint" style={{ marginTop: 16 }}>
        Forgotten the password? Ask whoever set the shop up to run
        {' '}<code>node scripts/set-admin-password.js</code>{' '}on the server. It is never printed here.
      </p>
      <p style={{ marginTop: 12 }}>
        <Link href="/" className="btn ghost small">Back to the shop</Link>
      </p>
    </section>
  );
}
