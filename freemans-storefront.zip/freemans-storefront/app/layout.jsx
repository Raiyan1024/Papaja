import './globals.css';
import SiteHeader from '@/components/site-header';
import SiteFooter from '@/components/site-footer';
import FloatingActions from '@/components/floating-actions';
import { LangProvider } from '@/components/lang-provider';
import { hasDb } from '@/lib/db';
import { getLang } from '@/lib/lang';
import { cartDetails } from '@/lib/cart';
import { SHOP_NAME } from '@/lib/contact';
import { storeJsonLd, JsonLd, siteBase } from '@/lib/seo';

const SITE_TITLE = SHOP_NAME + ' — made-to-measure suits, blazers and uniforms in Dhaka';
const SITE_DESCRIPTION =
  'Tailored menswear in Dhaka: suits, blazers, trousers, shirts and scout or school uniforms, cut to your own measurements. Order online without an account, or book a home measuring visit for ৳150 inside Dhaka.';

export const metadata = {
  metadataBase: new URL(siteBase()),
  title: {
    default: SITE_TITLE,
    template: `%s — ${SHOP_NAME}`
  },
  description: SITE_DESCRIPTION,
  applicationName: SHOP_NAME,
  keywords: [
    'tailor in Dhaka', 'tailors Dhaka', 'custom suit Dhaka', 'made to measure suit Bangladesh',
    'blazer tailoring Dhaka', 'scout uniform Dhaka', 'school uniform tailor Dhaka',
    'home measuring visit Dhaka', 'menswear Dhaka', 'দর্জি ঢাকা', 'স্যুট বানানো ঢাকা', 'ইউনিফর্ম ঢাকা'
  ],
  authors: [{ name: SHOP_NAME }],
  creator: SHOP_NAME,
  publisher: SHOP_NAME,
  alternates: {
    canonical: '/',
    languages: { 'en-BD': '/', 'bn-BD': '/' }
  },
  openGraph: {
    type: 'website',
    siteName: SHOP_NAME,
    locale: 'en_BD',
    alternateLocale: ['bn_BD'],
    title: SITE_TITLE,
    description: SITE_DESCRIPTION,
    url: '/',
    images: [{ url: '/products/suit-navy.jpg', width: 928, height: 1152, alt: 'A navy two-piece suit cut in Dhaka' }]
  },
  twitter: {
    card: 'summary_large_image',
    title: SITE_TITLE,
    description: SITE_DESCRIPTION,
    images: ['/products/suit-navy.jpg']
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 }
  },
  category: 'shopping',
  formatDetection: { telephone: true, address: true }
};

export default async function RootLayout({ children }) {
  const lang = await getLang();
  const cart = await cartDetails().catch(() => ({ count: 0, subtotal: 0 }));

  return (
    <html lang={lang === 'bn' ? 'bn-BD' : 'en-BD'}>
      <body>
        <JsonLd data={storeJsonLd()} />
        <LangProvider lang={lang}>
          <SiteHeader />
          {!hasDb() ? (
            <div className="wrap" style={{ paddingTop: 18 }}>
              <div className="alert warn">
                <b>No database connected.</b> Set <code>DATABASE_URL</code> in your environment and run{' '}
                <code>npm run db:setup</code> — the catalogue, prices and stock load from Postgres.
              </div>
            </div>
          ) : null}
          <main>{children}</main>
          <SiteFooter />
          <FloatingActions count={cart.count} subtotal={cart.subtotal} />
        </LangProvider>
      </body>
    </html>
  );
}
