import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getPaymentByTranId } from '@/lib/orders';
import { submitManualPayment, completeMockPayment } from '@/app/actions/orders';
import { taka } from '@/lib/money';
import { receivingNumber, METHOD_LABEL } from '@/lib/payments/manual';
import { paymentsMode } from '@/lib/payments';
import { telLink, PHONE_PRETTY } from '@/lib/contact';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import ManualPaymentForm from '@/components/manual-payment-form';
import PaymentPanel from '@/components/payment-panel';

export const dynamic = 'force-dynamic';

/**
 * Where the customer is told exactly how to send the money.
 * No gateway, no merchant account: their own bKash/Nagad app, the shop's number, and the
 * order code as the reference. Then they paste the TrxID and the shop checks it.
 */
export default async function PaymentPage({ params }) {
  const { tranId } = await params;
  const [payment, lang] = await Promise.all([getPaymentByTranId(tranId), getLang()]);
  if (!payment) notFound();

  const bn = lang === 'bn';
  const method = payment.method || (payment.provider || '').replace('_manual', '') || 'bkash';
  const isCard = method === 'card';
  const number = receivingNumber(method) || receivingNumber('bkash');
  const alreadySent = payment.status === 'submitted';
  const paid = payment.status === 'paid';
  const rejected = payment.status === 'rejected';

  if (paymentsMode === 'mock') {
    return (
      <section className="wrap tight" style={{ maxWidth: 620, margin: '0 auto' }}>
        <p className="eyebrow">{bn ? 'পেমেন্ট · টেস্ট মোড' : 'Payment · test mode'}</p>
        <h1 style={{ fontSize: 34 }}>{taka(payment.amount)}</h1>
        <p className="muted" style={{ marginTop: 10 }}>
          {bn
            ? `অর্ডার ${payment.code} · ${payment.customer_name}। এটা টেস্ট গেটওয়ে — কোনো টাকা যাচ্ছে না।`
            : `Order ${payment.code} · ${payment.customer_name}. This is the test gateway — no money moves.`}
        </p>
        <form action={completeMockPayment} className="row" style={{ marginTop: 24, gap: 12 }}>
          <input type="hidden" name="tran_id" value={payment.tran_id} />
          <input type="hidden" name="code" value={payment.code} />
          <button className="btn" name="outcome" value="success" type="submit">
            {bn ? `৳${payment.amount} পরিশোধ` : `Pay ${taka(payment.amount)}`}
          </button>
          <button className="btn outline" name="outcome" value="cancel" type="submit">
            {bn ? 'বাতিল' : 'Cancel'}
          </button>
        </form>
        <p className="hint" style={{ marginTop: 20 }}>{payment.tran_id}</p>
      </section>
    );
  }

  return (
    <section className="wrap tight" style={{ maxWidth: 720 }}>
      <p className="eyebrow">
        {bn ? 'পেমেন্ট' : 'Payment'} · {payment.code}
      </p>

      <div className="between" style={{ alignItems: 'flex-start', gap: 20 }}>
        <h1 style={{ fontSize: 'clamp(26px, 3vw, 38px)' }}>
          {paid
            ? bn ? 'টাকা পেয়ে গেছি।' : 'Payment received.'
            : alreadySent
              ? bn ? 'আপনার পেমেন্ট দেখছি।' : 'We are checking your payment.'
              : bn ? `৳${payment.amount} পাঠান।` : `Send ${taka(payment.amount)}.`}
        </h1>
        <span className={`pill ${paid ? 'good' : rejected ? 'bad' : 'warn'}`}>
          {paid ? (bn ? 'পরিশোধিত' : 'Paid') : rejected ? (bn ? 'মেলেনি' : 'Not matched') : alreadySent ? (bn ? 'যাচাই চলছে' : 'Checking') : (bn ? 'বাকি' : 'Due')}
        </span>
      </div>

      {paid ? (
        <div className="alert good" style={{ marginTop: 18 }}>
          {bn ? 'টাকা এসেছে, অর্ডার কনফার্ম।' : 'The money is in and the order is confirmed.'}{' '}
          <Link href={`/order/${payment.code}`}>{bn ? 'অর্ডার দেখুন' : 'See the order'} →</Link>
        </div>
      ) : null}

      {alreadySent ? (
        <div className="alert warn" style={{ marginTop: 18 }}>
          {bn
            ? `আপনার TrxID (${payment.gateway_ref || '—'}) পেয়েছি। আমরা বিকাশ/নগদ স্টেটমেন্টে মিলিয়ে দেখে অর্ডার কনফার্ম করব — সাধারণত ৩০ মিনিটের মধ্যে।`
            : `We have your TrxID (${payment.gateway_ref || '—'}). We match it against the bKash/Nagad statement and confirm the order — usually within 30 minutes.`}
        </div>
      ) : null}

      {rejected ? (
        <div className="alert warn" style={{ marginTop: 18 }}>
          {bn
            ? 'এই TrxID-টা আমাদের স্টেটমেন্টে মেলেনি। নিচে আবার দিতে পারেন, অথবা হোয়াটসঅ্যাপে স্ক্রিনশট পাঠান।'
            : 'That TrxID did not match our statement. You can enter it again below, or send us a screenshot on WhatsApp.'}
        </div>
      ) : null}

      {!paid && !alreadySent ? (
        <>
          <div className="panel" style={{ marginTop: 18 }}>
            <p className="panel-title">
              {isCard
                ? bn ? 'কার্ড পেমেন্ট' : 'Card payment'
                : bn ? `${METHOD_LABEL[method]} দিয়ে সেন্ড মানি` : `Send money with ${METHOD_LABEL[method]}`}
            </p>

            <PaymentPanel
              tranId={payment.tran_id}
              code={payment.code}
              method={method}
              amount={Number(payment.amount)}
              number={number}
              lang={lang}
            />
          </div>

          {!isCard ? (
            <>
              <p className="label small-caps" style={{ marginTop: 22 }}>
                {bn ? 'টাকা পাঠিয়েছেন? TrxID দিন' : 'Money sent? Give us the TrxID'}
              </p>
              <ManualPaymentForm
                action={submitManualPayment}
                tranId={payment.tran_id}
                code={payment.code}
                lang={lang}
              />
            </>
          ) : null}
        </>
      ) : null}

      <div className="row" style={{ marginTop: 22, gap: 14, flexWrap: 'wrap' }}>
        <Link href={`/order/${payment.code}`} className="btn outline small">
          {bn ? 'অর্ডারের অবস্থা দেখুন' : 'See the order status'} →
        </Link>
        <a href={telLink()} className="btn ghost small">{t(lang, 'common.call')} · {PHONE_PRETTY}</a>
      </div>
    </section>
  );
}
