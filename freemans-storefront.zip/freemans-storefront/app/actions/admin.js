'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { updateOrderStatus, setPaymentStatus } from '@/lib/orders';
import { guessColour } from '@/lib/colours';

const int = (value, fallback = 0) => {
  const n = Math.round(Number(value));
  return Number.isFinite(n) ? n : fallback;
};
const num = (value, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};

export async function saveVariant(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const price = Math.max(0, int(formData.get('price')));
  const stock = Math.max(0, int(formData.get('stock')));
  const active = formData.get('active') === 'on';

  const before = await q('select price, stock from product_variants where id = $1', [id]);
  if (!before.length) redirect('/admin/products');

  await q('update product_variants set price = $2, stock = $3, active = $4 where id = $1', [id, price, stock, active]);

  const delta = stock - Number(before[0].stock);
  if (delta !== 0) {
    await q(`insert into stock_movements (variant_id, delta, reason) values ($1,$2,'admin adjustment')`, [id, delta]);
  }
  revalidatePath('/admin/products');
}

export async function saveProduct(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const spec = formData.get('spec');
  await q(
    'update products set name = $2, summary = $3, description = $4, active = $5, spec = coalesce($6, spec) where id = $1',
    [
      id,
      String(formData.get('name') || '').slice(0, 120),
      String(formData.get('summary') || '').slice(0, 200),
      String(formData.get('description') || '').slice(0, 2000),
      formData.get('active') === 'on',
      spec === null ? null : String(spec).slice(0, 160)
    ]
  );
  revalidatePath('/admin/products');
}

export async function saveFabric(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const price = Math.max(0, int(formData.get('price_per_yard')));
  const yards = Math.max(0, num(formData.get('yards_in_stock')));
  const reorder = Math.max(0, num(formData.get('reorder_level')));

  const before = await q('select yards_in_stock from fabrics where id = $1', [id]);
  if (!before.length) redirect('/admin/fabrics');

  await q(
    `update fabrics set price_per_yard = $2, yards_in_stock = $3, reorder_level = $4, active = $5, updated_at = now()
      where id = $1`,
    [id, price, yards, reorder, formData.get('active') === 'on']
  );

  const delta = yards - Number(before[0].yards_in_stock);
  if (delta !== 0) {
    await q(`insert into stock_movements (fabric_id, delta, reason) values ($1,$2,'admin adjustment')`, [id, delta]);
  }
  revalidatePath('/admin/fabrics');
}

/** Quick stock take: + or − yards without opening the edit row. */
export async function adjustFabricStock(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const delta = num(formData.get('delta'));
  if (!delta) redirect('/admin/fabrics');
  await q('update fabrics set yards_in_stock = greatest(0, yards_in_stock + $2), updated_at = now() where id = $1', [id, delta]);
  await q(`insert into stock_movements (fabric_id, delta, reason) values ($1,$2,$3)`, [id, delta, String(formData.get('reason') || 'adjustment').slice(0, 80)]);
  revalidatePath('/admin/fabrics');
}

export async function changeOrderStatus(formData) {
  await requireAdmin();
  await updateOrderStatus(int(formData.get('id')), String(formData.get('status')));
  revalidatePath('/admin/orders');
  revalidatePath(`/admin/orders/${formData.get('id')}`);
}

export async function changePaymentStatus(formData) {
  await requireAdmin();
  await setPaymentStatus(int(formData.get('id')), String(formData.get('status')));
  revalidatePath('/admin/orders');
  revalidatePath(`/admin/orders/${formData.get('id')}`);
}

/**
 * The shopkeeper has the bKash/Nagad statement open, sees the TrxID, and releases the order.
 * This is the only place a manual payment becomes money.
 */
export async function verifyManualPayment(formData) {
  const admin = await requireAdmin();
  const { approveManualPayment } = await import('@/lib/orders');
  const tranId = String(formData.get('tran_id'));
  const id = String(formData.get('order_id') || '');
  await approveManualPayment({ tranId, checkedBy: admin?.email || 'admin' });
  revalidatePath('/admin');
  revalidatePath('/admin/orders');
  if (id) revalidatePath(`/admin/orders/${id}`);
}

export async function rejectManualPayment(formData) {
  const admin = await requireAdmin();
  const { rejectManualPayment: reject } = await import('@/lib/orders');
  const tranId = String(formData.get('tran_id'));
  const id = String(formData.get('order_id') || '');
  await reject({
    tranId,
    checkedBy: admin?.email || 'admin',
    reason: String(formData.get('reason') || '').slice(0, 200) || 'Not found in the statement'
  });
  revalidatePath('/admin');
  revalidatePath('/admin/orders');
  if (id) revalidatePath(`/admin/orders/${id}`);
}

/** Paste a chunk of the bKash/Nagad statement; every line that matches an order is released. */
export async function matchStatement(formData) {
  await requireAdmin();
  const { parseStatement } = await import('@/lib/payments/parse');
  const { matchIncoming } = await import('@/lib/payments/auto');
  const rows = parseStatement(String(formData.get('statement') || ''));
  let paid = 0;
  let refused = 0;
  for (const row of rows) {
    const result = await matchIncoming({ ...row, source: 'statement' });
    if (result.outcome === 'paid') paid += 1;
    else refused += 1;
  }
  revalidatePath('/admin');
  revalidatePath('/admin/payments');
  return { rows: rows.length, paid, refused };
}

export async function rotatePaymentToken() {
  await requireAdmin();
  const { rotateSmsToken } = await import('@/lib/payments/auto');
  await rotateSmsToken();
  revalidatePath('/admin/payments');
}

/* ---------------------------------------------------------------------------------------
 * Adding a new line of clothing from the admin panel — a new design, with its own photos,
 * colours, prices and stock. No code, no developer.
 * ------------------------------------------------------------------------------------- */

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 60);
}

async function uniqueSlug(base) {
  const root = slugify(base) || `style-${Date.now().toString(36)}`;
  let slug = root;
  for (let i = 2; i < 60; i += 1) {
    const clash = await q('select 1 from products where slug = $1', [slug]);
    if (!clash.length) return slug;
    slug = `${root}-${i}`;
  }
  return `${root}-${Date.now().toString(36)}`;
}

function parseVariants(raw) {
  let rows;
  try {
    rows = typeof raw === 'string' ? JSON.parse(raw) : raw;
  } catch {
    return [];
  }
  if (!Array.isArray(rows)) return [];
  return rows
    .map(row => ({
      colour: String(row.colour || '').trim().slice(0, 40),
      colour_hex: /^#[0-9a-f]{6}$/i.test(String(row.colour_hex || '')) ? row.colour_hex : guessColour(row.colour),
      design: String(row.design || '').trim().slice(0, 60) || 'House style',
      price: Math.max(0, int(row.price)),
      stock: Math.max(0, int(row.stock)),
      image: String(row.image || '').trim().slice(0, 300) || null,
      fabric_id: int(row.fabric_id) || null
    }))
    .filter(row => row.colour && row.price > 0);
}

/** A new product (a "style"), with its photograph, its colours and its first prices. */
export async function createProduct(prevState, formData) {
  await requireAdmin();

  const categoryId = int(formData.get('category_id'));
  const name = String(formData.get('name') || '').trim().slice(0, 120);
  const summary = String(formData.get('summary') || '').trim().slice(0, 200);
  const description = String(formData.get('description') || '').trim().slice(0, 2000);
  const spec = String(formData.get('spec') || '').trim().slice(0, 160);
  const image = String(formData.get('image') || '').trim().slice(0, 300) || null;
  const variants = parseVariants(formData.get('variants'));

  if (!categoryId) return { error: 'Pick which line this piece belongs to.' };
  if (!name) return { error: 'Give the piece a name — the name is what the customer reads.' };
  if (!variants.length) return { error: 'Add at least one colour and design with a price.' };

  const category = await q('select id from categories where id = $1', [categoryId]);
  if (!category.length) return { error: 'That line of the shop does not exist any more.' };

  const slug = await uniqueSlug(name);
  const product = (
    await q(
      `insert into products (slug, category_id, name, summary, description, image, spec, active, position)
       values ($1,$2,$3,$4,$5,$6,$7,true,
         coalesce((select max(position) + 1 from products where category_id = $2), 0))
       returning id`,
      [slug, categoryId, name, summary || null, description || null, image, spec || null]
    )
  )[0];

  for (const row of variants) {
    await q(
      `insert into product_variants (product_id, colour, colour_hex, design, fabric_id, price, stock, image, active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,true)
       on conflict (product_id, colour, design) do nothing`,
      [product.id, row.colour, row.colour_hex, row.design, row.fabric_id, row.price, row.stock, row.image]
    );
  }

  if (image) await q('update product_images set product_id = $2 where key = $1', [image.split('/').pop(), product.id]);

  revalidatePath('/admin/products');
  revalidatePath(`/${(await q('select slug from categories where id = $1', [categoryId]))[0].slug}`);
  revalidatePath('/');
  redirect(`/admin/products?open=${product.id}&created=1`);
}

/** Add one more colour × design to a product that already exists. */
export async function addVariant(formData) {
  await requireAdmin();
  const productId = int(formData.get('product_id'));
  const colour = String(formData.get('colour') || '').trim().slice(0, 40);
  const design = String(formData.get('design') || '').trim().slice(0, 60) || 'House style';
  const price = Math.max(0, int(formData.get('price')));
  const stock = Math.max(0, int(formData.get('stock')));
  const hexRaw = String(formData.get('colour_hex') || '');
  const colourHex = /^#[0-9a-f]{6}$/i.test(hexRaw) ? hexRaw : guessColour(colour);
  const image = String(formData.get('image') || '').trim().slice(0, 300) || null;

  if (!productId || !colour || price <= 0) redirect(`/admin/products${productId ? `?open=${productId}` : ''}`);

  await q(
    `insert into product_variants (product_id, colour, colour_hex, design, price, stock, image, active)
     values ($1,$2,$3,$4,$5,$6,$7,true)
     on conflict (product_id, colour, design)
     do update set price = excluded.price, stock = excluded.stock, image = coalesce(excluded.image, product_variants.image), active = true`,
    [productId, colour, colourHex, design, price, stock, image]
  );

  if (image) await q('update product_images set product_id = $2 where key = $1', [image.split('/').pop(), productId]);

  revalidatePath('/admin/products');
  revalidatePath('/');
  redirect(`/admin/products?open=${productId}&added=1`);
}

/**
 * The same job as addVariant, but from the "Add a design" panel, where the screen should show
 * what went wrong instead of jumping away. Returns { error } when something is missing.
 */
export async function addVariantState(prevState, formData) {
  await requireAdmin();
  const productId = int(formData.get('product_id'));
  const colour = String(formData.get('colour') || '').trim().slice(0, 40);
  const design = String(formData.get('design') || '').trim().slice(0, 60) || 'House style';
  const price = Math.max(0, int(formData.get('price')));
  const stock = Math.max(0, int(formData.get('stock')));
  const image = String(formData.get('image') || '').trim().slice(0, 300) || null;

  if (!productId) return { error: 'Pick which piece this design goes into.' };
  if (!colour) return { error: 'The colour is missing — that is the word the customer reads on the chip.' };
  if (price <= 0) return { error: 'A price is the one thing it cannot go without.' };

  const product = await q('select id, slug from products where id = $1', [productId]);
  if (!product.length) return { error: 'That piece does not exist any more. Reload the page.' };

  const hexRaw = String(formData.get('colour_hex') || '');
  const colourHex = /^#[0-9a-f]{6}$/i.test(hexRaw) ? hexRaw : guessColour(colour);

  await q(
    `insert into product_variants (product_id, colour, colour_hex, design, price, stock, image, active)
     values ($1,$2,$3,$4,$5,$6,$7,true)
     on conflict (product_id, colour, design)
     do update set price = excluded.price, stock = excluded.stock, image = coalesce(excluded.image, product_variants.image), active = true`,
    [productId, colour, colourHex, design, price, stock, image]
  );

  if (image) await q('update product_images set product_id = $2 where key = $1', [image.split('/').pop(), productId]);

  revalidatePath('/admin/products');
  revalidatePath('/admin/designs');
  revalidatePath('/');
  revalidatePath(`/product/${product[0].slug}`);
  redirect(`/admin/designs?product=${productId}&added=1`);
}

/** Swap the photograph of a whole product (the picture shown on the cards). */
export async function setProductImage(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const image = String(formData.get('image') || '').trim().slice(0, 300) || null;
  if (!id) redirect('/admin/products');
  await q('update products set image = $2 where id = $1', [id, image]);
  if (image) await q('update product_images set product_id = $2 where key = $1', [image.split('/').pop(), id]);
  revalidatePath('/admin/products');
  revalidatePath('/');
  redirect(`/admin/products?open=${id}&saved=1`);
}

/** Swap the photograph of one colour × design. */
export async function setVariantImage(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  const image = String(formData.get('image') || '').trim().slice(0, 300) || null;
  const rows = await q('select product_id from product_variants where id = $1', [id]);
  if (!rows.length) redirect('/admin/products');
  await q('update product_variants set image = $2 where id = $1', [id, image]);
  if (image) await q('update product_images set variant_id = $2 where key = $1', [image.split('/').pop(), id]);
  revalidatePath('/admin/products');
  redirect(`/admin/products?open=${rows[0].product_id}&saved=1`);
}

/** Take a colour × design off the shelf — kept in the database so old orders still read. */
export async function hideVariant(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  await q('update product_variants set active = false where id = $1', [id]);
  revalidatePath('/admin/products');
  redirect(`/admin/products?open=${int(formData.get('product_id')) || ''}`);
}

/** Hide or show a whole style. Nothing is deleted, so past orders keep their history. */
export async function toggleProduct(formData) {
  await requireAdmin();
  const id = int(formData.get('id'));
  await q('update products set active = not active where id = $1', [id]);
  revalidatePath('/admin/products');
  revalidatePath('/');
  redirect(`/admin/products?open=${id}`);
}

/* ---------------------------------------------------------------------------------------
 * The customer asked to cancel. The shopkeeper accepts or declines, once.
 * ------------------------------------------------------------------------------------- */
export async function decideCancellation(formData) {
  const admin = await requireAdmin();
  const id = int(formData.get('id'));
  const decision = String(formData.get('decision') || '');
  const note = String(formData.get('note') || '').slice(0, 300) || null;
  const { decideOrderCancellation } = await import('@/lib/orders');
  if (!['accepted', 'rejected'].includes(decision)) redirect('/admin/orders');
  await decideOrderCancellation({ id, decision, note, by: admin?.email || 'admin' });
  revalidatePath('/admin/orders');
  revalidatePath(`/admin/orders/${id}`);
  revalidatePath('/admin');
}
