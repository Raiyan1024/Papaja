'use server';

import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { cartDetails } from '@/lib/cart';
import {
  createOrder,
  createPaymentIntent,
  markPaymentPaid,
  markPaymentFailed,
  markPaymentSubmitted
} from '@/lib/orders';
import { normaliseTrxId, normaliseSenderNumber } from '@/lib/payments/manual';
import { startPayment, paymentsMode, methodProvider } from '@/lib/payments';
import { siteUrl } from '@/lib/site-url';

function clean(value, max = 400) {
  return String(value || '').trim().slice(0, max);
}

export async function placeOrder(prevState, formData) {
  const cart = await cartDetails();

  if (!cart.items.length) return { error: 'Your order is empty. Add a piece to it first.' };

  const form = {
    customer_name: clean(formData.get('customer_name'), 80),
    customer_phone: clean(formData.get('customer_phone'), 30),
    customer_email: clean(formData.get('customer_email'), 120),
    area: clean(formData.get('area'), 80),
    delivery_zone: clean(formData.get('delivery_zone'), 200) || 'inside_dhaka',
    address: clean(formData.get('address'), 200),
    measurement_mode: clean(formData.get('measurement_mode'), 20) || 'home_visit',
    measurement_note: clean(formData.get('measurement_note'), 400),
    wants_discussion: formData.get('wants_discussion') === 'on',
    discussion_topic: clean(formData.get('discussion_topic'), 400),
    cloth_choice: clean(formData.get('cloth_choice'), 160),
    notes: clean(formData.get('notes'), 400),
    payment_option: clean(formData.get('payment_option'), 10) || 'advance',
    payment_method: ['bkash', 'nagad', 'card'].includes(clean(formData.get('payment_method'), 10))
      ? clean(formData.get('payment_method'), 10)
      : 'bkash',
    item_brief: clean(formData.get('item_brief'), 300)
  };

  const errors = {};
  if (!form.customer_name) errors.customer_name = 'Tell us your name.';
  if (!/^[+\d][\d\s-]{7,}$/.test(form.customer_phone)) errors.customer_phone = 'A phone number we can reach you on.';
  if (form.measurement_mode === 'home_visit' && !form.address) errors.address = 'Where should our person come?';

  if (Object.keys(errors).length) {
    return { error: 'Some details are missing.', errors, values: form };
  }

  let order;
  try {
    order = await createOrder({ user: null, form });
  } catch (error) {
    return { error: error.message, errors: {}, values: form };
  }

  const provider = paymentsMode === 'mock' ? 'mock' : methodProvider(order);
  const intent = await createPaymentIntent(order, { provider, method: form.payment_method });

  let redirectUrl;
  try {
    const started = await startPayment({ order, tranId: intent.tran_id, siteUrl: await siteUrl() });
    redirectUrl = started.redirectUrl;
  } catch (error) {
    // The order exists but the gateway refused the session. Say so, keep the order,
    // and leave the payment row marked failed so the admin can see what happened.
    const { markPaymentFailed } = await import('@/lib/orders');
    await markPaymentFailed({ tranId: intent.tran_id, status: 'failed', payload: { error: error.message } });
    return {
      error: `The payment page could not be opened (${error.message}). Your order is saved — reply on WhatsApp and we will send a payment link.`,
      errors: {},
      values: form
    };
  }

  revalidatePath('/cart');
  revalidatePath('/order');
  redirect(redirectUrl);
}

/** Called from the mock gateway page. In live mode the gateway calls /api/payments/callback instead. */
export async function completeMockPayment(formData) {
  const tranId = String(formData.get('tran_id'));
  const outcome = String(formData.get('outcome'));
  const code = String(formData.get('code'));

  if (outcome === 'success') {
    await markPaymentPaid({ tranId, valId: `mock-${tranId}`, payload: { mock: true, at: new Date().toISOString() }, provider: 'mock' });
  } else {
    await markPaymentFailed({ tranId, status: 'cancelled', payload: { cancelled: true } });
  }
  redirect(`/order/${code}?paid=${outcome === 'success' ? '1' : '0'}`);
}

export async function retryPayment(formData) {
  const { getOrderByCode } = await import('@/lib/orders');
  const order = await getOrderByCode(String(formData.get('code')));
  if (!order) redirect('/order');
  // The customer picks the method here: bKash, Nagad or card. Whichever button was pressed wins.
  const picked = String(formData.get('method') || '');
  const method = ['bkash', 'nagad', 'card'].includes(picked) ? picked : order.payment_method || 'bkash';
  const intent = await createPaymentIntent(order, {
    provider: paymentsMode === 'mock' ? 'mock' : `${method}_manual`,
    method
  });
  const { redirectUrl } = await startPayment({ order, tranId: intent.tran_id, siteUrl: await siteUrl() });
  redirect(redirectUrl);
}

/**
 * The customer sent the money from their bKash/Nagad app and pasted the TrxID here.
 * Nothing is marked paid — the shop checks its own statement first. The TrxID is unique
 * across payments, so one screenshot cannot release two orders.
 */
export async function submitManualPayment(prevState, formData) {
  const tranId = String(formData.get('tran_id') || '');
  const code = String(formData.get('code') || '');
  const { getPaymentByTranId } = await import('@/lib/orders');
  const payment = await getPaymentByTranId(tranId);
  if (!payment) return { error: 'We could not find that payment. Refresh the page and try again.' };

  const trxId = normaliseTrxId(formData.get('trx_id'));
  if (!trxId) {
    return {
      error:
        'A bKash or Nagad TrxID is 8–12 letters and numbers, e.g. 9F7A2KD10X. Copy it from the confirmation SMS.'
    };
  }
  const sender = normaliseSenderNumber(formData.get('sender_number'));

  try {
    const updated = await markPaymentSubmitted({
      tranId,
      trxId,
      senderNumber: sender,
      note: String(formData.get('payer_note') || '').slice(0, 200) || null
    });
    if (!updated) {
      return { error: 'That payment has already been sent for checking, or it was closed. Reply on WhatsApp and we will sort it out.' };
    }
  } catch (error) {
    const duplicate = /duplicate key|unique/i.test(String(error.message));
    return {
      error: duplicate
        ? 'That TrxID is already used on another order. Check the number, or WhatsApp us with a screenshot.'
        : `We could not save that (${error.message}). WhatsApp us the TrxID and we will mark it by hand.`
    };
  }

  revalidatePath('/admin');
  redirect(`/order/${code}?submitted=1`);
}

/** The customer asks to cancel. The shop accepts or declines — the answer shows on the order. */
export async function requestOrderCancellation(prevState, formData) {
  const code = String(formData.get('code') || '');
  const reason = String(formData.get('reason') || '').slice(0, 300);
  const { requestCancellation } = await import('@/lib/orders');
  const updated = await requestCancellation({ code, reason });
  if (!updated) {
    return {
      error:
        'This order can no longer be cancelled from here — it is either already cancelled, delivered, or a request is already waiting. Call or WhatsApp us.'
    };
  }
  revalidatePath(`/order/${code}`);
  revalidatePath('/admin/orders');
  redirect(`/order/${code}?cancellation=requested`);
}

export async function withdrawOrderCancellation(formData) {
  const code = String(formData.get('code') || '');
  const { withdrawCancellation } = await import('@/lib/orders');
  await withdrawCancellation({ code });
  revalidatePath(`/order/${code}`);
  redirect(`/order/${code}`);
}

/** bKash / Nagad / card on the payment page — each tab really changes where the money goes. */
export async function switchPaymentMethodAction(formData) {
  const tranId = String(formData.get('tran_id') || '');
  const method = String(formData.get('method') || '');
  const { getPaymentByTranId, switchPaymentMethod } = await import('@/lib/orders');
  const payment = await getPaymentByTranId(tranId);
  if (!payment) redirect('/order');
  try {
    await switchPaymentMethod({ tranId, method });
  } catch {
    /* an unknown method is simply ignored — the page shows what is true */
  }
  revalidatePath(`/pay/${tranId}`);
  redirect(`/pay/${tranId}`);
}

/** "I did not send it after all" — the order stays and the page says payment was not made. */
export async function cancelPaymentAction(formData) {
  const tranId = String(formData.get('tran_id') || '');
  const code = String(formData.get('code') || '');
  const { cancelPaymentIntent } = await import('@/lib/orders');
  await cancelPaymentIntent({ tranId, note: 'Customer stopped at the payment page' });
  revalidatePath(`/pay/${tranId}`);
  redirect(`/order/${code}?paid=0`);
}
