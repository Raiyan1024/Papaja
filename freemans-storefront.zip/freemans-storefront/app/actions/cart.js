'use server';

import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { addToCart, setQty, removeItem, clearCart } from '@/lib/cart';

export async function addToOrder(formData) {
  const variantId = Number(formData.get('variant_id'));
  const qty = Math.max(1, Math.min(50, Number(formData.get('qty')) || 1));
  if (!variantId) redirect('/cart');
  await addToCart(variantId, qty);
  revalidatePath('/cart');
  redirect('/cart');
}

export async function changeQty(formData) {
  await setQty(Number(formData.get('variant_id')), Number(formData.get('qty')));
  revalidatePath('/cart');
}

export async function removeLine(formData) {
  await removeItem(Number(formData.get('variant_id')));
  revalidatePath('/cart');
}

export async function emptyOrder() {
  await clearCart();
  revalidatePath('/cart');
}
