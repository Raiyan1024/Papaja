'use server';

import { redirect } from 'next/navigation';
import { q } from '@/lib/db';
import { verifyPassword, setSession, clearSession } from '@/lib/auth';

function field(formData, name, max = 200) {
  return String(formData.get(name) || '').trim().slice(0, max);
}

/**
 * The shop owner's sign-in. Customers never have an account — an order is a name,
 * a phone number and a set of pieces, nothing to register.
 */
export async function login(formData) {
  const email = field(formData, 'email', 120).toLowerCase();
  const password = String(formData.get('password') || '');

  const rows = await q('select id, password_hash, role from users where email = $1', [email]);
  const user = rows[0];
  if (!user || !verifyPassword(password, user.password_hash)) {
    redirect('/admin/login?error=' + encodeURIComponent('That email and password do not match.'));
  }
  if (user.role !== 'admin') {
    redirect('/admin/login?error=' + encodeURIComponent('This sign-in is for the shop owner only.'));
  }

  await setSession(user.id);
  redirect('/admin');
}

export async function logout() {
  await clearSession();
  redirect('/admin/login');
}
