import Link from 'next/link';
import CheckoutForm from '@/components/checkout-form';
import { cartDetails } from '@/lib/cart';
import { listFabrics } from '@/lib/catalogue';
import { VISIT_FEE, VISIT_FEE_OUTSIDE, taka } from '@/lib/money';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { telLink, waLink, SHOP_NAME } from '@/lib/contact';

export const dynamic = 'force-dynamic';

export const metadata = { title: 'Place an order — ' + SHOP_NAME };

export default async function OrderPage({ searchParams }) {
  const sp = await searchParams;
  const lang = await getLang();
  const [cart, fabrics] = await Promise.all([cartDetails(), listFabrics()]);

  if (!cart.items.length) {
    return (
      <section className="wrap">
        <p className="eyebrow">{t(lang, 'checkout.eyebrow')}</p>
        <h1>{t(lang, 'checkout.emptyTitle')}</h1>
        <p className="muted" style={{ marginTop: 12, maxWidth: 620 }}>{t(lang, 'checkout.emptyBody')}</p>
        <div className="row" style={{ marginTop: 22, flexWrap: 'wrap' }}>
          <Link href="/suits" className="btn">{t(lang, 'cart.browse')}</Link>
          <Link href="/visit" className="btn outline">{t(lang, 'hero.bookVisit')}</Link>
          <a href={waLink('অর্ডার নিয়ে কথা বলতে চাই।')} target="_blank" rel="noreferrer" className="btn ghost wa-btn">{t(lang, 'common.whatsapp')}</a>
        </div>
      </section>
    );
  }

  return (
    <section className="wrap tight">
      <p className="eyebrow">
        {t(lang, 'checkout.eyebrow')} · {cart.count} {t(lang, 'common.pieces')}
      </p>
      <div className="split" style={{ alignItems: 'start', gap: 34 }}>
        <div>
          <h1 style={{ fontSize: 'clamp(26px, 3vw, 38px)', marginBottom: 20 }}>{t(lang, 'checkout.title')}</h1>
          <CheckoutForm
            fabrics={fabrics}
            subtotal={cart.subtotal}
            visitFee={VISIT_FEE}
            visitFeeOutside={VISIT_FEE_OUTSIDE}
            initialPayment={sp?.discuss ? 'full' : undefined}
            initialDiscuss={Boolean(sp?.discuss)}
          />
        </div>

        <aside className="panel" style={{ position: 'sticky', top: 96 }}>
          <p className="panel-title">{t(lang, 'checkout.yourPieces')}</p>
          {cart.items.map(line => (
            <div className="kv" key={line.id}>
              <span>
                <b>{line.name}</b>
                <span className="muted small" style={{ display: 'block' }}>{line.colour} · {line.design} · ×{line.qty}</span>
              </span>
              <span>{taka(line.lineTotal)}</span>
            </div>
          ))}
          <div className="kv total"><span>{t(lang, 'checkout.pieces')}</span><b>{taka(cart.subtotal)}</b></div>
          <p className="hint" style={{ marginTop: 14 }}>{t(lang, 'product.priceNote')}</p>
          <Link href="/cart" className="btn outline small" style={{ marginTop: 10, width: '100%', justifyContent: 'center' }}>
            {t(lang, 'common.editPieces')}
          </Link>
          <div className="row" style={{ marginTop: 10, gap: 8 }}>
            <a className="btn ghost small wa-btn" href={waLink('অর্ডার নিয়ে কথা বলতে চাই।')} target="_blank" rel="noreferrer">{t(lang, 'common.whatsapp')}</a>
            <a className="btn ghost small" href={telLink()}>{t(lang, 'common.call')}</a>
          </div>
        </aside>
      </div>
    </section>
  );
}
