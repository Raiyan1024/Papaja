import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getOrderByCode } from '@/lib/orders';
import { taka, REFUND_PCT } from '@/lib/money';
import { retryPayment } from '@/app/actions/orders';
import { getLang } from '@/lib/lang';
import CancelOrder, { WithdrawRequest } from '@/components/cancel-order';

export const dynamic = 'force-dynamic';

const STATUS_LABEL = {
  placed: 'Placed', confirmed: 'Confirmed', in_production: 'In production',
  ready: 'Ready', delivered: 'Delivered', cancelled: 'Cancelled'
};

const CANCEL_BADGE = {
  requested: { pill: 'warn', text: 'Cancellation asked — waiting for the shop' },
  accepted: { pill: 'bad', text: 'Cancelled — accepted by the shop' },
  rejected: { pill: 'good', text: 'Cancellation declined — the order stands' }
};

export async function generateMetadata({ params }) {
  const { code } = await params;
  return { title: `Order ${code}` };
}

export default async function OrderPage({ params, searchParams }) {
  const [{ code }, sp, lang] = await Promise.all([params, searchParams, getLang()]);
  const order = await getOrderByCode(code);
  if (!order) notFound();

  const bn = lang === 'bn';
  const paid = order.payment_status === 'paid';
  const partPaid = order.payment_status === 'partial';
  const justPaid = sp?.paid === '1';
  const justSubmitted = sp?.submitted === '1';
  const justAskedCancel = sp?.cancellation === 'requested';
  const latest = order.payments?.[0];
  const checking = !paid && latest?.status === 'submitted';
  const rejected = !paid && latest?.status === 'rejected';
  const method = order.payment_method || latest?.method || 'bkash';
  const cancel = order.cancel_state;
  const badge = cancel ? CANCEL_BADGE[cancel] : null;
  const canAskCancel = !cancel && order.status !== 'cancelled' && order.status !== 'delivered';

  return (
    <section className="wrap tight">
      <p className="eyebrow">{bn ? 'অর্ডার' : 'Order'} {order.code}</p>
      <div className="between">
        <h1 style={{ fontSize: 'clamp(26px, 3vw, 38px)' }}>
          {order.status === 'cancelled'
            ? bn ? 'অর্ডারটা বাতিল হয়েছে।' : 'This order is cancelled.'
            : paid
              ? bn ? 'টাকা পেয়ে গেছি।' : 'Payment received.'
              : bn ? 'অর্ডার নেওয়া হয়েছে — পেমেন্ট বাকি।' : 'Order placed — payment pending.'}
        </h1>
        <span className={`pill ${paid ? 'good' : 'warn'}`}>
          {paid ? (bn ? 'পরিশোধিত' : 'Paid') : partPaid ? `${bn ? 'অ্যাডভান্স দেওয়া' : 'Advance paid'} · ${taka(order.amount_due)} ${bn ? 'বাকি' : 'due'}` : `${bn ? 'বাকি' : 'Due'} ${taka(order.amount_due)}`}
        </span>
      </div>

      {justPaid ? <div className="alert good" style={{ margin: '18px 0' }}>{bn ? 'ধন্যবাদ — টাকা পেয়েছি, অর্ডার কনফার্ম।' : 'Thank you — the payment went through and the order is confirmed.'}</div> : null}

      {/* The cancellation answer, in one line, whichever way it went. */}
      {badge ? (
        <div className={`alert ${cancel === 'accepted' ? 'bad' : cancel === 'rejected' ? 'good' : 'warn'}`} style={{ margin: '18px 0' }}>
          <div className="between" style={{ alignItems: 'flex-start', gap: 12 }}>
            <div>
              <b>{justAskedCancel ? (bn ? 'অনুরোধ পাঠানো হয়েছে।' : 'Request sent.') : null} {badge.text}</b>
              {order.cancel_reason ? <div className="small" style={{ marginTop: 4 }}>{bn ? 'আপনার কারণ' : 'Your reason'}: {order.cancel_reason}</div> : null}
              {order.cancel_note && cancel !== 'requested' ? <div className="small" style={{ marginTop: 4 }}>{bn ? 'দোকানের উত্তর' : 'The shop says'}: {order.cancel_note}</div> : null}
              <div className="small muted" style={{ marginTop: 4 }}>
                {cancel === 'requested'
                  ? bn ? 'দোকান দেখে গ্রহণ বা না-মেনে নেবে — উত্তর এখানেই দেখা যাবে।' : 'The shop will accept or decline. The answer appears right here.'
                  : cancel === 'accepted'
                    ? bn ? 'কোনো কাপড় কাটা হয়নি। অ্যাডভান্স ফেরতযোগ্য নয় — বিস্তারিত জানতে কল বা হোয়াটসঅ্যাপ করুন।' : 'Nothing was cut. The home-visit advance is not refundable — WhatsApp us and we will explain the rest.'
                    : bn ? 'অর্ডার আগের মতোই চলবে।' : 'The order carries on as it was.'}
              </div>
            </div>
            <span className={`pill ${cancel === 'accepted' ? 'bad' : cancel === 'rejected' ? 'good' : 'warn'}`}>
              {cancel === 'accepted' ? (bn ? 'বাতিল হয়েছে' : 'Cancelled') : cancel === 'rejected' ? (bn ? 'না মেনে নেওয়া হয়েছে' : 'Not cancelled') : (bn ? 'অপেক্ষায়' : 'Requested')}
            </span>
          </div>
          {cancel === 'requested' ? <WithdrawRequest code={order.code} bn={bn} /> : null}
        </div>
      ) : null}

      {checking ? (
        <div className="alert warn" style={{ margin: '18px 0' }}>
          <b>{justSubmitted ? (bn ? 'TrxID পেয়েছি।' : 'TrxID received.') : bn ? 'আপনার পেমেন্ট দেখছি।' : 'We are checking your payment.'}</b>{' '}
          {latest?.gateway_ref ? <>TrxID <b>{latest.gateway_ref}</b>. </> : null}
          {bn
            ? 'বিকাশ/নগদ স্টেটমেন্টে মিলিয়ে দেখে অর্ডার কনফার্ম করব — দোকান খোলা থাকলে সাধারণত ৩০ মিনিটের মধ্যে।'
            : 'We match it against the bKash/Nagad statement and confirm the order — usually within 30 minutes during shop hours.'}
        </div>
      ) : null}

      {rejected ? (
        <div className="alert warn" style={{ margin: '18px 0' }}>
          {bn
            ? 'এই TrxID আমাদের স্টেটমেন্টে মেলেনি, তাই অর্ডার এখনো বাকি। স্ক্রিনশট হোয়াটসঅ্যাপে পাঠান, অথবা আবার টাকা পাঠিয়ে নতুন TrxID দিন।'
            : 'That TrxID did not match our statement, so the order is still unpaid. Reply on WhatsApp with a screenshot, or send the money again and re-enter the TrxID.'}
        </div>
      ) : null}
      {sp?.paid === '0' ? <div className="alert warn" style={{ margin: '18px 0' }}>{bn ? 'পেমেন্ট হয়নি। অর্ডার সেভ আছে, কোনো কাপড় কাটা হয়নি — যখন চান টাকা পাঠাতে পারেন।' : 'No payment was made. The order is saved and nothing has been cut — you can pay whenever you are ready.'}</div> : null}

      <div className="split" style={{ alignItems: 'start', gap: 34, marginTop: 24 }}>
        <div>
          <div className="panel">
            <p className="panel-title">{bn ? 'এর পরে কী হবে' : 'What happens next'}</p>
            <div className="stack" style={{ gap: 12 }}>
              {order.measurement_mode === 'home_visit' ? (
                <p>
                  {bn
                    ? `${order.customer_phone} নম্বরে ফোন করে বাসায় মাপ নেওয়ার সময় ঠিক করব${order.area ? ` — ${order.area}` : ''}। আমাদের লোক এসে মাপ নিয়ে অর্ডার নেবেন।`
                    : `We will call ${order.customer_phone} to arrange the home visit${order.area ? ` in ${order.area}` : ''}. Our person measures you and takes the order.`}
                </p>
              ) : order.measurement_mode === 'discuss' ? (
                <p>{bn ? 'ডিজাইন, মাপ আর কাপড় নিয়ে কথা বলার জন্য ফোন করব — তারপর কাটা হবে।' : 'We will call to agree the design, the measurements and the cloth before anything is cut.'}</p>
              ) : (
                <p>{bn ? 'আপনার দেওয়া মাপ লিখিতভাবে মিলিয়ে নেব, তারপর কাটা হবে।' : 'We will confirm your numbers in writing before cutting. Please keep your phone reachable.'}</p>
              )}
              {order.wants_discussion ? <p className="muted">{bn ? 'আপনি আগে কথা বলতে চেয়েছেন — দোকান সেখান থেকেই শুরু করবে।' : 'You asked to discuss the design first — the shop will start there.'}</p> : null}
              <p className="hint">
                {bn
                  ? `দাম কাটার আগে লিখিতভাবে ঠিক হবে। ফিটের প্রতিশ্রুতি: না মিললে ${REFUND_PCT}% ফেরত — অথবা ডেলিভারির ২ ঘণ্টার মধ্যে সম্পূর্ণ ফেরত দিলে।`
                  : `Prices are confirmed in writing before cutting. The fit promise: ${REFUND_PCT}% refunded if the finished garment does not fit — or if it comes back complete within 2 hours of delivery.`}
              </p>
            </div>
          </div>

          <div className="panel" style={{ marginTop: 18, padding: 0 }}>
            <table className="table">
              <thead><tr><th>{bn ? 'পোশাক' : 'Piece'}</th><th>{bn ? 'রং / ডিজাইন' : 'Colour / design'}</th><th className="num">{bn ? 'সংখ্যা' : 'Qty'}</th><th className="num">{bn ? 'দাম' : 'Price'}</th></tr></thead>
              <tbody>
                {order.items.map(item => (
                  <tr key={item.id}>
                    <td>{item.title}</td>
                    <td className="muted small">{item.colour}<br />{item.design}</td>
                    <td className="num">{item.qty}</td>
                    <td className="num">{taka(item.unit_price * item.qty)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <aside className="panel">
          <p className="panel-title">{bn ? 'পেমেন্ট' : 'Payment'}</p>
          <div className="kv"><span>{bn ? 'পোশাক' : 'Pieces'}</span><b>{taka(order.subtotal)}</b></div>
          {order.visit_fee ? <div className="kv"><span>{bn ? 'বাসায় মাপ' : 'Home visit'}</span><b>{taka(order.visit_fee)}</b></div> : null}
          <div className="kv total"><span>{bn ? 'মোট' : 'Total'}</span><b>{taka(order.total)}</b></div>
          <div className="kv"><span>{bn ? 'দেওয়া হয়েছে' : 'Paid'}</span><b>{taka(order.total - order.amount_due)}</b></div>
          <div className="kv"><span>{bn ? 'বাকি' : 'Due'}</span><b>{taka(order.amount_due)}</b></div>
          <div className="kv"><span>{bn ? 'অবস্থা' : 'Status'}</span><span>{STATUS_LABEL[order.status]}</span></div>

          {checking ? (
            <p className="hint" style={{ marginTop: 14 }}>
              TrxID {latest.gateway_ref} · {bn ? 'যাচাই চলছে' : 'checking'}. {order.customer_phone} {bn ? 'নম্বরে জানাব।' : '— we will confirm on this number.'}
            </p>
          ) : null}

          {!paid && !checking && order.amount_due > 0 && order.status !== 'cancelled' ? (
            <>
              <p className="label small-caps" style={{ marginTop: 16 }}>
                {rejected ? (bn ? 'আবার টাকা পাঠান' : 'Send the money again') : `${bn ? 'টাকা পাঠান' : 'Pay'} ${taka(order.amount_due)}`}
              </p>
              <form action={retryPayment} className="stack" style={{ gap: 8, marginTop: 8 }}>
                <input type="hidden" name="code" value={order.code} />
                {[
                  ['bkash', 'bKash'],
                  ['nagad', 'Nagad'],
                  ['card', bn ? 'কার্ড (ফোনে লিংক)' : 'Card (we call with a link)']
                ].map(([value, label]) => (
                  <button key={value} className="btn small wide" name="method" value={value} type="submit">
                    {label}
                  </button>
                ))}
              </form>
              <p className="hint" style={{ marginTop: 8 }}>
                {bn ? 'যেটা চাপবেন, সেই পেজে নিয়ে যাবে — বিকাশ, নগদ বা কার্ড।' : 'Whichever you press takes you to that payment page — bKash, Nagad or card.'}
              </p>
            </>
          ) : null}

          <Link href="/suits" className="btn outline small" style={{ marginTop: 12, width: '100%', justifyContent: 'center' }}>
            {bn ? 'আরেকটা পোশাক অর্ডার করুন' : 'Order something else'}
          </Link>
          {order.cloth_choice ? <p className="hint" style={{ marginTop: 14 }}>{bn ? 'কাপড়' : 'Cloth requested'}: {order.cloth_choice}</p> : null}
          {order.measurement_note ? <p className="hint">{bn ? 'মাপ' : 'Measurements'}: {order.measurement_note}</p> : null}

          {canAskCancel ? <CancelOrder code={order.code} lang={lang} /> : null}
        </aside>
      </div>
    </section>
  );
}
