import { getCategories, listProducts } from '@/lib/catalogue';

export const dynamic = 'force-dynamic';

/** /sitemap.xml — the catalogue, so Google indexes designs and not just the front page. */
export default async function sitemap() {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || 'https://freemans.antideploy.app').replace(/\/+$/, '');
  const now = new Date();

  const entries = [
    { url: `${base}/`, lastModified: now, changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/visit`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 },
    { url: `${base}/order`, lastModified: now, changeFrequency: 'monthly', priority: 0.7 }
  ];

  let categories = [];
  let products = [];
  try {
    [categories, products] = await Promise.all([getCategories(), listProducts(null)]);
  } catch {
    // a database blip should never break the sitemap
  }

  for (const category of categories) {
    entries.push({
      url: `${base}/${category.slug}`,
      lastModified: now,
      changeFrequency: 'weekly',
      priority: 0.8
    });
  }

  for (const product of products) {
    // The photographs travel with the entry, so a picture of a navy suit can be found in
    // Google Images even when nobody searches with words.
    const pictures = [product.image].filter(Boolean).map(src => (src.startsWith('http') ? src : base + src));
    entries.push({
      url: `${base}/product/${product.slug}`,
      lastModified: now,
      changeFrequency: 'weekly',
      priority: 0.6,
      images: pictures
    });
  }

  return entries;
}
