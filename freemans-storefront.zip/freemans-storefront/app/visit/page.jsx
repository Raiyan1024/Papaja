import Link from 'next/link';
import { VISIT_FEE, VISIT_FEE_OUTSIDE, REFUND_PCT, taka } from '@/lib/money';
import { SHOP_NAME } from '@/lib/contact';
import { faqs, faqJsonLd, JsonLd } from '@/lib/seo';

export const metadata = {
  title: 'Home measuring visit in Dhaka',
  description:
    'Our person comes to your address, takes your measurements and writes the order. ৳150 inside Dhaka, ৳400 outside Dhaka, travel included.',
  alternates: { canonical: '/visit' }
};

export default function VisitPage() {
  return (
    <>
    <JsonLd data={faqJsonLd(faqs)} />
    <section className="wrap tight">
      <p className="eyebrow">Two ways to give your size · 01</p>
      <div className="split" style={{ alignItems: 'start', gap: 40 }}>
        <div>
          <h1 style={{ fontSize: 'clamp(28px, 3.4vw, 42px)' }}>We come to you.</h1>
          <p style={{ marginTop: 14, maxWidth: 520 }}>
            Pay {taka(VISIT_FEE)} inside Dhaka or {taka(VISIT_FEE_OUTSIDE)} outside Dhaka and we send one of our
            people to your address to take your measurements and your order in person. The visit fee is a fixed
            charge and it is not refundable — the visit happens whether or not the order goes ahead.
          </p>

          <div className="panel flat" style={{ marginTop: 18 }}>
            <div className="kv">
              <span>{taka(VISIT_FEE)}</span>
              <span className="muted">Inside Dhaka · ঢাকার ভেতরে</span>
            </div>
            <div className="kv">
              <span>{taka(VISIT_FEE_OUTSIDE)}</span>
              <span className="muted">Outside Dhaka · ঢাকার বাইরে, যাতায়াতসহ</span>
            </div>
          </div>

          <div className="panel" style={{ marginTop: 24 }}>
            <p className="panel-title">How the visit works</p>
            <div className="stack" style={{ gap: 14 }}>
              <div className="kv"><b>01</b><span className="muted">Choose “Home visit” on the order form and give your address.</span></div>
              <div className="kv"><b>02</b><span className="muted">Pay the visit advance — {taka(VISIT_FEE)} inside Dhaka, {taka(VISIT_FEE_OUTSIDE)} outside. Non-refundable.</span></div>
              <div className="kv"><b>03</b><span className="muted">Our person arrives, measures you, and takes the order and the cloth choice.</span></div>
              <div className="kv"><b>04</b><span className="muted">The price is confirmed in writing before anything is cut.</span></div>
            </div>
          </div>

          <div className="row" style={{ marginTop: 24 }}>
            <Link href="/order" className="btn">Start an order with a visit</Link>
            <Link href="/suits" className="btn outline">See the catalogue</Link>
          </div>
        </div>

        <aside className="panel">
          <p className="panel-title">Prefer to send your own size?</p>
          <p className="muted">
            Choose “I will give my own size” at checkout and send your numbers — chest, waist, shoulder, sleeve,
            length, collar. The clothes are cut exactly to the size you give.
          </p>
          <hr className="rule" style={{ margin: '18px 0' }} />
          <p className="panel-title">The fit promise</p>
          <p className="muted">
            {REFUND_PCT}% of the price comes back if the finished garment does not fit — or if you change your mind
            and hand it back, complete, within 2 hours of delivery. মাপ না হলে {REFUND_PCT}% ফেরত।
          </p>
          <hr className="rule" style={{ margin: '18px 0' }} />
          <p className="panel-title">Payment</p>
          <p className="muted small" style={{ margin: 0 }}>
            The visit advance is {taka(VISIT_FEE)} inside Dhaka and {taka(VISIT_FEE_OUTSIDE)} outside,
            non-refundable. A full payment option is available if you would rather settle the whole order up front.
          </p>
        </aside>
      </div>

      {/* The questions people actually ask before they order — also what Google reads out. */}
      <div className="line-block" style={{ marginTop: 44 }}>
        <h2>Questions we are asked every day</h2>
        <div className="faq-grid">
          {faqs.map(item => (
            <details key={item.q} className="faq">
              <summary>{item.q}</summary>
              <p className="muted">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
    </>
  );
}
