import Link from 'next/link';
import { notFound } from 'next/navigation';
import ProductView from '@/components/product-view';
import SetupNotice from '@/components/setup-notice';
import { getCategories, getProduct, listProducts } from '@/lib/catalogue';
import { taka } from '@/lib/money';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { SHOP_NAME } from '@/lib/contact';
import { productJsonLd, breadcrumbJsonLd, JsonLd, siteBase } from '@/lib/seo';
import { addToOrder } from '@/app/actions/cart';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) return { title: 'Not found' };
  const prices = (product.variants || []).map(v => Number(v.price));
  const from = Math.min(...prices);
  const description =
    `${product.summary || product.description || product.name} Made to measure in Dhaka` +
    (Number.isFinite(from) ? `, from ৳${from.toLocaleString('en-US')}.` : '.') +
    ' Order online or book a ৳150 home measuring visit.';
  const image = product.image || '/products/suit-navy.jpg';
  return {
    title: `${product.name} — ${product.category_name} in Dhaka`,
    description,
    alternates: { canonical: `/product/${product.slug}` },
    openGraph: {
      type: 'article',
      title: product.name,
      description,
      url: `/product/${product.slug}`,
      images: [{ url: image, alt: product.name }]
    },
    twitter: { card: 'summary_large_image', title: product.name, description, images: [image] }
  };
}

export default async function ProductPage({ params, searchParams }) {
  const { slug } = await params;
  const sp = await searchParams;
  const lang = await getLang();
  const product = await getProduct(slug);

  if (!product) {
    const cats = await getCategories();
    if (!cats.length) return <SetupNotice what="style" />;
    notFound();
  }

  const siblings = (await listProducts(product.category_slug)).filter(p => p.slug !== product.slug).slice(0, 3);

  return (
    <>
      <JsonLd data={productJsonLd(product)} />
      <JsonLd
        data={breadcrumbJsonLd([
          { name: 'Home', href: '/' },
          { name: product.category_name, href: `/${product.category_slug}` },
          { name: product.name, href: `/product/${product.slug}` }
        ])}
      />
      <section className="wrap tight">
        <p className="eyebrow">
          <Link href={`/${product.category_slug}`}>{product.category_name}</Link> · {t(lang, 'product.instance')}
        </p>

        <ProductView
          product={product}
          variants={product.variants}
          action={addToOrder}
          initialColour={sp?.colour}
          gallery={product.gallery || []}
        />
      </section>

      {siblings.length ? (
        <section className="wrap">
          <h3 style={{ marginBottom: 18 }}>{t(lang, 'product.more')} {product.category_name.toLowerCase()}</h3>
          <div className="grid-3">
            {siblings.map(item => (
              <Link key={item.id} href={`/product/${item.slug}`} className="card">
                <div className="thumb small">{item.image ? <img src={item.image} alt={item.name} loading="lazy" /> : null}</div>
                <div className="body">
                  <h3>{item.name}</h3>
                  <div className="foot">
                    <span className="price">{taka(item.from_price)}</span>
                    <span className="small" style={{ color: 'var(--blue)' }}>{t(lang, 'common.view')} →</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}
