import Link from 'next/link';
import { cartDetails } from '@/lib/cart';
import { taka } from '@/lib/money';
import { changeQty, removeLine, emptyOrder } from '@/app/actions/cart';
import { SHOP_NAME } from '@/lib/contact';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Your order — ' + SHOP_NAME };

export default async function CartPage() {
  const cart = await cartDetails();

  return (
    <section className="wrap tight">
      <p className="eyebrow">Your order</p>
      <h1 style={{ fontSize: 'clamp(26px, 3vw, 38px)' }}>
        {cart.items.length ? `${cart.count} ${cart.count === 1 ? 'piece' : 'pieces'} in your order` : 'Nothing in your order yet'}
      </h1>

      {!cart.items.length ? (
        <div style={{ marginTop: 20 }}>
          <p className="muted">Pick a design and a colour to start — every price is for a piece cut to your size.</p>
          <div className="row" style={{ marginTop: 18 }}>
            <Link href="/suits" className="btn">Suits</Link>
            <Link href="/blazers" className="btn outline">Blazers</Link>
            <Link href="/trousers" className="btn outline">Trousers</Link>
            <Link href="/shirts" className="btn outline">Shirts</Link>
          </div>
        </div>
      ) : (
        <div className="split" style={{ alignItems: 'start', gap: 34, marginTop: 22 }}>
          <div className="panel" style={{ padding: 0 }}>
            <table className="table">
              <thead>
                <tr><th>Piece</th><th>Colour / design</th><th className="num">Price</th><th className="num">Qty</th><th className="num">Total</th><th /></tr>
              </thead>
              <tbody>
                {cart.items.map(line => (
                  <tr key={line.id}>
                    <td>
                      <Link href={`/product/${line.slug}`} style={{ fontFamily: 'var(--serif)' }}>{line.name}</Link>
                      <div className="muted small">{line.category_name}</div>
                    </td>
                    <td className="muted small">{line.colour}<br />{line.design}</td>
                    <td className="num">{taka(line.price)}</td>
                    <td className="num">
                      <form action={changeQty} className="row" style={{ gap: 6, justifyContent: 'flex-end' }}>
                        <input type="hidden" name="variant_id" value={line.id} />
                        <input name="qty" type="number" min="0" max="50" defaultValue={line.qty} style={{ width: 64, padding: '5px 7px' }} />
                        <button className="btn ghost small" type="submit">Update</button>
                      </form>
                    </td>
                    <td className="num">{taka(line.lineTotal)}</td>
                    <td className="num">
                      <form action={removeLine}>
                        <input type="hidden" name="variant_id" value={line.id} />
                        <button className="btn ghost small" type="submit">Remove</button>
                      </form>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <aside className="panel">
            <p className="panel-title">Summary</p>
            <div className="kv"><span>Pieces</span><b>{taka(cart.subtotal)}</b></div>
            <div className="kv"><span>Home visit</span><span className="muted">Added at checkout</span></div>
            <div className="kv total"><span>Subtotal</span><b>{taka(cart.subtotal)}</b></div>
            <Link href="/order" className="btn" style={{ marginTop: 16, width: '100%', justifyContent: 'center' }}>
              Continue to the order form
            </Link>
            <form action={emptyOrder} style={{ marginTop: 10 }}>
              <button className="btn ghost small" type="submit">Empty the order</button>
            </form>
          </aside>
        </div>
      )}
    </section>
  );
}
