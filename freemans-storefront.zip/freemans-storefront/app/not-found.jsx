import Link from 'next/link';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { waLink } from '@/lib/contact';

export default async function NotFound() {
  const lang = await getLang();
  const bn = lang === 'bn';

  return (
    <section className="wrap tight" style={{ minHeight: '58vh', display: 'grid', alignContent: 'center' }}>
      <p className="eyebrow">{bn ? '৪০৪ · পাতা নেই' : '404 · not on the rail'}</p>
      <h1 style={{ maxWidth: 640 }}>
        {bn ? 'এই পাতা আমাদের দোকানে নেই।' : 'That page is not on the rail.'}
      </h1>
      <p className="muted" style={{ maxWidth: 560, marginTop: 14 }}>
        {bn
          ? 'হতে পারে লিংকটা পুরোনো, অথবা পোশাকটার নাম বদলেছে। নিচের যেকোনো পথে এগোতে পারেন — অর্ডার নিতে আমরা সবসময় আছি।'
          : 'The link may be old, or the piece has been renamed. Take any of the ways below — we are still here to take your order.'}
      </p>

      <div className="row" style={{ marginTop: 24, flexWrap: 'wrap' }}>
        <Link className="btn" href="/">{bn ? 'ক্যাটালগে ফিরে যান' : 'Back to the catalogue'}</Link>
        <Link className="btn outline" href="/blazers">{bn ? 'ব্লেজার' : 'Blazers'}</Link>
        <Link className="btn outline" href="/order">{bn ? 'অর্ডার করুন' : 'Place an order'}</Link>
        <a className="btn wa-btn" href={waLink(bn ? 'পাতাটা খুঁজে পাচ্ছি না, সাহায্য করুন।' : 'I cannot find that page — could you help?')} target="_blank" rel="noreferrer">
          {t(lang, 'common.whatsapp')}
        </a>
      </div>
    </section>
  );
}
