import Link from 'next/link';
import { notFound } from 'next/navigation';
import ProductCard from '@/components/product-card';
import SetupNotice from '@/components/setup-notice';
import { getCategories, getCategory, listProducts, listFabrics } from '@/lib/catalogue';
import { taka } from '@/lib/money';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { waLink, SHOP_NAME } from '@/lib/contact';
import { breadcrumbJsonLd, JsonLd } from '@/lib/seo';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }) {
  const { category } = await params;
  const row = await getCategory(category);
  if (!row) return { title: 'Not found' };
  const description = `${row.name} cut to your own measurements in Dhaka. ${row.tagline || ''} ${
    (row.intro || '').split('. ')[0]
  }. A home measuring visit costs ৳150 inside Dhaka.`.replace(/\s+/g, ' ').trim();
  return {
    title: `${row.name} in Dhaka — made to measure`,
    description,
    alternates: { canonical: `/${row.slug}` },
    openGraph: { title: `${row.name} — ${SHOP_NAME}`, description, url: `/${row.slug}` }
  };
}

export default async function CategoryPage({ params }) {
  const { category } = await params;
  const lang = await getLang();
  const row = await getCategory(category);
  if (!row) {
    const cats = await getCategories();
    if (!cats.length) return <SetupNotice what="line" />;
    notFound();
  }

  const [products, fabrics] = await Promise.all([listProducts(row.slug), listFabrics()]);
  const cheapest = products.length ? Math.min(...products.map(p => Number(p.from_price || 0))) : 0;
  const dearest = products.length ? Math.max(...products.map(p => Number(p.to_price || 0))) : 0;
  const colours = new Set(products.flatMap(p => p.colours || []));
  const designs = products.reduce((sum, p) => sum + Number(p.variant_count || 0), 0);

  return (
    <>
      <JsonLd
        data={breadcrumbJsonLd([
          { name: 'Home', href: '/' },
          { name: row.name, href: `/${row.slug}` }
        ])}
      />
      <section className="wrap tight">
        <p className="eyebrow">
          <Link href="/">{t(lang, 'cat.eyebrow')}</Link> · {row.name}
        </p>
        <h1>{row.name}</h1>
        <p className="muted" style={{ marginTop: 12, maxWidth: 620 }}>{row.tagline}</p>
        <p style={{ marginTop: 18, maxWidth: 740 }}>{row.intro}</p>
        <p className="hint">{t(lang, 'cat.note')}</p>

        <div className="row" style={{ marginTop: 20, flexWrap: 'wrap' }}>
          <a className="btn small wa-btn" href={waLink(`আসসালামু আলাইকুম — ${row.name} নিয়ে জিজ্ঞেস করতে চাই।`)} target="_blank" rel="noreferrer">
            {t(lang, 'common.whatsapp')}
          </a>
          <Link className="btn small outline" href="/order">{t(lang, 'pay.discuss')}</Link>
        </div>
      </section>

      <hr className="rule" />

      <section className="wrap">
        {products.length === 0 ? (
          <div className="alert warn">
            {lang === 'bn' ? 'এখনো কোনো পোশাক নেই — ' : 'No products yet — run '}
            <code>npm run db:setup</code>
          </div>
        ) : (
          <>
            <div className="between" style={{ marginBottom: 18 }}>
              <p className="eyebrow" style={{ margin: 0 }}>
                {products.length} {t(lang, 'common.styles')} · {taka(cheapest)} – {taka(dearest)}
              </p>
              <p className="muted small" style={{ margin: 0 }}>
                {lang === 'bn' ? 'প্রতিটি রং ও ডিজাইন আলাদা দামে' : 'Every colour and design priced separately'}
              </p>
            </div>
            <div className="grid-3">
              {products.map(product => <ProductCard key={product.id} product={product} lang={lang} />)}
            </div>
          </>
        )}
      </section>

      {/* Uniforms are cut from the school's own cloth, so the cloth shelf stays off this page. */}
      {row.slug === 'uniforms' ? (
        <section className="wrap">
          <div className="panel flat">
            <div className="between">
              <h3>{lang === 'bn' ? 'ইউনিফর্মের কাপড় আমরা নিজেরাই ঠিক করি' : 'Uniform cloth is arranged with the school'}</h3>
              <Link href="/order" className="btn outline small">{t(lang, 'cat.combineDesign')}</Link>
            </div>
            <p className="muted small" style={{ margin: '10px 0 0' }}>
              {lang === 'bn'
                ? 'ইউনিফর্মের কাপড় স্কুল বা প্রতিষ্ঠানের সঙ্গে ঠিক করা হয়, তাই এখানে কাপড়ের দামের তালিকা দেওয়া হয়নি। পরিমাণ আর রঙ জানালে আমরা নমুনা পাঠাই।'
                : 'Uniform cloth is agreed with the school or the institution, so the shelf prices are not listed here. Send us the quantity and the colour and we will send the swatch.'}
            </p>
          </div>
        </section>
      ) : (
      <section className="wrap">
        <div className="panel flat">
          <div className="between">
            <h3>{t(lang, 'cat.clothForLine')} {row.name.toLowerCase()}</h3>
            <Link href="/order" className="btn outline small">{t(lang, 'cat.combineDesign')}</Link>
          </div>
          <div className="grid-2" style={{ marginTop: 18 }}>
            {fabrics.slice(0, 8).map(fabric => (
              <div className="kv" key={fabric.id}>
                <span className="row" style={{ gap: 10 }}>
                  <span className="swatch" style={{ background: fabric.colour_hex }} />
                  {fabric.colour} · {fabric.name}
                  <span className="muted small">{fabric.composition}</span>
                </span>
                <span className="muted">{taka(fabric.price_per_yard)} / yd</span>
              </div>
            ))}
          </div>
        </div>
      </section>
      )}
    </>
  );
}
