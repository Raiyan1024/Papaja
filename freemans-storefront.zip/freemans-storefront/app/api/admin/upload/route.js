import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { saveImage, attachImage } from '@/lib/images';

export const runtime = 'nodejs';

/**
 * The admin panel sends a photograph that the browser has already shrunk to a sensible size.
 * It is kept in the database and the URL comes back, ready to be saved on a product or a design.
 */
export async function POST(request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: 'Not signed in' }, { status: 401 });
  }

  let form;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: 'That upload could not be read' }, { status: 400 });
  }

  const file = form.get('file');
  if (!file || typeof file === 'string') {
    return NextResponse.json({ error: 'No photograph arrived' }, { status: 400 });
  }
  if (file.size > 6 * 1024 * 1024) {
    return NextResponse.json({ error: 'That photograph is too large (6 MB max)' }, { status: 400 });
  }

  const mime = ['image/jpeg', 'image/png', 'image/webp'].includes(file.type) ? file.type : 'image/jpeg';
  const bytes = Buffer.from(await file.arrayBuffer());
  if (!bytes.length) return NextResponse.json({ error: 'That file is empty' }, { status: 400 });

  const width = Number(form.get('width')) || null;
  const height = Number(form.get('height')) || null;
  const productId = Number(form.get('product_id')) || null;
  const variantId = Number(form.get('variant_id')) || null;

  try {
    const url = await saveImage({ bytes, mime, width, height, productId, variantId, label: String(form.get('label') || '').slice(0, 80) || null });
    if (productId || variantId) {
      await attachImage({ key: url.split('/').pop(), productId, variantId });
    }
    return NextResponse.json({ url, bytes: bytes.length });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
