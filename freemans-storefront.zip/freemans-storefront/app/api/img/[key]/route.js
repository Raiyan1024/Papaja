import { NextResponse } from 'next/server';
import { getImage } from '@/lib/images';

/**
 * Photographs come back from the database here. They never change once uploaded, so the
 * browser is told to keep them for a year.
 */
export async function GET(_request, { params }) {
  const { key } = await params;
  let row;
  try {
    row = await getImage(key);
  } catch {
    return new NextResponse('Not found', { status: 404 });
  }
  if (!row) return new NextResponse('Not found', { status: 404 });

  return new NextResponse(Buffer.from(row.bytes), {
    headers: {
      'content-type': row.mime || 'image/jpeg',
      'cache-control': 'public, max-age=31536000, immutable'
    }
  });
}
