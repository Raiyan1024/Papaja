import { timingSafeEqual } from 'node:crypto';
import { parseReceipt } from '@/lib/payments/parse';
import { matchIncoming, getSmsToken } from '@/lib/payments/auto';

export const dynamic = 'force-dynamic';

/**
 * The shop's phone forwards each bKash/Nagad receipt here, and the order is released by itself.
 *
 *   POST /api/payments/sms?token=<the token shown in /admin/payments>
 *   body: the SMS text, a JSON {"text": "..."} or {"from": "...", "body": "..."}
 *
 * Point any free SMS-forwarder app on the shop phone at this URL (it lives in /admin/payments —
 * copy the whole thing from there). Nothing is trusted beyond the token, and nothing is released
 * unless the amount matches the amount that order was asked to pay.
 */

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'cache-control': 'no-store', 'content-type': 'application/json' }
  });

function tokenMatches(given, expected) {
  if (!given || !expected) return false;
  const a = Buffer.from(String(given));
  const b = Buffer.from(String(expected));
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

async function readText(request) {
  const type = request.headers.get('content-type') || '';
  if (type.includes('application/json')) {
    const body = await request.json().catch(() => ({}));
    return String(body.text || body.body || body.message || body.sms || '');
  }
  return request.text();
}

export async function POST(request) {
  const url = new URL(request.url);
  const expected = await getSmsToken();
  const given = url.searchParams.get('token') || request.headers.get('x-payment-token');

  if (!tokenMatches(given, expected)) {
    return json({ ok: false, error: 'bad_token' }, 401);
  }

  let text = '';
  try {
    text = await readText(request);
  } catch {
    return json({ ok: false, error: 'unreadable_body' }, 400);
  }

  const receipt = parseReceipt(text);
  if (!receipt) {
    // Not a payment message. Keep it, so the shopkeeper can see what the phone is sending.
    await matchIncoming({ raw: text, source: 'sms' });
    return json({ ok: false, error: 'not_a_payment_message', seen: String(text).slice(0, 120) }, 422);
  }

  const result = await matchIncoming({ ...receipt, raw: text, source: 'sms' });
  const ok = result.outcome === 'paid' || result.outcome === 'duplicate';
  return json({ ok, ...result }, ok ? 200 : 202);
}

/** Handy while setting the phone up: open the URL in a browser to see that it answers. */
export async function GET(request) {
  const url = new URL(request.url);
  const expected = await getSmsToken();
  const given = url.searchParams.get('token');
  if (!tokenMatches(given, expected)) return json({ ok: false, error: 'bad_token' }, 401);
  return json({
    ok: true,
    says: 'POST the bKash/Nagad message here, as text or as {"text": "..."}',
    example: 'You have received Tk 150.00 from 01711223344. TrxID 9F7A2KD10X at 07/11/2026 10:23'
  });
}
