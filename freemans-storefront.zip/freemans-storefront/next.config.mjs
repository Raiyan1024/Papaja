/** @type {import('next').NextConfig} */
const nextConfig = {
  poweredByHeader: false,
  experimental: {
    serverActions: {
      bodySizeLimit: '2mb',
      // preview and live hosts: Antideploy, sandbox (*.e2b.app), Vercel (*.vercel.app), local dev
      allowedOrigins: [
        '*.antideploy.app',
        '*.e2b.app',
        '*.vercel.app',
        'localhost:3000',
        'localhost:3100',
        'localhost:3200',
        '127.0.0.1:3100',
        '127.0.0.1:3200'
      ]
    }
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'geolocation=(), microphone=(), camera=()' },
          { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' }
        ]
      }
    ];
  }
};
export default nextConfig;
