'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useLang } from '@/components/lang-provider';
import { telLink, waLink, PHONE_PRETTY } from '@/lib/contact';

/**
 * Fixed to the lower-right corner from the very top of the page:
 * the order button, then WhatsApp and call, so a customer is never more than one tap
 * from buying or asking.
 */
export default function FloatingActions({ count = 0, subtotal = 0, hidden = false }) {
  const { t, lang } = useLang();
  const pathname = usePathname() || '';
  // the shopkeeper's own screens and the payment page keep the corner clear
  if (hidden || pathname.startsWith('/admin') || pathname.startsWith('/pay')) return null;

  const label = lang === 'bn'
    ? (count ? `অর্ডার · ${count}` : 'অর্ডার করুন')
    : (count ? `Order · ${count}` : 'Order');
  const sub = count
    ? `৳${Number(subtotal).toLocaleString('en-US')}`
    : lang === 'bn' ? 'শুরু করুন' : 'Start one';

  return (
    <div className="fab">
      <Link href={count ? '/cart' : '/order'} className="fab-main">
        <span className="fab-ico" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.7">
            <path d="M6 7h12l-1.2 12.2a1.6 1.6 0 0 1-1.6 1.4H8.8a1.6 1.6 0 0 1-1.6-1.4L6 7Z" />
            <path d="M9 7a3 3 0 0 1 6 0" />
          </svg>
        </span>
        <span className="fab-txt">
          <b>{label}</b>
          <small>{sub}</small>
        </span>
      </Link>

      <a className="fab-mini wa" href={waLink(lang === 'bn' ? 'আসসালামু আলাইকুম, অর্ডার নিয়ে কথা বলতে চাই।' : 'Hello, I would like to talk about an order.')}
         target="_blank" rel="noreferrer" aria-label={t('common.whatsapp')} title={t('common.whatsapp')}>
        <svg viewBox="0 0 24 24" width="19" height="19" fill="currentColor" aria-hidden="true">
          <path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 1.8a8.2 8.2 0 0 1 0 16.4 8.1 8.1 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 0 1 12 3.8Zm-3 4c-.2 0-.5.1-.7.4-.3.3-.9.9-.9 2s.9 2.2 1 2.4c.1.2 1.7 2.7 4.1 3.7 2 .8 2.4.7 2.8.6.5 0 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2 0-.1-.2-.2-.4-.3l-1.6-.8c-.2-.1-.4-.1-.5.1l-.7.9c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-2-1.2 7.4 7.4 0 0 1-1.3-1.7c-.1-.2 0-.3.1-.4l.6-.7c.1-.2.1-.3 0-.5l-.7-1.7c-.2-.4-.4-.4-.6-.4h-.4Z" />
        </svg>
      </a>

      <a className="fab-mini call" href={telLink()} aria-label={`${t('common.call')} ${PHONE_PRETTY}`} title={`${t('common.call')} · ${PHONE_PRETTY}`}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
          <path d="M6.6 3.5h2.7l1.4 3.6-2 1.4a11 11 0 0 0 5.4 5.4l1.4-2 3.6 1.4v2.7A2.6 2.6 0 0 1 16.4 19C9.8 18.6 5.4 14.2 5 7.6a2.6 2.6 0 0 1 1.6-4.1Z" />
        </svg>
      </a>
    </div>
  );
}
