'use client';

import { useState } from 'react';
import { switchPaymentMethodAction, cancelPaymentAction } from '@/app/actions/orders';
import { waLink } from '@/lib/contact';

const fmt = new Intl.NumberFormat('en-US');

/**
 * Everything the customer can press on the payment page, and every one of them does something:
 * change how they pay, copy a number straight into their bKash/Nagad app, hand over the TrxID,
 * ask on WhatsApp, or stop and keep the order.
 */
export default function PaymentPanel({ tranId, code, method, amount, number, lang }) {
  const bn = lang === 'bn';
  const [copied, setCopied] = useState(null);

  async function copy(what, text) {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        document.execCommand('copy');
        document.body.removeChild(area);
      }
      setCopied(what);
      setTimeout(() => setCopied(c => (c === what ? null : c)), 2200);
    } catch {
      setCopied(null);
    }
  }

  const tabs = [
    ['bkash', 'bKash'],
    ['nagad', 'Nagad'],
    ['card', bn ? 'কার্ড' : 'Card']
  ];

  return (
    <>
      <div className="pay-tabs" role="tablist" aria-label={bn ? 'কীভাবে টাকা পাঠাবেন' : 'How you will pay'}>
        {tabs.map(([value, label]) => (
          <form key={value} action={switchPaymentMethodAction}>
            <input type="hidden" name="tran_id" value={tranId} />
            <input type="hidden" name="method" value={value} />
            <button
              type="submit"
              role="tab"
              aria-selected={method === value}
              className={`pay-tab ${method === value ? 'on' : ''}`}
            >
              {label}
            </button>
          </form>
        ))}
      </div>

      {method !== 'card' ? (
        <div className="stack" style={{ gap: 10, marginTop: 16 }}>
          <div className="copy-row">
            <div>
              <div className="meta small muted">{bn ? 'যে নম্বরে পাঠাবেন' : 'Send to'}</div>
              <b style={{ fontSize: 20 }}>{number}</b>
            </div>
            <button type="button" className="btn small outline" onClick={() => copy('number', number)}>
              {copied === 'number' ? (bn ? 'কপি হয়েছে ✓' : 'Copied ✓') : bn ? 'নম্বর কপি' : 'Copy number'}
            </button>
          </div>

          <div className="copy-row">
            <div>
              <div className="meta small muted">{bn ? 'টাকার পরিমাণ' : 'Amount'}</div>
              <b style={{ fontSize: 20 }}>৳{fmt.format(amount)}</b>
            </div>
            <button type="button" className="btn small outline" onClick={() => copy('amount', String(amount))}>
              {copied === 'amount' ? (bn ? 'কপি হয়েছে ✓' : 'Copied ✓') : bn ? 'টাকা কপি' : 'Copy amount'}
            </button>
          </div>

          <div className="copy-row">
            <div>
              <div className="meta small muted">{bn ? 'রেফারেন্স (রিমার্কসে লিখুন)' : 'Reference (write it in the remarks)'}</div>
              <b style={{ letterSpacing: 1 }}>{code}</b>
            </div>
            <button type="button" className="btn small outline" onClick={() => copy('code', code)}>
              {copied === 'code' ? (bn ? 'কপি হয়েছে ✓' : 'Copied ✓') : bn ? 'রেফারেন্স কপি' : 'Copy reference'}
            </button>
          </div>

          <p className="hint" style={{ margin: 0 }}>
            {bn
              ? 'কপি করা নম্বরটা বিকাশ/নগদ অ্যাপের “Send Money” ঘরে বসিয়ে দিন, টাকা লিখুন, রেফারেন্সে অর্ডার কোডটা দিন।'
              : 'Paste the copied number into Send Money in your bKash/Nagad app, type the amount, put the order code in the reference.'}
          </p>
        </div>
      ) : (
        <div className="alert warn" style={{ marginTop: 16 }}>
          {bn
            ? 'কার্ডে নিতে আমাদের মার্চেন্ট অ্যাকাউন্ট লাগে, যা এখনো হয়নি। অর্ডার সেভ আছে — আমরা ফোন করে সিকিউর পেমেন্ট লিংক পাঠাব, অথবা আপনি বিকাশ/নগদ ট্যাবে গিয়ে সেন্ড মানি করতে পারেন।'
            : 'Cards need a merchant account, which is not open yet. Your order is saved: we call you with a secure payment link, or you can switch to the bKash/Nagad tab and Send Money instead.'}
        </div>
      )}

      <div className="row" style={{ gap: 10, marginTop: 16, flexWrap: 'wrap' }}>
        <a
          className="btn wa-btn small"
          href={waLink(bn ? `অর্ডার ${code} — পেমেন্ট নিয়ে কথা বলতে চাই।` : `Order ${code} — I need help paying.`)}
          target="_blank"
          rel="noreferrer"
        >
          {bn ? 'স্ক্রিনশট হোয়াটসঅ্যাপে' : 'Send the screenshot on WhatsApp'}
        </a>
        <form action={cancelPaymentAction}>
          <input type="hidden" name="tran_id" value={tranId} />
          <input type="hidden" name="code" value={code} />
          <button type="submit" className="btn ghost small">
            {bn ? 'এখন টাকা পাঠাচ্ছি না — অর্ডার রাখুন' : 'Not paying now — keep my order'}
          </button>
        </form>
      </div>
    </>
  );
}
