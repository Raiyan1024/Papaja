'use client';

import { useEffect, useMemo, useState } from 'react';
import { useLang } from '@/components/lang-provider';
import { designCrop } from '@/lib/colours';
import { productWaText, waLink, telLink, PHONE_PRETTY } from '@/lib/contact';
import { thumb } from '@/lib/thumbs';

const fmt = new Intl.NumberFormat('en-US');

/**
 * The piece itself: the photograph, every colour and every design, and the button that puts
 * it in the order. Pressing a colour changes the picture, pressing a design opens it bigger,
 * and the price you see is the price of the box you picked.
 */
export default function ProductView({ product, variants, action, initialColour, gallery = [] }) {
  const { t, lang } = useLang();
  const bn = lang === 'bn';

  const colours = useMemo(() => {
    const map = new Map();
    for (const v of variants) if (!map.has(v.colour)) map.set(v.colour, v.colour_hex);
    return [...map.entries()].map(([name, hex]) => ({ name, hex }));
  }, [variants]);

  const start = colours.find(c => c.name === initialColour)?.name || colours[0]?.name || '';
  const [colour, setColour] = useState(start);
  const designs = variants.filter(v => v.colour === colour);
  const [design, setDesign] = useState(designs[0]?.design || '');
  const [qty, setQty] = useState(1);
  const [zoom, setZoom] = useState(null);

  const active = variants.find(v => v.colour === colour && v.design === design) || designs[0] || variants[0];
  const mainImage = active?.image || product.image;
  const prices = variants.map(v => Number(v.price));
  const from = Math.min(...prices);
  const to = Math.max(...prices);

  function pickColour(name) {
    setColour(name);
    const next = variants.find(v => v.colour === name);
    if (next) setDesign(next.design);
  }

  useEffect(() => {
    if (!zoom) return;
    const onKey = e => {
      if (e.key === 'Escape') setZoom(null);
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [zoom]);

  return (
    <>
      <div className="split" style={{ gap: 46, alignItems: 'start' }}>
        <div>
          <button
            type="button"
            className="card gallery-main"
            onClick={() => mainImage && setZoom({ src: mainImage, title: `${product.name} — ${colour}`, note: design })}
            title={bn ? 'বড় করে দেখুন' : 'See it bigger'}
            style={{ background: 'var(--panel)', padding: 0, border: '1px solid var(--line)', cursor: 'zoom-in' }}
          >
            {mainImage ? (
              <img src={mainImage} alt={`${product.name} in ${colour}`} style={{ width: '100%', aspectRatio: '4/5', objectFit: 'cover' }} />
            ) : null}
            <span className="zoom-hint">{bn ? 'বড় করে দেখুন ⤢' : 'See it bigger ⤢'}</span>
          </button>

          {/* The close-ups: how the pocket, the cuff, the back and the lining are actually made. */}
          {gallery.length ? (
            <div className="gallery-strip">
              {gallery.map(shot => (
                <button
                  key={shot.id || shot.url + shot.label}
                  type="button"
                  onClick={() => setZoom({ src: shot.url, title: `${product.name} — ${shot.label}`, note: colour })}
                  aria-label={`${shot.label} — ${bn ? 'বড় করে দেখুন' : 'see it bigger'}`}
                >
                  <img src={thumb(shot.url)} alt={`${product.name} — ${shot.label} detail`} loading="lazy" width="400" height="400" />
                  <span>{shot.label}</span>
                </button>
              ))}
            </div>
          ) : null}

          {/* Every colour is a button: press it and the photograph and the price follow. */}
          <div className="colour-strip">
            {colours.map(c => (
              <button
                key={c.name}
                type="button"
                onClick={() => pickColour(c.name)}
                aria-pressed={colour === c.name}
                className={`chip ${colour === c.name ? 'on' : ''}`}
                title={c.name}
              >
                <span className="swatch" style={{ background: c.hex || '#2c3a4a' }} />
                <span>{c.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h1 style={{ fontSize: 'clamp(28px, 3.4vw, 42px)' }}>{product.name}</h1>
          <p className="muted" style={{ marginTop: 10 }}>{product.spec}</p>

          <p style={{ marginTop: 18 }}>{product.description}</p>
          <p className="hint" style={{ marginBottom: 22 }}>{t('product.priceNote')}</p>

          <form action={action} className="stack" style={{ gap: 22 }}>
            <input type="hidden" name="variant_id" value={active?.id || ''} />
            <input type="hidden" name="colour" value={colour} />
            <input type="hidden" name="design" value={design} />

            <div>
              <div className="between" style={{ alignItems: 'baseline' }}>
                <span className="label small-caps">{t('product.colour')}</span>
                <span className="muted small">{colour}</span>
              </div>
              <div className="colour-row">
                {colours.map(c => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => pickColour(c.name)}
                    aria-pressed={colour === c.name}
                    className={`colour-chip ${colour === c.name ? 'on' : ''}`}
                  >
                    <span className="swatch" style={{ background: c.hex || '#2c3a4a' }} />
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="between" style={{ alignItems: 'baseline' }}>
                <span className="label small-caps">{t('product.design')}</span>
                <span className="muted small">{t('product.designHint')}</span>
              </div>

              <div className="design-row">
                {designs.map((d, i) => {
                  const crop = designCrop(i);
                  const img = d.image || product.image;
                  const on = design === d.design;
                  return (
                    <div key={d.id} className={`design-box ${on ? 'on' : ''}`}>
                      <button
                        type="button"
                        className="design-img"
                        onClick={() => setZoom({ src: img, title: `${product.name} — ${d.design}`, note: `${d.colour} · ৳${fmt.format(d.price)}` })}
                        title={bn ? 'বড় করে দেখুন' : 'Open it bigger'}
                        aria-label={`${d.design} — ${bn ? 'বড় করে দেখুন' : 'open bigger'}`}
                      >
                        {img ? <img src={thumb(img)} alt={`${product.name} — ${d.design}`} loading="lazy" style={crop} /> : <span className="design-blank" aria-hidden="true" />}
                        {on ? <span className="design-tick" aria-hidden="true">✓</span> : null}
                        <span className="design-zoom" aria-hidden="true">⤢</span>
                      </button>
                      <button type="button" className="design-pick" onClick={() => setDesign(d.design)} aria-pressed={on}>
                        <b>{d.design}</b>
                        <small>
                          {d.fabric_name ? d.fabric_name : t('product.clothAtFitting')}
                          {Number(d.stock) > 0 ? ` · ${Number(d.stock)} ${t('product.cutReady')}` : ''}
                        </small>
                        <em>৳{fmt.format(d.price)}</em>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="field">
              <label htmlFor="brief">{t('product.brief')}</label>
              <textarea id="brief" name="brief" placeholder={t('product.briefPlaceholder')} />
              <p className="hint">{t('product.briefHint')}</p>
            </div>

            <div className="row" style={{ gap: 14, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <div className="field" style={{ width: 110 }}>
                <label htmlFor="qty">{t('product.qty')}</label>
                <input
                  id="qty"
                  name="qty"
                  type="number"
                  min="1"
                  max="50"
                  value={qty}
                  onChange={e => setQty(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
                />
              </div>
              <div style={{ flex: 1, minWidth: 140 }}>
                <div className="small muted">{t('product.lineTotal')}</div>
                <b style={{ fontFamily: 'var(--serif)', fontSize: 24 }}>৳{fmt.format((active?.price || 0) * qty)}</b>
                <div className="small muted">
                  {from === to ? `৳${fmt.format(from)}` : `৳${fmt.format(from)} – ৳${fmt.format(to)}`} · {active?.design}
                </div>
              </div>
              <button className="btn" type="submit">{t('product.add')}</button>
              <a className="btn outline wa-btn" href={waLink(productWaText(product.name, active?.price))} target="_blank" rel="noreferrer">
                {bn ? 'হোয়াটসঅ্যাপে জিজ্ঞেস করুন' : 'Ask on WhatsApp'}
              </a>
            </div>
          </form>

          <div className="row" style={{ marginTop: 20, gap: 10, flexWrap: 'wrap' }}>
            <a className="btn ghost small" href={telLink()}>{t('common.call')} · {PHONE_PRETTY}</a>
          </div>
        </div>
      </div>

      {zoom ? (
        <div className="lightbox" role="dialog" aria-modal="true" onClick={() => setZoom(null)}>
          <div className="lightbox-inner" onClick={e => e.stopPropagation()}>
            <button type="button" className="lightbox-close" onClick={() => setZoom(null)} aria-label={bn ? 'বন্ধ করুন' : 'Close'}>×</button>
            {zoom.src ? <img src={zoom.src} alt={zoom.title} /> : <div className="design-blank" />}
            <div className="lightbox-bar">
              <b>{zoom.title}</b>
              {zoom.note ? <small>{zoom.note}</small> : null}
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
