'use client';

import { useActionState, useState } from 'react';
import { placeOrder } from '@/app/actions/orders';
import { useLang } from '@/components/lang-provider';
import { telLink, waLink } from '@/lib/contact';

const fmt = new Intl.NumberFormat('en-US');

export default function CheckoutForm({ fabrics, subtotal, visitFee, visitFeeOutside, initialPayment, initialDiscuss }) {
  const { t } = useLang();
  const [state, formAction, pending] = useActionState(placeOrder, { error: null, errors: {}, values: {} });
  const [mode, setMode] = useState(state.values?.measurement_mode || 'home_visit');
  const [zone, setZone] = useState(state.values?.delivery_zone || 'inside_dhaka');
  const [payment, setPayment] = useState(state.values?.payment_option || initialPayment || 'advance');
  const [method, setMethod] = useState(state.values?.payment_method || 'bkash');
  const [discuss, setDiscuss] = useState(Boolean(initialDiscuss));

  const visit = mode === 'home_visit';
  // ৳150 inside Dhaka, ৳400 outside (video 1, 3:27) — the server charges the same numbers.
  const feeForZone = zone === 'outside_dhaka' ? Number(visitFeeOutside ?? 400) : Number(visitFee ?? 150);
  const total = subtotal + (visit ? feeForZone : 0);
  const due = payment === 'advance' ? feeForZone : total;

  return (
    <form action={formAction} className="stack" style={{ gap: 26 }}>
      {state.error ? <div className="alert bad">{state.error}</div> : null}

      <div className="panel">
        <p className="panel-title">01 · {t('checkout.who')}</p>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="customer_name">{t('checkout.name')}</label>
            <input id="customer_name" name="customer_name" defaultValue={state.values?.customer_name || ''} required />
            {state.errors?.customer_name ? <p className="error">{state.errors.customer_name}</p> : null}
          </div>
          <div className="field">
            <label htmlFor="customer_phone">{t('checkout.phone')}</label>
            <input id="customer_phone" name="customer_phone" inputMode="tel" defaultValue={state.values?.customer_phone || ''} placeholder="+8801XXXXXXXXX" required />
            {state.errors?.customer_phone ? <p className="error">{state.errors.customer_phone}</p> : null}
          </div>
          <div className="field full">
            <label htmlFor="customer_email">{t('checkout.email')}</label>
            <input id="customer_email" name="customer_email" type="email" defaultValue={state.values?.customer_email || ''} />
          </div>
        </div>
        <p className="hint">
          {t('checkout.who')} — {t('checkout.discussHint')}
        </p>
      </div>

      <div className="panel">
        <p className="panel-title">02 · {t('checkout.colourCloth')}</p>

        <div className="field">
          <label htmlFor="cloth_choice">{t('checkout.clothSelect')}</label>
          <select id="cloth_choice" name="cloth_choice" defaultValue={state.values?.cloth_choice || ''}>
            <option value="">{t('checkout.noPreference')}</option>
            {fabrics.map(f => (
              <option key={f.id} value={`${f.colour} ${f.name} (${f.code})`}>
                {f.colour} · {f.name} — ৳{fmt.format(f.price_per_yard)}/yd · {Number(f.yards_in_stock)} yd
              </option>
            ))}
          </select>
        </div>

        <div className="field" style={{ marginTop: 14 }}>
          <label htmlFor="item_brief">{t('checkout.brief')}</label>
          <textarea
            id="item_brief"
            name="item_brief"
            defaultValue={state.values?.item_brief || ''}
            placeholder={t('product.briefPlaceholder')}
          />
        </div>

        <label className="choice" style={{ marginTop: 14, cursor: 'pointer' }}>
          <input
            type="checkbox"
            name="wants_discussion"
            checked={discuss}
            onChange={e => setDiscuss(e.target.checked)}
            style={{ width: 16, height: 16, marginTop: 4 }}
          />
          <span>
            <b>{t('checkout.discuss')}</b>
            <span>{t('checkout.discussHint')}</span>
          </span>
        </label>

        {discuss ? (
          <div className="field" style={{ marginTop: 12 }}>
            <label htmlFor="discussion_topic">{t('checkout.topic')}</label>
            <textarea id="discussion_topic" name="discussion_topic" defaultValue={state.values?.discussion_topic || ''} />
            <p className="hint">
              <a href={waLink('অর্ডার নিয়ে কথা বলতে চাই।')} target="_blank" rel="noreferrer">{t('common.whatsapp')}</a>
              {' · '}
              <a href={telLink()}>{t('common.call')}</a>
            </p>
          </div>
        ) : null}
      </div>

      <div className="panel">
        <p className="panel-title">03 · {t('checkout.size')}</p>
        <div className="stack" style={{ gap: 10 }}>
          <label className={`choice ${mode === 'home_visit' ? 'active' : ''}`}>
            <input type="radio" name="measurement_mode" value="home_visit" checked={mode === 'home_visit'} onChange={() => setMode('home_visit')} style={{ width: 16, height: 16, marginTop: 4 }} />
            <span style={{ flex: 1 }}>
              <b>{t('checkout.visit')} — ৳{fmt.format(Number(visitFee ?? 150))} / ৳{fmt.format(Number(visitFeeOutside ?? 400))}</b>
              <span>{t('checkout.visitBody')}</span>
            </span>
          </label>
          <label className={`choice ${mode === 'own_size' ? 'active' : ''}`}>
            <input type="radio" name="measurement_mode" value="own_size" checked={mode === 'own_size'} onChange={() => setMode('own_size')} style={{ width: 16, height: 16, marginTop: 4 }} />
            <span style={{ flex: 1 }}>
              <b>{t('checkout.ownSize')}</b>
              <span>{t('checkout.ownSizeBody')}</span>
            </span>
          </label>
          <label className={`choice ${mode === 'discuss' ? 'active' : ''}`}>
            <input type="radio" name="measurement_mode" value="discuss" checked={mode === 'discuss'} onChange={() => setMode('discuss')} style={{ width: 16, height: 16, marginTop: 4 }} />
            <span style={{ flex: 1 }}>
              <b>{t('checkout.decideLater')}</b>
              <span>{t('checkout.decideLaterBody')}</span>
            </span>
          </label>
        </div>

        {visit ? (
          <div style={{ marginTop: 14 }}>
            <div className="stack" style={{ gap: 10 }}>
              <label className={`choice ${zone === 'inside_dhaka' ? 'active' : ''}`}>
                <input type="radio" name="delivery_zone" value="inside_dhaka" checked={zone === 'inside_dhaka'} onChange={() => setZone('inside_dhaka')} style={{ width: 16, height: 16, marginTop: 4 }} />
                <span style={{ flex: 1 }}>
                  <b>{t('checkout.zoneInside')} — ৳{fmt.format(Number(visitFee ?? 150))}</b>
                  <span>{t('checkout.zoneInsideBody')}</span>
                </span>
              </label>
              <label className={`choice ${zone === 'outside_dhaka' ? 'active' : ''}`}>
                <input type="radio" name="delivery_zone" value="outside_dhaka" checked={zone === 'outside_dhaka'} onChange={() => setZone('outside_dhaka')} style={{ width: 16, height: 16, marginTop: 4 }} />
                <span style={{ flex: 1 }}>
                  <b>{t('checkout.zoneOutside')} — ৳{fmt.format(Number(visitFeeOutside ?? 400))}</b>
                  <span>{t('checkout.zoneOutsideBody')}</span>
                </span>
              </label>
            </div>
          </div>
        ) : null}

        <div className="address-block" style={{ marginTop: 14 }}>
          <p className="label small-caps" style={{ marginBottom: 8 }}>
            {visit ? t('checkout.area') : t('checkout.address')}
          </p>
          <div className="form-grid">
            <div className="field">
              <label htmlFor="area">{t('checkout.area')}</label>
              <input
                id="area"
                name="area"
                list="dhaka-areas"
                defaultValue={state.values?.area || ''}
                placeholder={visit ? 'Dhanmondi, Dhaka' : 'e.g. Uttara, Dhaka'}
                autoComplete="address-level2"
              />
              <datalist id="dhaka-areas">
                {['Dhanmondi', 'Gulshan', 'Banani', 'Uttara', 'Mirpur', 'Mohammadpur', 'Bashundhara', 'Badda', 'Motijheel', 'Old Dhaka', 'Khilgaon', 'Rampura', 'Tejgaon', 'Farmgate', 'Shyamoli', 'Savar', 'Narayanganj', 'Gazipur', 'Chattogram', 'Sylhet'].map(a => (
                  <option key={a} value={a} />
                ))}
              </datalist>
              <p className="hint" style={{ margin: 0 }}>
                {visit
                  ? zone === 'outside_dhaka' ? t('checkout.zoneOutsideBody') : t('checkout.zoneInsideBody')
                  : t('checkout.ownSizeBody')}
              </p>
            </div>

            <div className="field">
              <label htmlFor="address">{t('checkout.address')}</label>
              <textarea
                id="address"
                name="address"
                rows={2}
                defaultValue={state.values?.address || ''}
                placeholder="House 12, Road 5, Floor 3 — flat 3B"
                autoComplete="street-address"
              />
              {state.errors?.address ? <p className="error">{state.errors.address}</p> : null}
              <p className="hint" style={{ margin: 0 }}>
                {visit
                  ? 'Our person needs the house, the road and the floor to find you.'
                  : 'Where should the finished piece be delivered?'}
              </p>
            </div>
          </div>
          <p className="hint" style={{ marginTop: 8 }}>
            <a href={telLink()}>{t('common.call')}</a> · <a href={waLink('ঠিকানাটা হোয়াটসঅ্যাপে পাঠাতে চাই।')} target="_blank" rel="noreferrer">{t('common.whatsapp')}</a>
            {' '}— ঠিকানা লিখতে না চাইলে ফোনে বা হোয়াটসঅ্যাপে বলে দিলেও চলবে।
          </p>
        </div>

        {mode === 'own_size' ? (
          <div className="field" style={{ marginTop: 14 }}>
            <label htmlFor="measurement_note">{t('checkout.measureNote')}</label>
            <textarea
              id="measurement_note"
              name="measurement_note"
              defaultValue={state.values?.measurement_note || ''}
              placeholder="e.g. L, or chest 40, waist 34, shoulder 18, sleeve 25, length 30, collar 16 (inches)"
            />
          </div>
        ) : null}
      </div>

      <div className="panel">
        <p className="panel-title">04 · {t('checkout.pay')}</p>
        <div className="stack" style={{ gap: 10 }}>
          {visit ? (
            <label className={`choice ${payment === 'advance' ? 'active' : ''}`}>
              <input type="radio" name="payment_option" value="advance" checked={payment === 'advance'} onChange={() => setPayment('advance')} style={{ width: 16, height: 16, marginTop: 4 }} />
              <span style={{ flex: 1 }}>
                <b>{t('checkout.payAdvance')} — ৳{fmt.format(feeForZone)}</b>
                <span>{t('checkout.payAdvanceBody')}</span>
              </span>
              <b style={{ fontFamily: 'var(--serif)' }}>৳{fmt.format(feeForZone)}</b>
            </label>
          ) : null}
          <label className={`choice ${payment === 'full' ? 'active' : ''}`}>
            <input type="radio" name="payment_option" value="full" checked={payment === 'full'} onChange={() => setPayment('full')} style={{ width: 16, height: 16, marginTop: 4 }} />
            <span style={{ flex: 1 }}>
              <b>{t('checkout.payFull')}</b>
              <span>{t('checkout.payFullBody')}</span>
            </span>
            <b style={{ fontFamily: 'var(--serif)' }}>৳{fmt.format(total)}</b>
          </label>
        </div>

        <div style={{ marginTop: 18 }}>
          <p className="label small-caps">{t('pay.howToPay')}</p>
          <div className="stack" style={{ gap: 10, marginTop: 8 }}>
            {[
              ['bkash', 'bKash', t('pay.bkashBody')],
              ['nagad', 'Nagad', t('pay.nagadBody')],
              ['card', t('pay.card'), t('pay.cardBody')]
            ].map(([value, label, body]) => (
              <label key={value} className={`choice ${method === value ? 'active' : ''}`}>
                <input
                  type="radio"
                  name="payment_method"
                  value={value}
                  checked={method === value}
                  onChange={() => setMethod(value)}
                  style={{ width: 16, height: 16, marginTop: 4 }}
                />
                <span style={{ flex: 1 }}>
                  <b>{label}</b>
                  <span>{body}</span>
                </span>
              </label>
            ))}
          </div>
        </div>

        <div className="field" style={{ marginTop: 14 }}>
          <label htmlFor="notes">{t('checkout.notes')}</label>
          <textarea id="notes" name="notes" defaultValue={state.values?.notes || ''} />
        </div>

        <div style={{ marginTop: 18 }}>
          <div className="kv"><span>{t('checkout.pieces')}</span><b>৳{fmt.format(subtotal)}</b></div>
          {visit ? <div className="kv"><span>{t('checkout.visitFee')} · {zone === 'outside_dhaka' ? t('checkout.zoneOutside') : t('checkout.zoneInside')}</span><b>৳{fmt.format(feeForZone)}</b></div> : null}
          <div className="kv total"><span>{t('checkout.orderTotal')}</span><b>৳{fmt.format(total)}</b></div>
          <div className="kv"><span>{t('checkout.payingNow')}</span><b>৳{fmt.format(due)}</b></div>
        </div>

        <div className="row" style={{ marginTop: 18, justifyContent: 'space-between', flexWrap: 'wrap', gap: 14 }}>
          <p className="hint" style={{ maxWidth: 430, margin: 0 }}>{t('checkout.hint')}</p>
          <button className="btn" type="submit" disabled={pending}>
            {pending ? t('checkout.placing') : `${t('checkout.submit')} · ৳${fmt.format(due)}`}
          </button>
        </div>
      </div>
    </form>
  );
}
