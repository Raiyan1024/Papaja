'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import LangToggle from '@/components/lang-toggle';

/**
 * The Menu button. It used to stay open after you picked a line, because the browser only
 * closes a <details> when you click the summary again. Now picking anything closes it, and so
 * does going to a new page.
 */
export default function MobileMenu({ items, lang, user }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);

  return (
    <div className={`mobile-menu ${open ? 'open' : ''}`}>
      <button
        type="button"
        className="mobile-menu-btn"
        aria-expanded={open}
        aria-controls="mobile-links"
        onClick={() => setOpen(o => !o)}
      >
        {open ? (lang === 'bn' ? 'বন্ধ' : 'Close') : (lang === 'bn' ? 'মেনু' : 'Menu')}
      </button>

      {open ? (
        <>
          <button type="button" className="mobile-menu-scrim" aria-label="Close" onClick={() => setOpen(false)} />
          <nav className="mobile-links" id="mobile-links" aria-label="Categories and pages">
            {items.map(([href, label]) => (
              <Link key={href} href={href} onClick={() => setOpen(false)}>{label}</Link>
            ))}
            <hr />
            <Link href="/cart" onClick={() => setOpen(false)}>{lang === 'bn' ? 'আমার অর্ডার' : 'My order'}</Link>
            <div style={{ padding: '10px 4px 2px' }}><LangToggle /></div>
          </nav>
        </>
      ) : null}
    </div>
  );
}
