'use client';

import { useRouter } from 'next/navigation';
import { useTransition } from 'react';
import { LANGS } from '@/lib/i18n';
import { useLang } from '@/components/lang-provider';

/** Sets the language cookie and re-renders the server components in place. */
export default function LangToggle({ compact = false }) {
  const router = useRouter();
  const { lang } = useLang();
  const [pending, start] = useTransition();

  function pick(code) {
    if (code === lang) return;
    document.cookie = `th_lang=${code}; path=/; max-age=${60 * 60 * 24 * 365}; samesite=lax`;
    start(() => router.refresh());
  }

  return (
    <div className={`lang-toggle ${pending ? 'busy' : ''}`} role="group" aria-label="Language">
      {LANGS.map(l => (
        <button
          key={l.code}
          type="button"
          onClick={() => pick(l.code)}
          aria-pressed={lang === l.code}
          title={l.label}
          lang={l.code}
        >
          {compact ? l.short : l.label}
        </button>
      ))}
    </div>
  );
}
