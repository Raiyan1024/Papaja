'use client';

import { useActionState } from 'react';
import { t } from '@/lib/i18n';

/**
 * The customer pastes the TrxID from the bKash/Nagad SMS. Nothing is charged here —
 * this only records the claim for the shopkeeper to check.
 */
export default function ManualPaymentForm({ action, tranId, code, lang }) {
  const [state, formAction, pending] = useActionState(action, {});

  return (
    <form action={formAction} className="panel" style={{ marginTop: 18 }}>
      <p className="panel-title">TrxID</p>
      <input type="hidden" name="tran_id" value={tranId} />
      <input type="hidden" name="code" value={code} />

      {state?.error ? <div className="alert warn" style={{ marginBottom: 14 }}>{state.error}</div> : null}

      <div className="grid-2">
        <div className="field">
          <label htmlFor="trx_id">
            TrxID <span className="muted small">{lang === 'bn' ? '(SMS থেকে)' : '(from the SMS)'}</span>
          </label>
          <input
            id="trx_id"
            name="trx_id"
            required
            autoComplete="off"
            spellCheck="false"
            placeholder="9F7A2KD10X"
            style={{ textTransform: 'uppercase', letterSpacing: 1 }}
          />
        </div>

        <div className="field">
          <label htmlFor="sender_number">
            {lang === 'bn' ? 'যে নম্বর থেকে পাঠিয়েছেন' : 'The number you paid from'}{' '}
            <span className="muted small">{lang === 'bn' ? '(ঐচ্ছিক)' : '(optional)'}</span>
          </label>
          <input id="sender_number" name="sender_number" inputMode="tel" placeholder="01XXXXXXXXX" />
        </div>
      </div>

      <div className="field">
        <label htmlFor="payer_note">
          {lang === 'bn' ? 'কিছু বলার থাকলে' : 'Anything we should know'}{' '}
          <span className="muted small">{lang === 'bn' ? '(ঐচ্ছিক)' : '(optional)'}</span>
        </label>
        <input id="payer_note" name="payer_note" placeholder={lang === 'bn' ? 'যেমন: ভাইয়ের নম্বর থেকে পাঠিয়েছি' : 'e.g. sent from my brother’s number'} />
      </div>

      <button className="btn" type="submit" disabled={pending} style={{ marginTop: 6 }}>
        {pending
          ? lang === 'bn' ? 'পাঠানো হচ্ছে…' : 'Sending…'
          : lang === 'bn' ? 'TrxID পাঠান' : 'Send the TrxID for checking'}
      </button>

      <p className="hint" style={{ marginTop: 12 }}>
        {lang === 'bn'
          ? 'TrxID পাঠালেই অর্ডার কনফার্ম হয়ে যায় না — আমরা বিকাশ/নগদ স্টেটমেন্টে মিলিয়ে দেখি, তারপর কনফার্ম করি।'
          : 'Sending the TrxID does not confirm the order by itself — we match it against the bKash/Nagad statement first.'}
      </p>
    </form>
  );
}
