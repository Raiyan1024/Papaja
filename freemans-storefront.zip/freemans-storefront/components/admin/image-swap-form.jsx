'use client';

import { useState } from 'react';
import PhotoField from '@/components/admin/photo-field';

/** Swap one photograph (the product's own, or one design's) without touching anything else. */
export default function ImageSwapForm({ action, id, value = '', label = 'Photo', submitLabel = 'Save photo' }) {
  const [url, setUrl] = useState(value || '');

  return (
    <form action={action} className="row" style={{ gap: 10, alignItems: 'flex-start', flexWrap: 'wrap' }}>
      <input type="hidden" name="id" value={id} />
      <PhotoField name="image" value={url} onChangeUrl={setUrl} label={label} hint="" />
      <button className="btn small" type="submit" disabled={!url || url === value}>{submitLabel}</button>
    </form>
  );
}
