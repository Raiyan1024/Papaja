'use client';

import { useState } from 'react';

/** Two ways of doing the same job on one screen — press the one you want. */
export default function Tabs({ tabs, initial = 0 }) {
  const [index, setIndex] = useState(initial);

  return (
    <div>
      <div className="pay-tabs" role="tablist">
        {tabs.map((tab, i) => (
          <button
            key={tab.key || i}
            type="button"
            role="tab"
            aria-selected={i === index}
            className={`pay-tab ${i === index ? 'on' : ''}`}
            onClick={() => setIndex(i)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div style={{ marginTop: 18 }}>{tabs[index]?.content}</div>
    </div>
  );
}
