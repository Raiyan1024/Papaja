'use client';

import { useActionState, useMemo, useState } from 'react';
import PhotoField from '@/components/admin/photo-field';
import { addVariantState } from '@/app/actions/admin';
import { guessColour } from '@/lib/colours';

const fmt = new Intl.NumberFormat('en-US');

/**
 * Put one new design into a piece that already exists — its own colour, name, price, stock and,
 * if you have one, its own photograph. It lands in that piece's design boxes immediately.
 */
export default function AddDesignForm({ products, defaultProduct }) {
  const [state, formAction, pending] = useActionState(addVariantState, { error: null });
  const [productId, setProductId] = useState(String(defaultProduct || products[0]?.id || ''));
  const [colour, setColour] = useState('');
  const [design, setDesign] = useState('');
  const [price, setPrice] = useState('');
  const [stock, setStock] = useState('');
  const [image, setImage] = useState('');

  const product = useMemo(() => products.find(p => String(p.id) === String(productId)), [products, productId]);
  const siblings = product?.designs || [];
  const sameName = siblings.filter(d => d.colour.toLowerCase() === colour.trim().toLowerCase() && d.design.toLowerCase() === (design.trim() || 'House style').toLowerCase());

  return (
    <form action={formAction} className="stack" style={{ gap: 16 }}>
      {state?.error ? <div className="alert bad">{state.error}</div> : null}

      <div className="panel">
        <p className="panel-title">01 · Which piece is it going into?</p>
        <div className="form-grid">
          <div className="field full">
            <label htmlFor="product_id">The piece (style)</label>
            <select id="product_id" name="product_id" value={productId} onChange={e => setProductId(e.target.value)} required>
              {products.map(p => (
                <option key={p.id} value={p.id}>
                  {p.category_name} — {p.name}{p.active ? '' : ' (hidden)'}
                </option>
              ))}
            </select>
            <p className="hint">
              {siblings.length
                ? `${siblings.length} colour × design already on this piece: ${siblings.slice(0, 6).map(d => `${d.colour} / ${d.design}`).join(' · ')}${siblings.length > 6 ? ' …' : ''}`
                : 'This piece has no colours yet — this will be its first.'}
            </p>
          </div>
        </div>
      </div>

      <div className="panel">
        <p className="panel-title">02 · The new design</p>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="colour">Colour · রঙ</label>
            <input id="colour" name="colour" value={colour} onChange={e => setColour(e.target.value)} placeholder="Olive" maxLength={40} required />
            <span className="row" style={{ gap: 8, marginTop: 6 }}>
              <span className="swatch" style={{ background: guessColour(colour), width: 20, height: 20 }} />
              <span className="hint" style={{ margin: 0 }}>the dot the customer sees</span>
            </span>
          </div>

          <div className="field">
            <label htmlFor="design">Design · ডিজাইন</label>
            <input id="design" name="design" value={design} onChange={e => setDesign(e.target.value)} placeholder="House style" maxLength={60} />
            <p className="hint" style={{ margin: 0 }}>e.g. Double-breasted, Slim shorter jacket</p>
          </div>

          <div className="field">
            <label htmlFor="price">Price · দাম (৳)</label>
            <input id="price" name="price" type="number" min="0" step="50" value={price} onChange={e => setPrice(e.target.value)} placeholder="12500" required />
          </div>

          <div className="field">
            <label htmlFor="stock">Ready to cut · স্টক</label>
            <input id="stock" name="stock" type="number" min="0" step="1" value={stock} onChange={e => setStock(e.target.value)} placeholder="2" />
          </div>

          <div className="field full">
            <label>Photo for this design · ছবি (ঐচ্ছিক)</label>
            <PhotoField
              name="image"
              label={`${colour || 'the new design'} photo`}
              value={image}
              onChangeUrl={setImage}
              hint="Leave it empty and the piece's main photo is used, with its own crop."
            />
          </div>
        </div>

        <div className="row" style={{ gap: 10, marginTop: 12, flexWrap: 'wrap' }}>
          <button className="btn" type="submit" disabled={pending}>
            {pending ? 'Saving…' : 'Put it in the boxes'}
          </button>
          <span className="hint" style={{ margin: 0 }}>
            {price && Number(price) > 0
              ? `${colour || 'this design'} · ৳${fmt.format(Number(price))}${stock ? ` · ${stock} ready` : ''}`
              : 'A price is the only thing it cannot go without.'}
          </span>
        </div>

        {sameName.length ? (
          <div className="alert warn" style={{ marginTop: 12 }}>
            This piece already has <b>{sameName[0].colour} / {sameName[0].design}</b> at ৳{fmt.format(sameName[0].price)}.
            Saving again replaces its price and stock instead of making a duplicate.
          </div>
        ) : null}
      </div>
    </form>
  );
}
