'use client';

import { useRef, useState } from 'react';

/**
 * A photograph picker for the admin panel.
 *
 * The browser shrinks the picture before it leaves the phone (1400px on the long edge, JPEG),
 * so a 6 MB camera photo becomes a couple of hundred kilobytes and still looks sharp on the
 * site. The photograph is then uploaded straight away and the URL is kept in a hidden field,
 * which is what the form saves.
 */
async function shrink(file, max = 1400, quality = 0.82) {
  const loadBitmap = async () => {
    if (typeof createImageBitmap === 'function') {
      try {
        return await createImageBitmap(file, { imageOrientation: 'from-image' });
      } catch {
        /* fall through to the <img> route */
      }
    }
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error('That file is not a picture we can read'));
        el.src = url;
      });
      return img;
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    }
  };

  const bitmap = await loadBitmap();
  const w = bitmap.width || bitmap.naturalWidth;
  const h = bitmap.height || bitmap.naturalHeight;
  const scale = Math.min(1, max / Math.max(w, h));
  const width = Math.max(1, Math.round(w * scale));
  const height = Math.max(1, Math.round(h * scale));

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(bitmap, 0, 0, width, height);

  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', quality));
  return { blob, width, height };
}

export default function PhotoField({
  name = 'image',
  label = 'Photograph',
  value = '',
  productId = '',
  variantId = '',
  hint = 'JPG or PNG from your phone. It is shrunk automatically — a big photo is fine.',
  onChangeUrl
}) {
  const [url, setUrl] = useState(value || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);

  function set(next) {
    setUrl(next);
    if (onChangeUrl) onChangeUrl(next);
  }

  async function upload(file) {
    setError(null);
    setBusy(true);
    try {
      const { blob, width, height } = await shrink(file);
      const body = new FormData();
      body.append('file', blob, 'photo.jpg');
      body.append('width', String(width));
      body.append('height', String(height));
      if (productId) body.append('product_id', String(productId));
      if (variantId) body.append('variant_id', String(variantId));
      const res = await fetch('/api/admin/upload', { method: 'POST', body });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'The upload failed');
      set(data.url);
    } catch (e) {
      setError(e.message || 'The upload failed');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  }

  return (
    <div className="photo-field">
      <input type="hidden" name={name} value={url} />

      <div className="photo-preview">
        {url ? (
          <img src={url} alt={label} />
        ) : (
          <span className="photo-blank">{busy ? 'Uploading…' : 'No photo yet'}</span>
        )}
      </div>

      <div className="photo-controls">
        <label className="btn small outline" style={{ cursor: 'pointer' }}>
          {busy ? 'Uploading…' : url ? 'Change photo' : 'Choose a photo'}
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            capture="environment"
            style={{ display: 'none' }}
            onChange={e => {
              const file = e.target.files?.[0];
              if (file) upload(file);
            }}
          />
        </label>
        {url ? (
          <button type="button" className="btn ghost small" onClick={() => set('')}>
            Remove
          </button>
        ) : null}
        <span className="hint" style={{ margin: 0 }}>{busy ? 'Shrinking and saving…' : hint}</span>
      </div>

      {error ? <p className="error">{error}</p> : null}
    </div>
  );
}
