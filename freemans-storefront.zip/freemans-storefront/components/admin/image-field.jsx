'use client';

import { useState } from 'react';
import PhotoField from '@/components/admin/photo-field';

/** A photograph field that works inside a plain server-action form. */
export default function ImageField({ name = 'image', label = 'Photo' }) {
  const [url, setUrl] = useState('');
  return <PhotoField name={name} value={url} onChangeUrl={setUrl} label={label} hint="" />;
}
