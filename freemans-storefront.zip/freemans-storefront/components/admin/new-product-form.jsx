'use client';

import { useActionState, useState } from 'react';
import Link from 'next/link';
import PhotoField from '@/components/admin/photo-field';
import { createProduct } from '@/app/actions/admin';
import { guessColour } from '@/lib/colours';

const fmt = new Intl.NumberFormat('en-US');

const emptyRow = () => ({ colour: '', design: 'House style', price: '', stock: '', image: '' });

export default function NewProductForm({ categories, defaultCategory }) {
  const [state, formAction, pending] = useActionState(createProduct, { error: null });
  const [image, setImage] = useState('');
  const [rows, setRows] = useState([emptyRow(), emptyRow()]);

  function patch(index, key, value) {
    setRows(list => list.map((row, i) => (i === index ? { ...row, [key]: value } : row)));
  }
  function addRow() {
    setRows(list => [...list, emptyRow()]);
  }
  function removeRow(index) {
    setRows(list => (list.length === 1 ? list : list.filter((_, i) => i !== index)));
  }

  const filled = rows.filter(r => r.colour.trim() && Number(r.price) > 0);

  return (
    <form action={formAction} className="stack" style={{ gap: 18 }}>
      {state?.error ? <div className="alert bad">{state.error}</div> : null}

      <div className="panel">
        <p className="panel-title">01 · The piece</p>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="category_id">Which line of the shop?</label>
            <select id="category_id" name="category_id" defaultValue={defaultCategory || categories[0]?.id} required>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          <div className="field">
            <label htmlFor="name">Name the customer reads</label>
            <input id="name" name="name" placeholder="e.g. The olive double-breasted" required maxLength={120} />
          </div>

          <div className="field">
            <label htmlFor="summary">One line under the name</label>
            <input id="summary" name="summary" placeholder="e.g. The summer wedding jacket." maxLength={200} />
          </div>

          <div className="field">
            <label htmlFor="spec">The small caps line</label>
            <input id="spec" name="spec" placeholder="e.g. Double-breasted · peak lapel · ticket pocket" maxLength={160} />
          </div>

          <div className="field full">
            <label htmlFor="description">The description</label>
            <textarea
              id="description"
              name="description"
              rows={4}
              placeholder="How it is cut, when to wear it, what cloth it suits."
              maxLength={2000}
            />
            <p className="hint">Write it the way you would explain it to a customer standing in the shop.</p>
          </div>
        </div>
      </div>

      <div className="panel">
        <p className="panel-title">02 · The photo</p>
        <PhotoField
          name="image"
          label="The main photo of this piece"
          value={image}
          onChangeUrl={setImage}
          hint="This is the photo on the cards and the top of the product page. Straight from your phone is fine."
        />
      </div>

      <div className="panel">
        <p className="panel-title">03 · Colours, designs, prices and stock</p>
        <p className="hint" style={{ marginTop: 0 }}>
          One line = one colour + one design at its own price. This is exactly what the customer
          picks from. Add as many as the piece comes in.
        </p>

        <div className="stack" style={{ gap: 12 }}>
          {rows.map((row, index) => (
            <div key={index} className="variant-row">
              <div className="field">
                <label>Colour</label>
                <input
                  value={row.colour}
                  onChange={e => patch(index, 'colour', e.target.value)}
                  placeholder="Navy"
                  maxLength={40}
                />
                <span
                  className="swatch"
                  style={{ background: guessColour(row.colour), marginTop: 6, width: 22, height: 22 }}
                  title="The swatch the customer sees"
                />
              </div>
              <div className="field">
                <label>Design</label>
                <input
                  value={row.design}
                  onChange={e => patch(index, 'design', e.target.value)}
                  placeholder="House style"
                  maxLength={60}
                />
              </div>
              <div className="field">
                <label>Price (৳)</label>
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={row.price}
                  onChange={e => patch(index, 'price', e.target.value)}
                  placeholder="12500"
                />
              </div>
              <div className="field">
                <label>Ready to cut</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={row.stock}
                  onChange={e => patch(index, 'stock', e.target.value)}
                  placeholder="3"
                />
              </div>
              <div className="field" style={{ minWidth: 190 }}>
                <label>Photo for this design (optional)</label>
                <PhotoField
                  name=""
                  label={`Photo for ${row.colour || 'this design'}`}
                  value={row.image}
                  onChangeUrl={url => patch(index, 'image', url)}
                  hint="Leave empty to use the main photo."
                />
              </div>
              <button type="button" className="btn ghost small" onClick={() => removeRow(index)} aria-label="Remove this line">
                Remove
              </button>
            </div>
          ))}
        </div>

        <div className="row" style={{ gap: 10, marginTop: 12, flexWrap: 'wrap' }}>
          <button type="button" className="btn outline small" onClick={addRow}>+ Add another colour / design</button>
          <span className="hint" style={{ margin: 0 }}>
            {filled.length ? `${filled.length} line${filled.length > 1 ? 's' : ''} ready · from ৳${fmt.format(Math.min(...filled.map(r => Number(r.price))))}` : 'Add at least one line with a price.'}
          </span>
        </div>

        <input type="hidden" name="variants" value={JSON.stringify(rows)} />
      </div>

      <div className="row" style={{ gap: 10, flexWrap: 'wrap' }}>
        <button className="btn" type="submit" disabled={pending}>
          {pending ? 'Saving…' : 'Save the new piece'}
        </button>
        <Link href="/admin/products" className="btn outline">Cancel</Link>
        <span className="hint" style={{ margin: 0 }}>It appears in the shop the moment you save it.</span>
      </div>
    </form>
  );
}
