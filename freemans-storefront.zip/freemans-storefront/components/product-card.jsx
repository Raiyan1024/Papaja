import Link from 'next/link';
import { taka } from '@/lib/money';
import { t } from '@/lib/i18n';
import { swatchColour } from '@/lib/colours';
import { thumb } from '@/lib/thumbs';

export default function ProductCard({ product, lang = 'en' }) {
  const colours = product.colours || [];
  const from = Number(product.from_price || 0);
  const to = Number(product.to_price || 0);
  const inStock = Number(product.stock || 0) > 0;
  const href = `/product/${product.slug}`;

  return (
    <article className="card">
      <Link href={href} className="thumb">
        {product.image ? <img src={thumb(product.image)} alt={`${product.name} — ${product.category_name} cut to measure in Dhaka`} loading="lazy" width="400" height="400" /> : null}
        <span className="tag">{product.category_name}</span>
        {product.variant_count > 3 ? (
          <span className="tag alt">{product.variant_count} {t(lang, 'common.designs')}</span>
        ) : null}
      </Link>

      <div className="body">
        <Link href={href}><h3>{product.name}</h3></Link>
        <p className="muted small" style={{ margin: 0 }}>{product.summary}</p>
        <div className="meta">{product.spec}</div>

        <div className="foot">
          <div>
            <div className="price">{from === to ? taka(from) : `${taka(from)} – ${taka(to)}`}</div>
            <div className="swatches" style={{ marginTop: 8 }}>
              {colours.slice(0, 7).map(c => (
                <Link
                  key={c}
                  href={`${href}?colour=${encodeURIComponent(c)}`}
                  className="swatch link"
                  title={`${c} — ${t(lang, 'common.choose')}`}
                  style={{ background: swatchColour(c) }}
                  aria-label={c}
                />
              ))}
              {colours.length > 7 ? <span className="swatch-more">+{colours.length - 7}</span> : null}
            </div>
          </div>
          <span className={`pill ${inStock ? 'good' : 'warn'}`}>
            {inStock ? t(lang, 'common.madeToOrder') : t(lang, 'common.askUs')}
          </span>
        </div>

        <Link href={href} className="btn small wide">{t(lang, 'common.order')}</Link>
      </div>
    </article>
  );
}
