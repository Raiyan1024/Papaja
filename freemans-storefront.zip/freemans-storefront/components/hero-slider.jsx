'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useLang } from '@/components/lang-provider';

const fmt = new Intl.NumberFormat('en-US');

/**
 * The hero photograph, changing every two seconds through the house's own pieces —
 * suits, blazers, the scout uniform and everything else on the wall.
 */
export default function HeroSlider({ slides = [], interval = 2000 }) {
  const { t } = useLang();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (slides.length < 2 || paused) return;
    const id = setInterval(() => setIndex(i => (i + 1) % slides.length), interval);
    return () => clearInterval(id);
  }, [slides.length, interval, paused]);

  if (!slides.length) return null;
  const current = slides[index] || slides[0];

  return (
    <div
      className="slider"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <Link href={current.href || '/suits'} className="slider-frame" aria-label={current.name}>
        {slides.map((s, i) => (
          <img
            key={s.src + i}
            src={s.src}
            alt={s.name}
            className={i === index ? 'on' : ''}
            loading={i === 0 ? 'eager' : 'lazy'}
            aria-hidden={i === index ? undefined : 'true'}
          />
        ))}
        <span className="tag">{current.label || current.category}</span>
      </Link>

      <div className="slider-bar">
        <div>
          <b>{current.name}</b>
          <small>
            {current.category}
            {current.price ? ` · ${t('common.from')} ৳${fmt.format(current.price)}` : ''}
          </small>
        </div>
        <Link href={current.href || '/suits'} className="btn tiny">{t('common.view')}</Link>
      </div>

      <div className="slider-dots" role="tablist" aria-label="Featured pieces">
        {slides.map((s, i) => (
          <button
            key={i}
            type="button"
            role="tab"
            aria-selected={i === index}
            aria-label={s.name}
            className={i === index ? 'on' : ''}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </div>
  );
}
