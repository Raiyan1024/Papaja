'use client';

import { createContext, useContext } from 'react';
import { t as translate } from '@/lib/i18n';

const LangContext = createContext({ lang: 'en', t: (key, vars) => translate('en', key, vars) });

export function LangProvider({ lang, children }) {
  const value = {
    lang,
    t: (key, vars) => translate(lang, key, vars)
  };
  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export function useLang() {
  return useContext(LangContext);
}
