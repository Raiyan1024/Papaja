import Link from 'next/link';
import { cartDetails } from '@/lib/cart';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import LangToggle from '@/components/lang-toggle';
import MobileMenu from '@/components/mobile-menu';
import { SHOP_LOCKUP, SHOP_LOCKUP_SUB } from '@/lib/contact';

const CATS = [
  ['/suits', 'nav.suits'],
  ['/blazers', 'nav.blazers'],
  ['/trousers', 'nav.trousers'],
  ['/shirts', 'nav.shirts'],
  ['/uniforms', 'nav.uniforms']
];

/**
 * The shop's own header. Deliberately free of shopkeeper links: the admin panel is reached by
 * typing /admin/login, never by a button a customer could press.
 */
export default async function SiteHeader() {
  const [{ count }, lang] = await Promise.all([
    cartDetails().catch(() => ({ count: 0 })),
    getLang()
  ]);

  const items = [
    ...CATS.map(([href, key]) => [href, t(lang, key)]),
    ['/order', t(lang, 'nav.howToOrder')],
    ['/visit', `${t(lang, 'nav.homeVisit')} — ৳150`]
  ];

  return (
    <header className="nav-shell">
      <div className="notice">
        {lang === 'bn'
          ? 'বাসায় মাপ নেওয়া — ঢাকার ভেতরে ৳১৫০, বাইরে ৳৪০০ · অ্যাকাউন্ট ছাড়াই অর্ডার · হোয়াটসঅ্যাপে কথা বলুন'
          : 'Home measuring visit — ৳150 inside Dhaka, ৳400 outside · Order without an account · WhatsApp us'}
      </div>

      <div className="wrap nav">
        <Link href="/" className="brand lockup">
          <b>{SHOP_LOCKUP}</b>
          <small>{SHOP_LOCKUP_SUB}</small>
        </Link>

        <nav className="links" aria-label="Categories">
          {CATS.map(([href, key]) => (
            <Link key={href} href={href}>{t(lang, key)}</Link>
          ))}
          <Link href="/order">{t(lang, 'nav.howToOrder')}</Link>
          <Link href="/visit">{t(lang, 'nav.homeVisit')}</Link>
        </nav>

        <MobileMenu items={items} lang={lang} />

        <div className="nav-tools">
          <LangToggle compact />
          <Link href="/cart" className={`btn small ${count ? '' : 'outline'}`}>
            {t(lang, 'nav.order')}{count ? ` · ${count}` : ''}
          </Link>
        </div>
      </div>
    </header>
  );
}
