import Link from 'next/link';

/**
 * Shown instead of a 404 when the app is running but the catalogue tables are empty —
 * i.e. a fresh deployment where `npm run db:setup` has not been run yet.
 */
export default function SetupNotice({ what = 'page' }) {
  return (
    <section className="wrap tight">
      <p className="eyebrow">The catalogue</p>
      <h1 style={{ maxWidth: 720 }}>The shop is deployed. The catalogue is not in it yet.</h1>
      <p className="muted" style={{ maxWidth: 620, marginTop: 14 }}>
        Nothing is broken — the database this {what} reads from is empty. Run the setup script once
        against the production database and every style, colour, design and price appears here.
      </p>
      <div className="panel" style={{ marginTop: 26, maxWidth: 620 }}>
        <p className="meta small muted" style={{ marginTop: 0 }}>On your machine, from the project folder</p>
        <pre style={{ margin: '10px 0 0', fontSize: 13, overflowX: 'auto' }}>npm run db:setup</pre>
        <p className="muted small" style={{ marginBottom: 0 }}>
          It creates the tables, the four lines, thirteen styles, eleven fabrics and the admin account,
          and it is safe to run more than once.
        </p>
      </div>
      <p style={{ marginTop: 24 }}>
        <Link className="btn" href="/">Back to the front of the shop</Link>
      </p>
    </section>
  );
}
