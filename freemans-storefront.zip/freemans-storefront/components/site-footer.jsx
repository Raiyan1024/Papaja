import Link from 'next/link';
import { getLang } from '@/lib/lang';
import { t } from '@/lib/i18n';
import { PHONE_PRETTY, telLink, waLink, SHOP_NAME, SHOP_ADDRESS } from '@/lib/contact';

export default async function SiteFooter() {
  const lang = await getLang();

  return (
    <footer className="site-foot">
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <h4>{SHOP_NAME}</h4>
            <p>{t(lang, 'foot.houseBody')}</p>
            <p className="muted small" style={{ marginTop: 6 }}>{SHOP_ADDRESS}</p>
            <p className="muted">{t(lang, 'foot.prices')}</p>
          </div>

          <div>
            <h4>{t(lang, 'foot.shop')}</h4>
            <Link href="/suits">{t(lang, 'nav.suits')}</Link>
            <Link href="/blazers">{t(lang, 'nav.blazers')}</Link>
            <Link href="/trousers">{t(lang, 'nav.trousers')}</Link>
            <Link href="/shirts">{t(lang, 'nav.shirts')}</Link>
            <Link href="/uniforms">{t(lang, 'nav.uniforms')}</Link>
          </div>

          <div>
            <h4>{t(lang, 'foot.ordering')}</h4>
            <Link href="/order">{t(lang, 'nav.howToOrder')}</Link>
            <Link href="/visit">{t(lang, 'nav.homeVisit')} — ৳150</Link>
            <Link href="/cart">{t(lang, 'cart.title')}</Link>
          </div>

          <div>
            <h4>{t(lang, 'foot.contact')}</h4>
            <p className="muted small">{t(lang, 'foot.contactBody')}</p>
            <div className="foot-contact">
              <a className="btn small wa-btn" href={waLink(lang === 'bn' ? 'আসসালামু আলাইকুম, অর্ডার নিয়ে কথা বলতে চাই।' : 'Hello, I would like to talk about an order.')} target="_blank" rel="noreferrer">
                {t(lang, 'common.whatsapp')}
              </a>
              <a className="btn small outline" href={telLink()}>{t(lang, 'common.call')} · {PHONE_PRETTY}</a>
            </div>
          </div>
        </div>

        <div className="foot-note">
          <span>© {t(lang, 'foot.rights')}</span>
          <span>{t(lang, 'foot.preview')}</span>
        </div>
      </div>
    </footer>
  );
}
