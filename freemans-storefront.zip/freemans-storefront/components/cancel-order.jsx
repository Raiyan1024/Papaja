'use client';

import { useActionState, useState } from 'react';
import { requestOrderCancellation, withdrawOrderCancellation } from '@/app/actions/orders';

/**
 * Ask to cancel, and withdraw the ask. The shop's answer — accepted or declined — is what
 * the customer sees afterwards, so nobody is left guessing.
 */
export default function CancelOrder({ code, lang = 'en' }) {
  const bn = lang === 'bn';
  const [state, formAction, pending] = useActionState(requestOrderCancellation, { error: null });
  const [open, setOpen] = useState(false);

  return (
    <div style={{ marginTop: 14 }}>
      {!open ? (
        <button type="button" className="btn ghost small" onClick={() => setOpen(true)}>
          {bn ? 'অর্ডার বাতিল করতে চাই' : 'Ask to cancel this order'}
        </button>
      ) : (
        <form action={formAction} className="panel flat" style={{ marginTop: 6 }}>
          <input type="hidden" name="code" value={code} />
          <p className="panel-title" style={{ marginTop: 0 }}>{bn ? 'বাতিলের অনুরোধ' : 'Cancellation request'}</p>

          {state?.error ? <div className="alert bad" style={{ marginBottom: 10 }}>{state.error}</div> : null}

          <div className="field">
            <label htmlFor="reason">{bn ? 'কারণ (ঐচ্ছিক)' : 'Why (optional)'}</label>
            <input id="reason" name="reason" maxLength={300} placeholder={bn ? 'যেমন: প্ল্যান বদলেছে' : 'e.g. changed my mind about the colour'} />
          </div>

          <p className="hint">
            {bn
              ? 'অনুরোধ পাঠালে দোকান সেটা দেখে গ্রহণ বা না-মেনে নেবে। উত্তরটা এই পেজেই দেখা যাবে।'
              : 'We send the request to the shop, who accepts or declines it. The answer appears on this page.'}
          </p>

          <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
            <button className="btn small" type="submit" disabled={pending}>
              {pending ? (bn ? 'পাঠানো হচ্ছে…' : 'Sending…') : bn ? 'বাতিলের অনুরোধ পাঠান' : 'Send the request'}
            </button>
            <button type="button" className="btn ghost small" onClick={() => setOpen(false)}>
              {bn ? 'না, থাক' : 'No, keep the order'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export function WithdrawRequest({ code, bn }) {
  return (
    <form action={withdrawOrderCancellation} style={{ marginTop: 10 }}>
      <input type="hidden" name="code" value={code} />
      <button className="btn ghost small" type="submit">
        {bn ? 'অনুরোধ তুলে নিন' : 'Withdraw the request'}
      </button>
    </form>
  );
}
