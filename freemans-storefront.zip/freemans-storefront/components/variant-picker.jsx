'use client';

import { useEffect, useMemo, useState } from 'react';
import { useLang } from '@/components/lang-provider';
import { designCrop } from '@/lib/colours';
import { productWaText, waLink } from '@/lib/contact';

const fmt = new Intl.NumberFormat('en-US');

export default function VariantPicker({ variants, action, product, initialColour }) {
  const { t, lang } = useLang();

  const colours = useMemo(() => {
    const map = new Map();
    for (const v of variants) if (!map.has(v.colour)) map.set(v.colour, v.colour_hex);
    return [...map.entries()].map(([name, hex]) => ({ name, hex }));
  }, [variants]);

  const start = colours.find(c => c.name === initialColour)?.name || colours[0]?.name || '';
  const [colour, setColour] = useState(start);
  const designs = variants.filter(v => v.colour === colour);
  const [design, setDesign] = useState(designs[0]?.design || '');
  const [qty, setQty] = useState(1);

  useEffect(() => {
    const next = variants.find(v => v.colour === colour);
    if (next) setDesign(next.design);
  }, [colour, variants]);

  const active = variants.find(v => v.colour === colour && v.design === design) || designs[0] || variants[0];

  function pickColour(name) {
    setColour(name);
    const next = variants.find(v => v.colour === name);
    if (next) setDesign(next.design);
  }

  const productImage = product?.image;

  return (
    <form action={action} className="stack" style={{ gap: 22 }}>
      <input type="hidden" name="variant_id" value={active?.id || ''} />
      <input type="hidden" name="colour" value={colour} />
      <input type="hidden" name="design" value={design} />

      <div>
        <div className="between" style={{ alignItems: 'baseline' }}>
          <span className="label small-caps">{t('product.colour')} · {colours.length}</span>
          <span className="muted small">{colour}</span>
        </div>
        <div className="colour-row">
          {colours.map(c => (
            <button
              key={c.name}
              type="button"
              onClick={() => pickColour(c.name)}
              aria-pressed={colour === c.name}
              className={`colour-chip ${colour === c.name ? 'on' : ''}`}
            >
              <span className="swatch" style={{ background: c.hex || '#2c3a4a' }} />
              <span>{c.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="between" style={{ alignItems: 'baseline' }}>
          <span className="label small-caps">{t('product.design')} · {designs.length}</span>
          <span className="muted small">{t('product.designHint')}</span>
        </div>

        <div className="design-row">
          {designs.map((d, i) => {
            const crop = designCrop(i);
            const img = d.image || productImage;
            const on = design === d.design;
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setDesign(d.design)}
                aria-pressed={on}
                className={`design-box ${on ? 'on' : ''}`}
              >
                <span className="design-img">
                  {img ? (
                    <img src={img} alt={d.design} loading="lazy" style={crop} />
                  ) : (
                    <span className="design-blank" aria-hidden="true" />
                  )}
                  {on ? <span className="design-tick" aria-hidden="true">✓</span> : null}
                </span>
                <span className="design-meta">
                  <b>{d.design}</b>
                  <small>
                    {d.fabric_name ? `${d.fabric_name}` : t('product.clothAtFitting')}
                    {Number(d.stock) > 0 ? ` · ${Number(d.stock)} ${t('product.cutReady')}` : ''}
                  </small>
                  <em>৳{fmt.format(d.price)}</em>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="field">
        <label htmlFor="brief">{t('product.brief')}</label>
        <textarea id="brief" name="brief" placeholder={t('product.briefPlaceholder')} />
        <p className="hint">{t('product.briefHint')}</p>
      </div>

      <div className="row" style={{ gap: 14, flexWrap: 'wrap' }}>
        <div className="field" style={{ width: 110 }}>
          <label htmlFor="qty">{t('product.qty')}</label>
          <input
            id="qty"
            name="qty"
            type="number"
            min="1"
            max="50"
            value={qty}
            onChange={e => setQty(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
          />
        </div>
        <div style={{ flex: 1, minWidth: 140 }}>
          <div className="small muted">{t('product.lineTotal')}</div>
          <b style={{ fontFamily: 'var(--serif)', fontSize: 24 }}>৳{fmt.format((active?.price || 0) * qty)}</b>
        </div>
        <button className="btn" type="submit">{t('product.add')}</button>
        <a
          className="btn outline wa-btn"
          href={waLink(productWaText(product?.name || '', active?.price))}
          target="_blank"
          rel="noreferrer"
        >
          {lang === 'bn' ? 'হোয়াটসঅ্যাপে জিজ্ঞেস করুন' : 'Ask on WhatsApp'}
        </a>
      </div>
    </form>
  );
}
