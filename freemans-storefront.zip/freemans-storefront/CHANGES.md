> **Later note — the gateway is gone.** This file was written when the shop still had
> SSLCommerz in the code. It has since been removed completely: `lib/payments/sslcommerz.js`,
> `app/api/payments/callback/`, the SSLCommerz variables and its tests no longer exist. Money is
> taken as bKash/Nagad Send Money with the TrxID checked in `/admin` — see README.md. The
> hardening lessons from section 1 below live on in the manual flow: a claim is not a payment,
> the amount must match, part payments accumulate, and mock mode cannot run in production.

# What changed in this build

Base: the zip you sent (project `freemans-tailoring`, live at freemans.antideploy.app).
Every change below was made against that code, and `npm run build` passes.

---

## 1. The paywall — SSLCommerz now actually takes money

The old code had an SSLCommerz client, but the money path had four holes. All four are closed.

| Hole in the old code | What it did | Now |
|---|---|---|
| `verifyPayment()` only checked `status` and that an amount existed | **Any valid `val_id` — from any transaction, any amount — marked an order paid.** A ৳10 test payment could release a ৳12,000 suit. | The amount must equal `payments.amount`, the currency must be BDT, and `tran_id` must match the row we created. Any mismatch is recorded as failed and the order is not released. |
| No `verify_sign` check on the IPN | A forged POST to `/api/payments/callback?ipn=1` was indistinguishable from the gateway. | MD5 checksum over `verify_key` fields + store password, compared in constant time. A bad signature is refused and logged. |
| The IPN was answered with a 303 redirect | The gateway expects a plain 200; a redirect looks like a failure and gets retried. | IPN gets `200 ok`; the browser returns get the redirect to the order page. |
| `markPaymentPaid` set `amount_due = 0` | An "advance" order (৳150 visit) was marked **fully paid**, and the garment balance vanished from the admin panel's outstanding total. | Part payments: `amount_paid` accumulates, `amount_due = total − paid`, status becomes `partial` until the balance is covered. |

Extra hardening that came with it:

- **Mock mode cannot be reached in production.** `completeMockPayment` and the public callback both refuse when `PAYMENTS_MODE=sslcommerz`; the test gateway page is inert.
- **No order is taken that cannot be charged.** With `PAYMENTS_MODE=sslcommerz` and no keys, checkout says so instead of creating an order that can never be paid.
- **If SSLCommerz refuses the session**, the order is kept, the payment row is marked failed with the reason, and the customer is told to WhatsApp — instead of a 500 page with an orphan order.
- **`risk_level 1` is a hold, not a payment.** The money is captured, the order stays unconfirmed, and the admin sees `on_hold`.
- **Idempotent**: the IPN and the browser return can both arrive, in either order, and only one of them moves money.
- **Card-only by default** (`SSLCOMMERZ_CHANNELS=cards`); set `all` for cards + bKash + Nagad + bank.
- The order page reads payment state from the database, never from `?paid=1` in the URL.

## 2. The visit fee — ৳150 inside Dhaka, ৳400 outside

- `lib/money.js` now has `ZONES`, `VISIT_FEE_OUTSIDE` and `visitFeeFor(zone)`.
- Checkout asks **Inside Dhaka / Outside Dhaka** and the advance, the order total and the "paying now" figure all follow the choice.
- The server recomputes the fee from the zone — the browser's number is ignored.
- `/visit` shows both fees, and the header/home stat row mentions the ৳400.
- New column `orders.delivery_zone` (migration `001`).

## 3. Refund is 60%, not 40%

Your video says the customer gets **60% back**; the site said 40% in six places (home panel, `/visit`, the order confirmation, both language dictionaries). All now read from `REFUND_RATE` (default `0.60`). Change one env var to flip it back.

## 4. Contact details

`NEXT_PUBLIC_PHONE` fallback is now **+8801626764545** (was the demo `+8801700000000`), so every WhatsApp button, call link and footer is correct even if the env var is never set. Override with the env var for a different number.

## 5. Admin security

`/admin/login` **printed the seeded credentials on the public page**. That text is gone, replaced with the reset instruction. A new script sets the password properly:

```bash
npm run admin:pass 'a-long-new-password'
```

It writes the same scrypt hash format the app verifies, and works on the live database.

## 6. Search engines

`/sitemap.xml` was a 404. Added `app/sitemap.js` (home, categories, every product) and `app/robots.js` (disallows `/admin`, `/pay/`, `/api/`, `/order/`).

## 7. The rotating-window caption

Video 1, 1:01: *"this writing should not be there."* The line *"The window turns over every two seconds…"* is removed in both languages; the hero renders nothing there now instead of an explanation of the mechanism.

## 8. Database migration that is safe to re-run

`sql/migrations/001-payment-hardening.sql` — adds `amount_paid`, `delivery_zone`, the `partial` and `on_hold` states, back-fills part payments from existing rows, and writes the fee settings. `scripts/db-setup.js` now applies every file in `sql/migrations/` in order, and still only seeds when the catalogue is empty. `--reset` remains the only destructive path and is not used on deploy.

## 9. Tests

`npm run test:payments` — 15 checks, no database and no internet needed. It stubs the SSLCommerz validator and proves an amount mismatch, a currency mismatch, a foreign `tran_id`, a bad IPN checksum and a risk hold are each rejected, and that the ৳150/৳400 fees and the 60% refund compute correctly. **All 15 pass.**

---

## Verified

- `npm run build` — passes, 21 routes, `/robots.txt` and `/sitemap.xml` now real routes.
- `npm run test:payments` — 15/15.
- Not verified end to end, because it needs your merchant account: a real sandbox transaction. That is step 5 of `DEPLOY.md`.

## Still open (next pass, from the two videos)

These are presentation changes and were not in this build:

- Hero split into two fixed panels — Menswear and Scouting (video 1, 0:44).
- Header: drop the Order button, add a Scouting link (video 2, 0:01).
- Brand lockup: `FREEMANS` on top, `TAILORS & FABRICS` beneath (video 2, 0:18).
- Product page: three large colour swatches that actually change the image, plus a tap-to-preview pop-up (video 2, 0:33–1:41).
- Menu drawer closing on scroll (video 1, 0:08).
- Stat strip smaller; uniforms first in "What we make most"; four cards per row (video 1, 1:48–2:50).
- Size-chart fields for "I'll give my own size" (video 2, 2:48).
- Inquiries from "discuss the design first" listed in the admin panel.

---

## Phase 7 — what the recordings asked for

Front page
- **The sign is fixed**: FREEMANS on the first line in the big serif, TAILORS AND FABRICS small and
  wide underneath.
- **The hero is four pictures, not a slider**: the scout uniform leads, then a blazer, a trouser and
  a shirt — each one a link to the piece.
- The five lines sit smaller; the shop cards carry smaller photographs; **What we make most** starts
  with the scout uniform.
- The **Menu** pop-up closes itself when a line is picked (it used to stay open).
- **No Admin button anywhere on the shop front** — header, menu and footer. You sign in at
  `/admin/login`.

Catalogue and piece page
- The "From ৳…, 11 colours, 30 designs, 4 styles" strip is gone from the category page — intro first,
  prices where a piece is actually chosen.
- On a piece page the price-and-count pills are gone; the colours are buttons that change the
  photograph, pressing a design opens it **in a pop-up, bigger**, and choosing a design sets the
  price you see.

Order and payment
- The address block is one clear pair of fields (area with suggestions, house/road/floor), shown for
  every order, with the "call us or WhatsApp the address instead" line.
- **Every payment button does something**: bKash / Nagad / Card tabs really switch the method,
  Copy number / Copy amount / Copy reference put the right text on the clipboard, "Money sent? Give
  us the TrxID" files the claim, "Not paying now — keep my order" stops cleanly, and the order page
  offers three working pay buttons instead of one.
- Card is explained plainly: no merchant account yet, so we call with a secure link.

Cancellation
- Customer asks, shop accepts or declines, and the answer — **accepted or cancelled** — is shown on
  the order page and in the admin, with the time and any note.

Admin
- **Add a new piece** with its photographs (`/admin/products/new`), a photo per design, add a colour
  or design to an existing piece, swap any photo, take a design off sale, hide a piece.
- The whole admin now fits a phone screen — no sideways scrolling, tables scroll inside their panel.

Tests: `node tests/phase7.js` — 32 checks passing (front page, menu, piece page, payment tabs and
copy buttons, TrxID, cancellation end to end, and a new piece with an uploaded photo appearing in the
shop). `npm run test:payments` still 41/41.

---

## Phase 8 — the fourth recording, the audit and the shop's own reach

What the recording asked for
- A side line under the hero: **"Made for tailoring, not for ready-made"**.
- **The five line boxes are removed.** In their place, **What we make most** shows **four pieces
  from every line**, one block per line, each with a "See all" link.
- **A bigger catalogue with real photographs**: a picture for each colour, a picture for each
  design, and a close-up strip on the piece page — **Front · Pocket · Cuff · Back · Lining** —
  each one opening full size. Ten new studio photographs, on light backgrounds, as asked.
- **No cloth shelf on the uniform pages**: the panel now says the cloth is agreed with the school.
- Four pieces in every line: a pleated trouser, a school uniform set, a navy workwear uniform and
  the scout uniform on parade were added, so no line looks empty.

Audit (`preview/website-audit.md`, script `tests/audit.js`)
- axe-core WCAG 2.1 A + AA: **0 violations on all seven pages** (one serious fix: the floating
  Order button's aria-label hid its visible text).
- 1 H1 per page, every image has alt text, no side-scrolling on a phone.
- Home page 318 KB → 255 KB; piece page 881 KB → 243 KB.
- Sitemap 20 → 32 URLs and now carries 24 photographs; robots keeps the admin, the payment page
  and order pages out of the index.

Reach (`preview/growth-plan-bangla.md`)
- Structured data, Open Graph cards and per-page titles in both languages, plus a step-by-step
  free plan: Google Business Profile, Search Console, Bing, WhatsApp Business, 15 free profile
  links, the partner links that actually count, reviews, and four weeks of content.
