# Deploying this build to Antideploy

There is no payment gateway in this project. Money arrives as bKash / Nagad **Send Money** to
the shop's own number, and the shopkeeper releases each order after matching the TrxID in the
statement. Nothing to apply for, nothing to approve, nothing taken per sale.

---

## 0. Before you upload

```bash
npm install
npm run build          # must pass
npm run test:payments  # 25 checks on the money rules
```

Do **not** upload `node_modules` or `.next`. The zip had neither; keep it that way.

## 1. Environment variables

Set these in the Antideploy console. `DATABASE_URL`, `NEXT_PUBLIC_SITE_URL` and the `PG*`
variables are set by the platform — leave them alone. **A variable change does nothing until a
redeploy.**

| Variable | Value | Note |
|---|---|---|
| `PAYMENTS_MODE` | `manual` | the default; anything else falls back to `manual` in production |
| `NEXT_PUBLIC_BKASH_NUMBER` | `+8801626764545` | where bKash money is sent; blank falls back to `NEXT_PUBLIC_PHONE` |
| `NEXT_PUBLIC_NAGAD_NUMBER` | the Nagad number | same number if you receive both on one phone |
| `NEXT_PUBLIC_PHONE` | `+8801626764545` | every call link and WhatsApp button |
| `NEXT_PUBLIC_WHATSAPP` | blank | follows `NEXT_PUBLIC_PHONE` when blank |
| `NEXT_PUBLIC_SHOP_NAME` | `Freemans Tailors & Fabrics` | the brand line |
| `NEXT_PUBLIC_SHOP_ADDRESS` | your real address | the footer reads it |
| `NEXT_PUBLIC_VISIT_FEE` | `150` | inside Dhaka |
| `NEXT_PUBLIC_VISIT_FEE_OUTSIDE` | `400` | outside Dhaka |
| `REFUND_RATE` | `0.60` | 60% comes back |

`ALLOW_MOCK_PAYMENTS=true` is for local testing only — in production the test gateway is
ignored, so a customer can never be walked through a payment that moves no money.

## 2. Database

Migrations run themselves on deploy:

```
schema.sql → sql/migrations/001-payment-hardening.sql → 002-manual-payments.sql
```

Each file is idempotent and only adds. The catalogue is seeded only when it is empty, so
re-running never touches a live shop's products, prices or orders.

## 3. Deploy

```bash
tar czf - --exclude=.git --exclude=node_modules --exclude=.next \
          --exclude=.env --exclude=.env.local --exclude=.vercel --exclude='*.zip' . \
  | curl -s -X POST "https://antideploy.com/api/v1/deploy?applicationId=$APP_ID" \
      -H "Authorization: Bearer $TOKEN" -F "archive=@-;filename=app.tar.gz"
```

Poll `GET /api/v1/deployments/{taskId}` until `status: succeeded`, then check `/health` and the
routes below.

## 4. The five-minute live check

1. `/` — the window turns every two seconds; the Order button floats lower-right.
2. Add a piece → `/order`: bKash / Nagad / card are offered; Outside Dhaka moves the advance
   to ৳400.
3. Place an advance order → you land on `/pay/<tran>` with the shop number, the amount and the
   order code as the reference.
4. Send ৳150 from a real bKash app using that reference, paste the TrxID, submit.
   The order page must say **"We are checking your payment"** — not "paid".
5. Admin → the **Payments to check** panel shows the TrxID. Match it in the bKash statement and
   press **Money is in — release**. The order becomes `partial`, the balance stays due, and the
   customer's order page shows "Advance paid".

Do step 4 with ৳10 once if you want to test without spending ৳150 — the amount is whatever the
payment row says, so use a real advance for the real test.

## 4b. Turn on automatic TrxID checking (optional, free)

1. Sign in to `/admin/payments`.
2. Copy the **forwarding URL** it shows.
3. Install a free SMS-forwarder app on the shop phone (e.g. *SMS Forwarder*), add a rule for the
   bKash and Nagad senders, method POST, body = the message, target = that URL.
4. Send yourself a ৳10 test payment to an order worth ৳10 if you want to watch it land; the
   message appears under **Last messages seen** and the order is released on the spot.

The URL carries a token: it is a password. Do not post it anywhere public, and press **Rotate the
token** if it ever leaks. Without the forwarder the shop just keeps using *Money is in — release*
by hand; nothing breaks.

## 5. Cards

Cards need a merchant account (bank or aggregator), which costs a percentage per sale and has
to be approved. The site does not pretend otherwise: choosing "Bank card" saves the order and
tells the customer the shop will call with a secure link. When an account is open, that is the
one method to wire — `lib/payments/manual.js` and the `/pay` page are where it goes.

## 5b. What the deploy sets up by itself

The deploy runs `sql/schema.sql` and every file in `sql/migrations/` (001 – 004) on start-up:

- `003-auto-trxid.sql` — the forwarded-SMS inbox and the SMS token.
- `004-photos-and-cancellation.sql` — `product_images` (photographs uploaded from the admin panel,
  kept in the database so they survive a redeploy) and the `cancel_state` columns on `orders`.

Nothing needs doing by hand. Your existing photographs are not touched, and no order is changed.

## 6. Admin password

```bash
npm run admin:pass 'a-long-new-password'
```

Writes the scrypt hash the app verifies, straight into the live database. Sign in at
`/admin/login`. Rotating `SESSION_SECRET` afterwards kills every old session.
