/**
 * Fills out the catalogue the way the shop asked for it:
 *
 *   · a photograph for each colour, not one picture cropped five ways
 *   · a photograph for each design (double-breasted, slim short, house style)
 *   · close-ups: the pocket, the cuff, the back, the lining
 *   · four pieces in every line, so "What we make most" can show four of each
 *
 * Safe to run again: everything is written with ON CONFLICT DO UPDATE / DO NOTHING.
 *   node scripts/catalogue-gallery.js
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

for (const file of ['.env.local', '.env']) {
  const full = path.join(process.cwd(), file);
  if (!fs.existsSync(full)) continue;
  for (const line of fs.readFileSync(full, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set.');
  process.exit(1);
}

/* ------------------------------------------------------------------ colours per piece */

// Each colour gets its own photograph, so a customer choosing Slate sees Slate.
const COLOUR_IMAGES = {
  'navy-two-piece': {
    Navy: '/products/suit-navy.jpg',
    Midnight: '/products/suit-midnight.jpg',
    Slate: '/products/suit-slate.jpg'
  },
  'black-formal-suit': {
    Black: '/products/suit-midnight.jpg',
    Graphite: '/products/suit-slate.jpg'
  }
};

// Each design gets the photograph of that cutting, where the shop has one.
const DESIGN_IMAGES = {
  'navy-two-piece': {
    'Double-breasted': '/products/suit-doublebreasted.jpg',
    'Slim, shorter jacket': '/products/suit-slim.jpg',
    'House style': '/products/suit-navy.jpg'
  }
};

/* ------------------------------------------------------------------ the close-ups */

const GALLERY = {
  'navy-two-piece': [
    ['Front', '/products/suit-navy.jpg'],
    ['Pocket', '/products/detail-pocket.jpg'],
    ['Cuff', '/products/detail-cuff.jpg'],
    ['Back', '/products/detail-back.jpg'],
    ['Lining', '/products/detail-lining.jpg']
  ],
  'charcoal-three-piece': [
    ['Front', '/products/cat-02.jpg'],
    ['Pocket', '/products/detail-pocket.jpg'],
    ['Cuff', '/products/detail-cuff.jpg'],
    ['Back', '/products/detail-back.jpg']
  ],
  'black-formal-suit': [
    ['Front', '/products/suit-midnight.jpg'],
    ['Back', '/products/detail-back.jpg'],
    ['Lining', '/products/detail-lining.jpg']
  ]
};

/* ------------------------------------------------------------------ four of every line */

// The photographs for these already live in public/products and were never used.
const NEW_PIECES = [
  {
    slug: 'charcoal-pleated-trouser',
    category: 'trousers',
    name: 'The charcoal pleated trouser',
    image: '/products/trouser-pleated.jpg',
    spec: 'Single pleat · clean fall · belt loops',
    summary: 'The formal trouser that hangs straight.',
    description:
      'One forward pleat gives room through the thigh and keeps a sharp line down the leg. Cut to your waist and inside leg, with the break you ask for — full, slight or none.',
    variants: [
      ['Charcoal', '#3a3d42', 'House style', 3400, 4],
      ['Ash grey', '#6b7078', 'House style', 3400, 2],
      ['Slate', '#3e4a5a', 'Turn-up', 3600, 2]
    ]
  },
  {
    slug: 'school-uniform-set',
    category: 'uniforms',
    name: 'The school uniform set',
    image: '/products/scout-01.jpg',
    spec: 'Shirt · trouser · tie · badge',
    summary: 'Cut to each student, not to a size chart.',
    description:
      'Send the strength of the class and we cut every set to the person wearing it: shirt, trouser, tie and badge. One set, one price, measured at the school or at home.',
    variants: [
      ['Sky', '#c3d5e6', 'House style', 1850, 12],
      ['White', '#f2f2ee', 'House style', 1750, 10]
    ]
  },
  {
    slug: 'navy-workwear-uniform',
    category: 'uniforms',
    name: 'The navy workwear uniform',
    image: '/products/scout-02.jpg',
    spec: 'Shirt · trouser · cap · belt',
    summary: 'For offices, guards and crews.',
    description:
      'A neat navy set for staff who are on their feet all day: a shirt that holds its collar, a trouser with a reinforced seat, and a cap and belt if you want them. Orders of ten or more are cut together so the colour never varies.',
    variants: [
      ['Navy', '#1d2d4d', 'House style', 2100, 20],
      ['Midnight', '#141c2e', 'With cap and belt', 2450, 10]
    ]
  },
  {
    slug: 'scout-uniform-on-parade',
    category: 'uniforms',
    name: 'The scout uniform, on parade',
    image: '/products/scout-worn.jpg',
    spec: 'Full dress · neckerchief · belt',
    summary: 'The full dress set, worn.',
    description:
      'The same uniform, photographed on a scout on parade so you can see the fall of the shirt, the length of the sleeve and where the neckerchief sits. Every part can be ordered on its own.',
    variants: [
      ['Scout blue', '#4f8fd0', 'Full dress', 4650, 6],
      ['Scout navy', '#1f3560', 'Full dress', 4650, 6]
    ]
  }
];

(async () => {
  const client = new Client({ connectionString: url, ssl: /sslmode=require/.test(url) ? { rejectUnauthorized: false } : false });
  await client.connect();

  const categoryId = async (slug) =>
    (await client.query('select id from categories where slug = $1', [slug])).rows[0]?.id || null;
  const productId = async (slug) => (await client.query('select id from products where slug = $1', [slug])).rows[0]?.id || null;
  const variantId = async (product, colour, design) =>
    (
      await client.query('select id from product_variants where product_id = $1 and colour = $2 and design = $3', [
        product,
        colour,
        design
      ])
    ).rows[0]?.id || null;

  /* 1 — a photograph per colour and per design */
  let touched = 0;
  for (const [slug, colours] of Object.entries(COLOUR_IMAGES)) {
    const id = await productId(slug);
    if (!id) continue;
    for (const [colour, image] of Object.entries(colours)) {
      const res = await client.query('update product_variants set image = $3 where product_id = $1 and colour = $2', [
        id,
        colour,
        image
      ]);
      touched += res.rowCount;
    }
  }
  for (const [slug, designs] of Object.entries(DESIGN_IMAGES)) {
    const id = await productId(slug);
    if (!id) continue;
    for (const [design, image] of Object.entries(designs)) {
      const res = await client.query('update product_variants set image = $3 where product_id = $1 and design = $2', [
        id,
        design,
        image
      ]);
      touched += res.rowCount;
    }
  }
  console.log(`· ${touched} colour/design photographs set`);

  /* 2 — the close-up gallery */
  let galleryRows = 0;
  for (const [slug, shots] of Object.entries(GALLERY)) {
    const id = await productId(slug);
    if (!id) continue;
    await client.query('delete from product_gallery where product_id = $1 and variant_id is null', [id]);
    for (let i = 0; i < shots.length; i += 1) {
      const [label, image] = shots[i];
      await client.query('insert into product_gallery (product_id, url, label, position) values ($1,$2,$3,$4)', [
        id,
        image,
        label,
        i
      ]);
      galleryRows += 1;
    }
  }
  console.log(`· ${galleryRows} gallery photographs`);

  /* 3 — four pieces in every line */
  let added = 0;
  for (const piece of NEW_PIECES) {
    const cat = await categoryId(piece.category);
    if (!cat) continue;
    const existing = await productId(piece.slug);
    let id = existing;
    if (!id) {
      const res = await client.query(
        `insert into products (slug, category_id, name, summary, description, image, spec, active, position)
         values ($1,$2,$3,$4,$5,$6,$7,true,
           coalesce((select max(position) + 1 from products where category_id = $2), 0))
         returning id`,
        [piece.slug, cat, piece.name, piece.summary, piece.description, piece.image, piece.spec]
      );
      id = res.rows[0].id;
      added += 1;
    }
    for (const [colour, hex, design, price, stock] of piece.variants) {
      await client.query(
        `insert into product_variants (product_id, colour, colour_hex, design, price, stock, active)
         values ($1,$2,$3,$4,$5,$6,true)
         on conflict (product_id, colour, design) do update set price = excluded.price`,
        [id, colour, hex, design, price, stock]
      );
    }
  }
  console.log(`· ${added} new pieces (${NEW_PIECES.length - added} already existed)`);

  const counts = await client.query(
    `select c.slug, count(pv.id)::int as variants, count(distinct p.id)::int as pieces
       from categories c left join products p on p.category_id = c.id and p.active
       left join product_variants pv on pv.product_id = p.id and pv.active
      group by c.slug, c.position order by c.position`
  );
  console.log('\nline'.padEnd(12), 'pieces  variants');
  for (const row of counts.rows) console.log(row.slug.padEnd(12), String(row.pieces).padStart(6), String(row.variants).padStart(9));

  await client.end();
})().catch((error) => {
  console.error('failed:', error.message);
  process.exit(1);
});
