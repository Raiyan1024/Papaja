/**
 * Proves the rules of the Send Money flow — the parts that decide whether money is real.
 * No database, no network, no framework.
 *
 *   npm run test:payments
 */
import assert from 'node:assert/strict';
import { bdNumber, normaliseTrxId, normaliseSenderNumber, methodProvider, trxIdFromText } from '../lib/payments/trx.js';
import { VISIT_FEE, VISIT_FEE_OUTSIDE, visitFeeFor, REFUND_PCT, refundOf } from '../lib/money.js';
import { parseReceipt, parseStatement, decide } from '../lib/payments/parse.js';

let passed = 0;
let failed = 0;

function ok(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`  ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.log(`  FAIL ${name}\n       ${error.message}`);
  }
}

console.log('\nTrxID — what the customer pastes');
ok('a normal bKash TrxID is accepted', () => assert.equal(normaliseTrxId('9F7A2KD10X'), '9F7A2KD10X'));
ok('lower case is tidied up', () => assert.equal(normaliseTrxId(' 9f7a2kd10x '), '9F7A2KD10X'));
ok('spaces inside are removed', () => assert.equal(normaliseTrxId('9F7A 2KD1 0X'), '9F7A2KD10X'));
ok('too short is refused', () => assert.equal(normaliseTrxId('9F7A2'), null));
ok('too long is refused', () => assert.equal(normaliseTrxId('9F7A2KD10XYZ123'), null));
ok('punctuation is refused', () => assert.equal(normaliseTrxId('9F7A-2KD1'), null));
ok('an empty paste is refused', () => assert.equal(normaliseTrxId(''), null));

console.log('\nSender number — optional, but whole when given');
ok('a local number becomes international', () => assert.equal(normaliseSenderNumber('01711223344'), '+8801711223344'));
ok('an international number is kept', () => assert.equal(normaliseSenderNumber('+880 1711-223344'), '+8801711223344'));
ok('a half-typed number is refused', () => assert.equal(normaliseSenderNumber('0171122'), null));
ok('blank means we do not know it', () => assert.equal(normaliseSenderNumber(''), null));
ok('a number with the wrong operator prefix is refused', () => assert.equal(bdNumber('01201234567'), null));

console.log('\nWhich payment a method records');
ok('bkash becomes bkash_manual', () => assert.equal(methodProvider({ payment_method: 'bkash' }), 'bkash_manual'));
ok('nagad becomes nagad_manual', () => assert.equal(methodProvider({ payment_method: 'nagad' }), 'nagad_manual'));
ok('card becomes card_manual, not a gateway', () => assert.equal(methodProvider({ payment_method: 'card' }), 'card_manual'));
ok('an unknown method falls back to bKash', () => assert.equal(methodProvider({ payment_method: 'paypal' }), 'bkash_manual'));
ok('a missing method falls back to bKash', () => assert.equal(methodProvider({}), 'bkash_manual'));

console.log('\nFees and the fit promise');
ok('inside Dhaka is 150', () => assert.equal(VISIT_FEE, 150));
ok('outside Dhaka is 400', () => assert.equal(VISIT_FEE_OUTSIDE, 400));
ok('an unknown zone falls back to 150', () => assert.equal(visitFeeFor('mars'), 150));
ok('the zone decides the fee', () => assert.equal(visitFeeFor('outside_dhaka'), 400));
ok('60% comes back', () => assert.equal(REFUND_PCT, 60));
ok('60% of 12,000 is 7,200', () => assert.equal(refundOf(12000), 7200));

console.log('\nReading a TrxID out of a message');
ok('a pasted SMS still yields the id', () => assert.equal(trxIdFromText('TrxID: 9F7A2KD10X'), '9F7A2KD10X'));
ok('a message with no id yields nothing', () => assert.equal(trxIdFromText('done'), null));

console.log('\nReading the bKash / Nagad receipt SMS');
ok('a bKash receipt yields amount, TrxID and sender', () => {
  const r = parseReceipt('You have received Tk 150.00 from 01711223344. TrxID 9F7A2KD10X at 07/11/2026 10:23. Your new balance is Tk 1,234.56.');
  assert.equal(r.amount, 150);
  assert.equal(r.trxId, '9F7A2KD10X');
  assert.equal(r.senderNumber, '01711223344');
});
ok('a comma in the amount is read as thousands', () => {
  const r = parseReceipt('You have received Tk 12,650.00 from 01711223344. TrxID ABC12345XY at 07/11/2026 10:23');
  assert.equal(r.amount, 12650);
});
ok('a Nagad receipt is read the same way', () => {
  const r = parseReceipt("You've received Taka 400.00 from 01811223344. TrxID: NG77A2KD10 at 07/11/2026 11:05");
  assert.equal(r.amount, 400);
  assert.equal(r.trxId, 'NG77A2KD10');
});
ok('a Bangla receipt is recognised', () => {
  const r = parseReceipt('আপনি ১৫০ টাকা পেয়েছেন 01711223344 থেকে। TrxID 9F7A2KD10X');
  assert.ok(r === null || r.trxId === '9F7A2KD10X');
});
ok('an outgoing message is not a payment', () => {
  assert.equal(parseReceipt('You have sent Tk 150.00 to 01711223344. TrxID 9F7A2KD10X'), null);
});
ok('a balance alert is not a payment', () => {
  assert.equal(parseReceipt('Your bKash balance is Tk 500.00'), null);
});
ok('an advert is not a payment', () => {
  assert.equal(parseReceipt('Get 20% cashback on bKash today'), null);
});

console.log('\nReading a pasted statement');
ok('one line per payment', () => {
  const rows = parseStatement('9F7A2KD10X 150\nXK29FJ30Q1 400');
  assert.equal(rows.length, 2);
  assert.equal(rows[0].trxId, '9F7A2KD10X');
  assert.equal(rows[1].amount, 400);
});
ok('commas and decimals still parse', () => {
  const rows = parseStatement('9F7A2KD10X, 12,650.00');
  assert.equal(rows[0].amount, 12650);
});
ok('a line without a TrxID is skipped', () => {
  assert.equal(parseStatement('Opening balance 5,000').length, 0);
});

console.log('\nThe amount is the gate');
ok('exact money releases the order', () => assert.equal(decide({ status: 'submitted', amount: 150 }, { amount: 150 }), 'exact'));
ok('one taka short is held for a person', () => assert.equal(decide({ status: 'submitted', amount: 150 }, { amount: 149 }), 'short'));
ok('more money than the order is held, never kept quietly', () => assert.equal(decide({ status: 'submitted', amount: 150 }, { amount: 1500 }), 'over'));
ok('a ৳10 message cannot clear a ৳12,000 order', () => assert.equal(decide({ status: 'submitted', amount: 12650 }, { amount: 10 }), 'short'));
ok('an already paid payment is not paid twice', () => assert.equal(decide({ status: 'paid', amount: 150 }, { amount: 150 }), 'spent'));
ok('an unknown TrxID matches nothing', () => assert.equal(decide(null, { amount: 150 }), 'unknown'));

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed === 0 ? 0 : 1);
