/**
 * Creates the schema and seeds the catalogue.
 *   node scripts/db-setup.js          → create tables + seed if empty
 *   node scripts/db-setup.js --reset  → drop everything first (dev only)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Client } = require('pg');

// Load .env.local / .env without pulling in a dependency (next loads these for the app itself).
for (const file of ['.env.local', '.env']) {
  const fullpath = path.join(process.cwd(), file);
  if (!fs.existsSync(fullpath)) continue;
  for (const line of fs.readFileSync(fullpath, 'utf8').split('\n')) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!match) continue;
    const value = match[2].replace(/^["']|["']$/g, '');
    if (!process.env[match[1]]) process.env[match[1]] = value;
  }
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set. Copy .env.example to .env.local and fill it in.');
  process.exit(1);
}

const reset = process.argv.includes('--reset');

const ssl = /sslmode=(require|verify)/.test(url) ? { rejectUnauthorized: false } : false;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

const CATEGORIES = [
  ['suits', 'Suits', 'Two- and three-piece, cut to your size.',
    'The interview suit, the wedding suit, the one you keep for a decade. Every suit is cut from the size you give or the size we measure, in the cloth you pick.'],
  ['blazers', 'Blazers', 'Odd jackets that carry a whole outfit.',
    'Navy, black, tweed, crest. Worn with matching trousers or none at all — the jacket is the statement, so the fit matters most.'],
  ['trousers', 'Trousers', 'Waist, rise and length to your numbers.',
    'Formal wool, everyday chino. Both cut to your waist and inside leg, with the break you ask for.'],
  ['shirts', 'Shirts', 'Collar and cuff to your neck and arm.',
    'Poplin, oxford, check. The collar sits where your neck is, the cuff ends where your wrist does.']
];

// [slug, category, name, image, spec, summary, description, base price, colours, designs, fabric code]
const PRODUCTS = [
  ['navy-two-piece', 'suits', 'The navy two-piece', '/products/cat-01.jpg',
    'Single-breasted · notch lapel · straight pockets', 'The interview and wedding suit.',
    'Navy is the safest suit you can own: it reads formal in daylight and forgiving under evening light. Single-breasted, two-button, notch lapel, straight flap pockets, half-lined so it stays wearable in Dhaka heat.',
    12500, [['Navy', '#1d2d4d'], ['Midnight', '#141c2e'], ['Slate', '#3e4a5a']],
    [['House style', 12500], ['Slim, shorter jacket', 13200], ['Double-breasted', 14800]], 'WL-NAVY'],
  ['charcoal-three-piece', 'suits', 'The charcoal three-piece', '/products/cat-02.jpg',
    'Jacket + waistcoat + trousers from one cloth', 'The full formal set.',
    'Cut from one bolt so the three pieces never disagree in tone. Waistcoat has a six-button front and adjustable back strap; trousers are single-pleat with a clean fall.',
    17800, [['Charcoal', '#3a3d42'], ['Graphite', '#2b2e33'], ['Ash grey', '#6b7078']],
    [['House style', 17800], ['Peak lapel', 18900], ['With second trousers', 21500]], 'WL-CHAR'],
  ['black-formal-suit', 'suits', 'The black formal suit', '/products/cat-03.jpg',
    'Peak lapel · clean line', 'For evenings and ceremonies.',
    'Black is a lighting problem, so the cloth here is a fine twill that holds a crease without shining. Peak lapel, jetted pockets, no turn-ups.',
    14000, [['Black', '#15171a'], ['Deep charcoal', '#2a2d31']],
    [['House style', 14000], ['Shawl collar', 15200], ['Tuxedo trouser braid', 15900]], 'WL-BLACK'],
  ['light-grey-two-piece', 'suits', 'The light grey two-piece', '/products/cat-04.jpg',
    'Soft shoulder · half-lined', 'Daytime wear and Dhaka winter.',
    'A warm-weather grey in a wool–linen blend: light enough for a January afternoon, structured enough to sit in a meeting.',
    12000, [['Light grey', '#a8a9a3'], ['Stone', '#b9b2a4'], ['Fog blue', '#8a9aa8']],
    [['House style', 12000], ['Unlined summer cut', 12800]], 'WL-GREY'],

  ['navy-gold-blazer', 'blazers', 'The navy blazer, gold buttons', '/products/cat-05.jpg',
    'Brass buttons · patch pockets', 'The college and club jacket.',
    'Hopsack navy with brass buttons and patch pockets — the version that works equally over a shirt and tie or a plain tee.',
    8200, [['Navy', '#1d2d4d'], ['Cobalt', '#24406e'], ['Bottle green', '#22493c']],
    [['House style', 8200], ['Gold buttons', 8700], ['Peak lapel', 9200]], 'HS-NAVY'],
  ['black-blazer', 'blazers', 'The black blazer', '/products/cat-06.jpg',
    'Two button · flap pockets', 'The office favourite.',
    'A black odd jacket with a clean front — no brass, no badge, nothing that dates. Wear it with grey trousers and stop thinking about it.',
    7400, [['Black', '#15171a'], ['Charcoal', '#3a3d42']],
    [['House style', 7400], ['Slim cut', 7900]], 'WL-BLACK'],
  ['herringbone-tweed-blazer', 'blazers', 'The herringbone tweed blazer', '/products/cat-07.jpg',
    'Textured tweed · horn buttons', 'For the cooler months.',
    'A herringbone with enough weight to hang straight. Horn buttons, a belted back option, and a lining you choose from the swatch book.',
    9800, [['Grey herringbone', '#6f6f6a'], ['Brown herringbone', '#6b5442'], ['Olive', '#55603f']],
    [['House style', 9800], ['Belted back', 10600], ['Full lining', 11200]], 'TW-HERR'],
  ['crest-blazer', 'blazers', 'The crest blazer', '/products/cat-08.jpg',
    'Your crest stitched on the pocket', 'For schools, colleges and clubs.',
    'The same jacket, cut to a group’s specification: one cloth, one badge position, one set of sizes. Priced per piece at group volumes.',
    7600, [['Navy', '#1d2d4d'], ['Maroon', '#4a2230'], ['Forest', '#23422f']],
    [['House style', 7600], ['With crest embroidery', 8400], ['Full lining', 8900]], 'HS-NAVY'],

  ['formal-wool-trouser', 'trousers', 'The formal wool trouser', '/products/cat-09.jpg',
    'Centre crease · side adjusters', 'With a jacket or on its own.',
    'A charcoal wool blend with a single centre crease, side adjusters instead of belt loops if you want them, and a break you choose at fitting.',
    2800, [['Charcoal', '#3a3d42'], ['Black', '#15171a'], ['Navy', '#1d2d4d']],
    [['House style', 2800], ['Side adjusters', 3200], ['Gurkha waist', 3800]], 'WL-CHAR'],
  ['cotton-chino', 'trousers', 'The cotton chino', '/products/cat-10.jpg',
    'Beige twill · cut to your leg', 'Everyday wear.',
    'A mid-weight beige twill that survives a working week. Straight or tapered, your waist and inside leg.',
    2200, [['Beige', '#b9a887'], ['Stone', '#a99c88'], ['Navy', '#1d2d4d'], ['Olive', '#55603f']],
    [['House style', 2200], ['Pleated front', 2500]], 'CT-BEIGE'],

  ['white-poplin-shirt', 'shirts', 'The white poplin shirt', '/products/shirt-01.jpg',
    'Spread collar · single cuff', 'The shirt that goes with everything.',
    'Two-ply poplin, spread collar, single-button cuff. Collar and sleeve cut to your neck and arm rather than a size chart.',
    2400, [['White', '#f2f2ee'], ['Ivory', '#eee7d8'], ['Sky', '#c3d5e6']],
    [['House style', 2400], ['Cutaway collar', 2600], ['French cuff', 2800]], 'CT-WHITE'],
  ['blue-oxford-shirt', 'shirts', 'The blue oxford shirt', '/products/shirt-02.jpg',
    'Button-down collar · box pleat', 'Softer, and it gets better.',
    'Oxford cloth with a button-down collar and a box pleat. Wears in rather than out — the one you reach for on a Friday.',
    2600, [['Blue', '#5d7c9b'], ['Pale blue', '#a9c1d6'], ['White', '#f2f2ee']],
    [['House style', 2600], ['Contrast collar', 2900]], 'CT-OXFORD'],
  ['checked-shirt', 'shirts', 'The checked shirt', '/products/shirt-03.jpg',
    'Small check · soft collar', 'For weekends and winter.',
    'A small brushed check, softened by a wash. Cut loose through the body, matching check across the placket.',
    2800, [['Grey check', '#7d7f79'], ['Navy check', '#33465e'], ['Rust check', '#7e5236']],
    [['House style', 2800], ['Slim cut', 2900]], 'CT-CHECK']
];

// [code, name, colour, hex, composition, price/yard, yards, reorder]
const FABRICS = [
  ['WL-NAVY', 'Super 120s worsted', 'Navy', '#1d2d4d', '100% wool', 1800, 46, 12],
  ['WL-CHAR', 'Super 120s worsted', 'Charcoal', '#3a3d42', '100% wool', 1750, 38, 12],
  ['WL-BLACK', 'Fine twill', 'Black', '#15171a', '100% wool', 1900, 24, 10],
  ['WL-GREY', 'Wool–linen', 'Light grey', '#a8a9a3', '55% wool, 45% linen', 1600, 21, 8],
  ['HS-NAVY', 'Hopsack', 'Navy', '#1d2d4d', 'Wool blend', 1400, 52, 12],
  ['TW-HERR', 'Herringbone tweed', 'Grey', '#6f6f6a', '80% wool, 20% poly', 1650, 17, 8],
  ['CT-BEIGE', 'Cotton twill', 'Beige', '#b9a887', '100% cotton', 700, 60, 15],
  ['CT-WHITE', 'Two-ply poplin', 'White', '#f2f2ee', '100% cotton', 650, 74, 20],
  ['CT-OXFORD', 'Oxford cloth', 'Blue', '#5d7c9b', '100% cotton', 720, 33, 15],
  ['CT-CHECK', 'Brushed check', 'Grey', '#7d7f79', '100% cotton', 760, 12, 10],
  ['DR-ASH', 'Cotton drill', 'Ash blue', '#7e94a8', 'Poly-cotton', 480, 88, 25]
];

const SCOUT = ['standard-set', 'premium-set', 'complete-set'];

async function main() {
  const client = new Client({ connectionString: url, ssl });
  await client.connect();

  if (reset) {
    await client.query(`drop schema public cascade; create schema public;`);
    console.log('· dropped everything');
  }

  await client.query(fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf8'));
  console.log('· schema ready');

  // Every file in sql/migrations, in name order. Each one is written to be idempotent,
  // so running setup on every deploy is safe — it adds, it never drops or reseeds.
  const migrationsDir = path.join(__dirname, '..', 'sql', 'migrations');
  if (fs.existsSync(migrationsDir)) {
    const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
    for (const file of files) {
      await client.query(fs.readFileSync(path.join(migrationsDir, file), 'utf8'));
      console.log(`· migration ${file}`);
    }
  }

  const { rows: existing } = await client.query('select count(*)::int as n from products');
  if (existing[0].n > 0 && !reset) {
    console.log(`· ${existing[0].n} products already present — leaving catalogue alone`);
  } else {
    for (const [i, [slug, name, tagline, intro]] of CATEGORIES.entries()) {
      await client.query(
        `insert into categories (slug, name, tagline, intro, position) values ($1,$2,$3,$4,$5)
         on conflict (slug) do update set name = excluded.name, tagline = excluded.tagline,
           intro = excluded.intro, position = excluded.position`,
        [slug, name, tagline, intro, i]
      );
    }
    console.log(`· ${CATEGORIES.length} categories`);

    for (const [code, name, colour, hex, comp, price, yards, reorder] of FABRICS) {
      await client.query(
        `insert into fabrics (code, name, colour, colour_hex, composition, price_per_yard, yards_in_stock, reorder_level)
         values ($1,$2,$3,$4,$5,$6,$7,$8)
         on conflict (code) do update set name = excluded.name, colour = excluded.colour,
           colour_hex = excluded.colour_hex, composition = excluded.composition,
           price_per_yard = excluded.price_per_yard`,
        [code, name, colour, hex, comp, price, yards, reorder]
      );
    }
    console.log(`· ${FABRICS.length} fabrics`);

    const { rows: cats } = await client.query('select id, slug from categories');
    const catId = Object.fromEntries(cats.map(c => [c.slug, c.id]));
    const { rows: fabrics } = await client.query('select id, code from fabrics');
    const fabId = Object.fromEntries(fabrics.map(f => [f.code, f.id]));

    for (const [i, p] of PRODUCTS.entries()) {
      const [slug, cat, name, image, spec, summary, description, base, colours, designs, fabric] = p;
      const { rows: [prod] } = await client.query(
        `insert into products (slug, category_id, name, summary, description, image, spec, position)
         values ($1,$2,$3,$4,$5,$6,$7,$8)
         on conflict (slug) do update set name = excluded.name, summary = excluded.summary,
           description = excluded.description, image = excluded.image, spec = excluded.spec,
           position = excluded.position returning id`,
        [slug, catId[cat], name, summary, description, image, spec, i]
      );

      let n = 0;
      for (const [colour, hex] of colours) {
        for (const [design, price] of designs) {
          const sku = `${slug.slice(0, 6).toUpperCase()}-${colour.slice(0, 3).toUpperCase()}-${design.slice(0, 3).toUpperCase()}-${++n}`;
          await client.query(
            `insert into product_variants (product_id, colour, colour_hex, design, fabric_id, price, stock, sku)
             values ($1,$2,$3,$4,$5,$6,$7,$8)
             on conflict (product_id, colour, design) do update set price = excluded.price,
               colour_hex = excluded.colour_hex, fabric_id = excluded.fabric_id`,
            [prod.id, colour, hex, design, fabId[fabric] ?? null, price, 4 + (i % 3), sku]
          );
        }
      }
    }
    console.log(`· ${PRODUCTS.length} products with colour × design variants`);
  }

  // one admin account so the panel is reachable on a fresh database
  const { rows: admins } = await client.query("select count(*)::int as n from users where role = 'admin'");
  if (admins[0].n === 0) {
    const email = process.env.ADMIN_EMAIL || 'admin@tailoring.local';
    const password = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
    await client.query(
      `insert into users (email, password_hash, name, role) values ($1,$2,$3,'admin')
       on conflict (email) do nothing`,
      [email, hashPassword(password), 'Shop owner']
    );
    console.log(`· admin account: ${email} / ${password}   (change this after your first login)`);
  }

  await client.query(
    `insert into settings (key, value) values ('visit_fee', $1)
     on conflict (key) do nothing`,
    [process.env.NEXT_PUBLIC_VISIT_FEE || '150']
  );

  await client.end();
  console.log('done.');
}

main().catch(err => {
  console.error('setup failed:', err.message);
  process.exit(1);
});
