const { Client } = require('pg');
const fs = require('fs');
const taka = n => 'Tk ' + Number(n).toLocaleString('en-US');
(async () => {
  const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  await c.connect();
  const q = async (s, p = []) => (await c.query(s, p)).rows;
  const L = [];
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
  L.push('# The live database, as it stands\n');
  L.push('**Neon Postgres** · host `ep-falling-lab-bcj4e6w9-pooler.c-16.us-east-1.aws.neon.tech` · database `neondb`  ');
  L.push('Read straight from the production database at ' + stamp + '.\n');
  const tables = await q("select table_name from information_schema.tables where table_schema='public' order by table_name");
  const counts = {};
  for (const t of tables) counts[t.table_name] = (await q('select count(*)::int n from ' + t.table_name))[0].n;
  const purpose = { categories:'The four lines of the shop', products:'The styles on the wall', product_variants:'Colour × design, each its own price and stock', fabrics:'Bolts on the shelf, by the yard', users:'Customers and the shop owner', orders:'Placed orders, one row each', order_items:'The pieces inside an order', payments:'Every gateway attempt, with its transaction id', measurements:'Saved sizes, one set per customer', stock_movements:'Every yard in or out, with a reason', settings:'Visit fee and shop-wide switches' };
  L.push('## Tables\n');
  L.push('| Table | Rows | What it holds |');
  L.push('|---|---|---|');
  for (const t of tables) L.push('| ' + t.table_name + ' | ' + counts[t.table_name] + ' | ' + (purpose[t.table_name] || '') + ' |');
  L.push('\nTotal: **' + tables.length + ' tables**, ' + Object.values(counts).reduce((a, b) => a + b, 0) + ' rows.\n');
  L.push('## The four lines\n');
  L.push('| Slug | Name | Tagline |');
  L.push('|---|---|---|');
  for (const r of await q('select slug, name, tagline from categories order by position')) L.push('| `' + r.slug + '` | ' + r.name + ' | ' + (r.tagline || '') + ' |');
  L.push('\n## Styles and their designs\n');
  for (const p of await q('select p.id, p.slug, p.name, c.name cat from products p join categories c on c.id=p.category_id order by c.position, p.position')) {
    const vs = await q('select colour, design, price, stock, sku from product_variants where product_id = $1 order by price', [p.id]);
    L.push('### ' + p.name + '  \n<sub>' + p.cat + ' · /product/' + p.slug + ' · ' + vs.length + ' designs</sub>\n');
    L.push('| Colour | Design | Price | Stock | SKU |');
    L.push('|---|---|---|---|---|');
    for (const v of vs) L.push('| ' + v.colour + ' | ' + v.design + ' | ' + taka(v.price) + ' | ' + v.stock + ' | `' + v.sku + '` |');
    L.push('');
  }
  L.push('## Fabric on the shelf\n');
  L.push('| Code | Cloth | Colour | Per yard | Yards | Reorder at |');
  L.push('|---|---|---|---|---|---|');
  for (const r of await q('select code, name, colour, price_per_yard, yards_in_stock, reorder_level from fabrics order by code'))
    L.push('| `' + r.code + '` | ' + r.name + ' | ' + r.colour + ' | ' + taka(r.price_per_yard) + ' | ' + Number(r.yards_in_stock) + ' | ' + Number(r.reorder_level) + ' |');
  const low = await q('select code, yards_in_stock from fabrics where yards_in_stock <= reorder_level');
  L.push('\n**At or below reorder level:** ' + (low.length ? low.map(r => r.code + ' (' + Number(r.yards_in_stock) + ' yd)').join(', ') : 'none — every bolt is above its reorder point.') + '\n');
  L.push('## People\n');
  L.push('| Email | Name | Role |');
  L.push('|---|---|---|');
  for (const r of await q('select email, name, role from users order by role desc')) L.push('| ' + r.email + ' | ' + (r.name || '—') + ' | ' + r.role + ' |');
  const s = await q('select key, value from settings order by key');
  if (s.length) { L.push('\n## Settings\n| Key | Value |\n|---|---|'); for (const r of s) L.push('| `' + r.key + '` | ' + r.value + ' |'); }
  L.push('\n---\n');
  L.push('Orders, payments, measurements and stock movements are empty because the shop has not taken a real order yet — the first one you place shows up in all four.');
  fs.writeFileSync('/home/user/database-snapshot.md', L.join('\n'));
  console.log('written: ' + L.length + ' lines');
  await c.end();
})().catch(e => { console.error('ERR:', e.message); process.exit(1); });
