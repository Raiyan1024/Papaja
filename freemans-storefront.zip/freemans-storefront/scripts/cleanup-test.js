/**
 * Removes anything left behind by the phase-7 test run (the piece it added, its photo,
 * and the test order). Run from the storefront folder:  node scripts/cleanup-test.js
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

for (const file of ['.env.local', '.env']) {
  const full = path.join(process.cwd(), file);
  if (!fs.existsSync(full)) continue;
  for (const line of fs.readFileSync(full, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

(async () => {
  const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: /sslmode=require/.test(process.env.DATABASE_URL) ? { rejectUnauthorized: false } : false });
  await c.connect();
  const del = async (sql) => (await c.query(sql)).rowCount;
  console.log('variants', await del("delete from product_variants where product_id in (select id from products where name ilike '%test waistcoat%')"));
  console.log('products', await del("delete from products where name ilike '%test waistcoat%'"));
  console.log('photos  ', await del('delete from product_images'));
  console.log('payments', await del('delete from payments'));
  console.log('items   ', await del('delete from order_items'));
  console.log('orders  ', await del('delete from orders'));
  await c.end();
})();
