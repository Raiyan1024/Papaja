/**
 * Catalogue v2 — the richer wall.
 *
 *   node scripts/catalogue-v2.js
 *
 * Safe to run on a live shop and safe to run twice:
 *   · adds the bilingual name column and the per-design image column
 *   · adds the Uniforms line and the scout uniform, using the photographs in public/products
 *   · adds six more blazers, so the blazer page is a proper wall of choices
 *   · gives every existing design its own instance photograph
 * It never deletes a row and never touches orders, prices or stock that already exist.
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

for (const file of ['.env.local', '.env']) {
  const full = path.join(process.cwd(), file);
  if (!fs.existsSync(full)) continue;
  for (const line of fs.readFileSync(full, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set.');
  process.exit(1);
}

const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const CATEGORY_NAMES_BN = {
  suits: 'স্যুট',
  blazers: 'ব্লেজার',
  trousers: 'প্যান্ট',
  shirts: 'শার্ট',
  uniforms: 'ইউনিফর্ম'
};

const UNIFORMS_CATEGORY = {
  slug: 'uniforms',
  name: 'Uniforms',
  tagline: 'Scout, school and club uniforms, cut to each member’s size.',
  intro:
    'Institutions do not come in one size. Send the strength of your troop, your class or your club and we cut every set to the person wearing it — shirt, trousers, neckerchief and belt, or whichever pieces you need.',
  position: 4
};

const BLAZERS = [
  {
    slug: 'brown-check-blazer',
    name: 'The brown houndstooth blazer',
    summary: 'Country check, city shoulders.',
    spec: 'Wool-blend houndstooth · peak lapel · patch pockets',
    description:
      'A check loud enough to carry a plain shirt and quiet enough for an office. Peak lapels keep the shoulder sharp; the patch pockets take it off duty.',
    image: '/products/blazer-check.jpg',
    designs: [
      { design: 'House style', price: 9400, colours: [['Brown check', '#6b5442']] },
      { design: 'Peak lapel', price: 10200, colours: [['Brown check', '#6b5442']] },
      { design: 'Patch pockets', price: 9800, colours: [['Brown check', '#6b5442'], ['Camel check', '#a98a5f']] }
    ]
  },
  {
    slug: 'olive-linen-blazer',
    name: 'The olive linen blazer',
    summary: 'For the eight months that feel like summer.',
    spec: 'Linen-cotton · unstructured · patch pockets',
    description:
      'Unlined through the body and soft in the shoulder, so it moves with you in Dhaka heat. The olive reads as a neutral next to navy trousers, cream, or denim.',
    image: '/products/blazer-olive.jpg',
    designs: [
      { design: 'House style', price: 8600, colours: [['Olive', '#55603f']] },
      { design: 'Unstructured', price: 9200, colours: [['Olive', '#55603f'], ['Stone', '#b9b2a4']] },
      { design: 'Patch pockets', price: 8900, colours: [['Olive', '#55603f']] }
    ]
  },
  {
    slug: 'grey-windowpane-blazer',
    name: 'The grey windowpane blazer',
    summary: 'A check drawn with a ruler, not a brush.',
    spec: 'Super 100s wool · peak lapel · flap pockets',
    description:
      'A single windowpane on mid-grey — the most useful odd jacket a man can own. It reads formal with a tie and easy with an open collar.',
    image: '/products/blazer-windowpane.jpg',
    designs: [
      { design: 'House style', price: 9800, colours: [['Grey check', '#7d7f79']] },
      { design: 'Peak lapel', price: 10600, colours: [['Grey check', '#7d7f79'], ['Navy check', '#33465e']] },
      { design: 'Double-breasted', price: 11200, colours: [['Grey check', '#7d7f79']] }
    ]
  },
  {
    slug: 'burgundy-velvet-jacket',
    name: 'The burgundy velvet jacket',
    summary: 'For the wedding you are not allowed to miss.',
    spec: 'Cotton velvet · shawl collar · satin-lined',
    description:
      'A dinner jacket that does not need a bow tie to be dressed. Shawl collar, covered buttons, and a lining that lets it go on and off over a good shirt.',
    image: '/products/blazer-dinner.jpg',
    designs: [
      { design: 'Shawl collar', price: 13900, colours: [['Burgundy', '#5c2431']] },
      { design: 'Peak lapel', price: 14200, colours: [['Burgundy', '#5c2431'], ['Midnight', '#141c2e']] },
      { design: 'House style', price: 13400, colours: [['Burgundy', '#5c2431']] }
    ]
  },
  {
    slug: 'stone-summer-blazer',
    name: 'The stone summer blazer',
    summary: 'The jacket that goes to Cox’s Bazar with you.',
    spec: 'Cotton-linen · unlined · patch pockets',
    description:
      'Bone buttons, an unlined back and a colour that throws light back at you. Pairs with the cotton chino and nothing else needed.',
    image: '/products/blazer-stone.jpg',
    designs: [
      { design: 'House style', price: 7900, colours: [['Stone', '#b9b2a4']] },
      { design: 'Unlined summer cut', price: 8400, colours: [['Stone', '#b9b2a4'], ['Sand', '#cbb894']] },
      { design: 'Patch pockets', price: 8200, colours: [['Stone', '#b9b2a4']] }
    ]
  },
  {
    slug: 'charcoal-double-breasted-blazer',
    name: 'The charcoal double-breasted blazer',
    summary: 'Six buttons, no tie required.',
    spec: 'Super 120s worsted · wide peak lapel · six buttons',
    description:
      'The most formal thing you can wear without a suit. Wide peak lapels hold the chest; the charcoal takes a white shirt and a pocket square and asks for nothing else.',
    image: '/products/blazer-doublebreasted.jpg',
    designs: [
      { design: 'Double-breasted', price: 11800, colours: [['Charcoal', '#3a3d42']] },
      { design: 'Peak lapel', price: 11400, colours: [['Charcoal', '#3a3d42'], ['Navy', '#1d2d4d']] },
      { design: 'House style', price: 10900, colours: [['Charcoal', '#3a3d42']] }
    ]
  }
];

const SCOUT = {
  slug: 'scout-uniform',
  name: 'The scout uniform',
  summary: 'Shirt, trousers, neckerchief and belt — cut for each scout.',
  spec: 'Cotton drill · short sleeve · embroidered badges',
  description:
    'The full set as it is worn: blue short-sleeve shirt with epaulettes and badge tabs, navy trousers with a sharp crease, the red neckerchief and the leather belt. Brought in one at a time or as a whole troop — every piece is cut to that scout’s own measurements.',
  image: '/products/scout-set.jpg',
  designs: [
    { design: 'Full set — shirt, trousers, neckerchief, belt', price: 2850, image: '/products/scout-set.jpg', colours: [['Scout blue', '#4f8fd0'], ['Scout navy', '#1f3560']] },
    { design: 'Shirt only', price: 1150, image: '/products/scout-worn.jpg', colours: [['Scout blue', '#4f8fd0'], ['Scout navy', '#1f3560']] },
    { design: 'Trousers only', price: 1050, image: '/products/scout-worn.jpg', colours: [['Scout blue', '#4f8fd0'], ['Scout navy', '#1f3560']] },
    { design: 'Neckerchief & belt', price: 450, image: '/products/scout-set.jpg', colours: [['Scout blue', '#4f8fd0'], ['Scout navy', '#1f3560']] }
  ]
};

(async () => {
  const client = new Client({ connectionString: url, ssl: { rejectUnauthorized: false } });
  await client.connect();
  const q = (text, params = []) => client.query(text, params);
  const log = (...a) => console.log('·', ...a);

  // 1. columns -------------------------------------------------------------
  await q('alter table categories add column if not exists name_bn text');
  await q('alter table product_variants add column if not exists image text');
  log('columns ready (categories.name_bn, product_variants.image)');

  for (const [s, nameBn] of Object.entries(CATEGORY_NAMES_BN)) {
    await q('update categories set name_bn = $2 where slug = $1', [s, nameBn]);
  }

  // 2. the uniforms line ---------------------------------------------------
  const uniformExists = (await q('select id from categories where slug = $1', ['uniforms'])).rows[0];
  if (!uniformExists) {
    await q(
      `insert into categories (slug, name, tagline, intro, position) values ($1,$2,$3,$4,$5)`,
      [UNIFORMS_CATEGORY.slug, UNIFORMS_CATEGORY.name, UNIFORMS_CATEGORY.tagline, UNIFORMS_CATEGORY.intro, UNIFORMS_CATEGORY.position]
    );
    log('category added: Uniforms');
  } else {
    await q('update categories set name = $2, tagline = $3, intro = $4 where slug = $1',
      [UNIFORMS_CATEGORY.slug, UNIFORMS_CATEGORY.name, UNIFORMS_CATEGORY.tagline, UNIFORMS_CATEGORY.intro]);
  }

  const categories = Object.fromEntries((await q('select id, slug from categories')).rows.map(r => [r.slug, r.id]));

  // 3. fabric lookup for variant links ------------------------------------
  const fabrics = (await q('select id, code from fabrics')).rows;
  const fabricByCode = Object.fromEntries(fabrics.map(f => [f.code, f.id]));

  async function addProduct(product, categorySlug, fabricCode) {
    const existing = (await q('select id from products where slug = $1', [product.slug])).rows[0];

    if (existing) {
      // top up any design/colour combination that is missing, never touching the ones that exist
      let topped = 0;
      let pos = 100;
      for (const design of product.designs) {
        for (const [colour, hex] of design.colours) {
          pos += 1;
          const sku = `${slug(product.slug).slice(0, 8).toUpperCase()}-${slug(colour).slice(0, 3).toUpperCase()}-${slug(design.design).slice(0, 3).toUpperCase()}-${pos}`;
          const res = await q(
            `insert into product_variants (product_id, colour, colour_hex, design, fabric_id, price, stock, sku, image, active)
             values ($1,$2,$3,$4,$5,$6,$7,$8,$9,true)
             on conflict (product_id, colour, design) do nothing`,
            [existing.id, colour, hex, design.design, fabricCode ? fabricByCode[fabricCode] || null : null, design.price, 12, sku, design.image || product.image]
          );
          topped += res.rowCount;
        }
      }
      return { id: existing.id, added: false, topped };
    }

    const rows = await q(
      `insert into products (slug, category_id, name, summary, description, image, spec, position, active)
       values ($1,$2,$3,$4,$5,$6,$7,(select coalesce(max(position),0)+1 from products where category_id = $2), true)
       returning id`,
      [product.slug, categories[categorySlug], product.name, product.summary, product.description, product.image, product.spec]
    );
    const productId = rows.rows[0].id;

    let position = 0;
    for (const design of product.designs) {
      for (const [colour, hex] of design.colours) {
        position += 1;
        const sku = `${slug(product.slug).slice(0, 8).toUpperCase()}-${slug(colour).slice(0, 3).toUpperCase()}-${slug(design.design).slice(0, 3).toUpperCase()}-${position}`;
        await q(
          `insert into product_variants (product_id, colour, colour_hex, design, fabric_id, price, stock, sku, image, active)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9,true)
           on conflict (product_id, colour, design) do nothing`,
          [productId, colour, hex, design.design, fabricCode ? fabricByCode[fabricCode] || null : null, design.price, 12, sku, design.image || product.image]
        );
      }
    }
    return { id: productId, added: true, variants: position };
  }

  // 4. the blazer wall -----------------------------------------------------
  const blazerFabric = { 'Brown check': 'CT-CHECK', 'Grey check': 'WL-GREY', 'Navy check': 'WL-NAVY', 'Charcoal': 'WL-CHAR', 'Stone': 'CT-BEIGE', 'Sand': 'CT-BEIGE', 'Olive': 'WL-GREY', 'Burgundy': 'WL-CHAR', 'Midnight': 'WL-BLACK' };
  let addedBlazers = 0;
  for (const blazer of BLAZERS) {
    const r = await addProduct(blazer, 'blazers', blazerFabric[blazer.designs[0].colours[0][0]] || 'WL-NAVY');
    if (r.added) { addedBlazers += 1; log(`blazer added: ${blazer.name} (${r.variants} designs)`); }
  }

  // 5. the scout uniform ---------------------------------------------------
  const scout = await addProduct(SCOUT, 'uniforms', 'DR-ASH');
  if (scout.added) log(`uniform added: ${SCOUT.name} (${scout.variants} designs)`);
  if (scout.topped) log(`uniform topped up with ${scout.topped} missing colour/design rows`);
  const retired = await q(
    `delete from product_variants v using products p
      where v.product_id = p.id and p.slug = 'scout-uniform' and v.colour = 'Scout red'`
  );
  if (retired.rowCount) log(`retired ${retired.rowCount} stray colour row on the uniform`);

  // 6. an instance photograph on every design ------------------------------
  const filled = await q(
    `update product_variants v
        set image = p.image
       from products p
      where p.id = v.product_id and (v.image is null or v.image = '') and p.image is not null`
  );
  log(`design instances filled on ${filled.rowCount} variants`);

  const summary = await q(
    `select c.name, count(distinct p.id)::int styles, count(v.id)::int designs
       from categories c left join products p on p.category_id = c.id and p.active
       left join product_variants v on v.product_id = p.id and v.active
      group by c.name, c.position order by c.position`
  );
  console.log('\nThe wall now reads:');
  for (const row of summary.rows) console.log(`   ${row.name.padEnd(10)} ${String(row.styles).padStart(2)} styles, ${String(row.designs).padStart(3)} designs`);
  log(`blazers added this run: ${addedBlazers}`);

  await client.end();
  console.log('done.');
})().catch(error => {
  console.error('failed:', error.message);
  process.exit(1);
});
