/**
 * Sets the shop owner's password. The hash matches lib/auth.js exactly (scrypt).
 *
 *   node scripts/set-admin-password.js 'a-long-new-password'
 *   node scripts/set-admin-password.js 'a-long-new-password' --email owner@shop.com
 *
 * Run it against the live database (DATABASE_URL in the environment). Nothing is printed
 * to the website, and the password is never stored in plain text anywhere.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

for (const file of ['.env.local', '.env']) {
  const full = path.join(process.cwd(), file);
  if (!fs.existsSync(full)) continue;
  for (const line of fs.readFileSync(full, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const args = process.argv.slice(2);
const password = args.find(a => !a.startsWith('--'));
const emailFlag = args.indexOf('--email');
const email = (emailFlag >= 0 ? args[emailFlag + 1] : process.env.ADMIN_EMAIL) || 'admin@tailoring.local';

if (!password) {
  console.error("Usage: node scripts/set-admin-password.js 'new-password' [--email you@shop.com]");
  process.exit(1);
}
if (password.length < 12) {
  console.error('Use at least 12 characters — this login controls every order in the shop.');
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is not set.');
  process.exit(1);
}

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(plain, salt, 64).toString('hex');
  return `scrypt:${salt}:${hash}`;
}

const ssl = /sslmode=(require|verify)/.test(process.env.DATABASE_URL)
  ? { rejectUnauthorized: false }
  : false;

(async () => {
  const client = new Client({ connectionString: process.env.DATABASE_URL, ssl });
  await client.connect();
  const { rows } = await client.query(
    `insert into users (email, password_hash, name, role)
     values ($1,$2,'Shop owner','admin')
     on conflict (email) do update set password_hash = excluded.password_hash, role = 'admin'
     returning id, email`,
    [email, hashPassword(password)]
  );
  await client.end();
  console.log(`· password set for ${rows[0].email} (user ${rows[0].id})`);
  console.log('· sign in at /admin/login, then rotate SESSION_SECRET so old sessions die.');
})().catch(err => {
  console.error('failed:', err.message);
  process.exit(1);
});
