-- 002 — manual bKash / Nagad payments.
--
-- There is no free bKash *API*: their payment API needs an approved merchant account.
-- What needs no approval, no merchant account and no monthly fee is Send Money to the
-- shop's own number, with the customer pasting the TrxID and the shop verifying it here.
-- These columns are what that flow needs. Idempotent — safe on every deploy.

alter table orders add column if not exists payment_method text not null default 'bkash';

alter table payments add column if not exists method         text;
alter table payments add column if not exists sender_number  text;
alter table payments add column if not exists gateway_ref    text;   -- the TrxID the customer pasted
alter table payments add column if not exists submitted_at   timestamptz;
alter table payments add column if not exists checked_at     timestamptz;
alter table payments add column if not exists checked_by     text;
alter table payments add column if not exists note           text;

alter table payments drop constraint if exists payments_status_check;
alter table payments add constraint payments_status_check
  check (status in ('initiated','submitted','paid','on_hold','failed','cancelled','rejected'));

-- One TrxID belongs to one payment: the same screenshot cannot release two orders.
create unique index if not exists payments_gateway_ref_key
  on payments (lower(gateway_ref)) where gateway_ref is not null;

create index if not exists payments_status_idx on payments(status, submitted_at desc);

-- The shop's own receiving numbers, so the admin panel and the payment page agree.
insert into settings (key, value) values ('bkash_number', '') on conflict (key) do nothing;
insert into settings (key, value) values ('nagad_number', '') on conflict (key) do nothing;
