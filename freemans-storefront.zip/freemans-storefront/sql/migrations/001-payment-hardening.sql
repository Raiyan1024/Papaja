-- 001 — payment hardening + outside-Dhaka visit fee + part payments.
-- Idempotent: safe to run on every deploy, never drops or reseeds anything.

-- 1. Which visit fee applies: ৳150 inside Dhaka, ৳400 outside (video 1, 3:27).
alter table orders add column if not exists delivery_zone text not null default 'inside_dhaka';
alter table orders drop constraint if exists orders_delivery_zone_check;
alter table orders add constraint orders_delivery_zone_check
  check (delivery_zone in ('inside_dhaka','outside_dhaka'));

-- 2. Part payments. An "advance" order pays the visit fee and still owes the garment;
--    marking it fully 'paid' used to lose the outstanding balance altogether.
alter table orders add column if not exists amount_paid integer not null default 0;
alter table orders drop constraint if exists orders_payment_status_check;
alter table orders add constraint orders_payment_status_check
  check (payment_status in ('unpaid','partial','paid','refunded','failed'));

-- 3. A gateway risk hold is its own state, not a failure.
alter table payments add column if not exists verified_at timestamptz;
alter table payments drop constraint if exists payments_status_check;
-- The full list, including the manual-payment states added in 002, so re-running this
-- migration on a database that already has 'submitted' or 'rejected' rows cannot fail.
alter table payments add constraint payments_status_check
  check (status in ('initiated','submitted','paid','on_hold','failed','cancelled','rejected'));

-- 4. Backfill what we can prove from the payment rows already recorded.
update orders o
   set amount_paid = coalesce(p.paid, 0),
       amount_due  = greatest(0, o.total - coalesce(p.paid, 0)),
       payment_status = case
                          when coalesce(p.paid, 0) >= o.total and o.total > 0 then 'paid'
                          when coalesce(p.paid, 0) > 0 then 'partial'
                          else o.payment_status
                        end
  from (select order_id, sum(amount)::int as paid from payments where status = 'paid' group by order_id) p
 where p.order_id = o.id
   and o.payment_status in ('paid','unpaid');

-- 5. The old settings row only knew one visit fee.
insert into settings (key, value) values ('visit_fee_inside', '150')
  on conflict (key) do nothing;
insert into settings (key, value) values ('visit_fee_outside', '400')
  on conflict (key) do nothing;
insert into settings (key, value) values ('refund_rate', '0.60')
  on conflict (key) do nothing;
