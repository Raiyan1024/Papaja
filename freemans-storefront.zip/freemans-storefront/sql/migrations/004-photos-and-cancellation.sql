-- 004 — photographs uploaded from the admin panel, and the customer's cancellation request.
--
-- Photos are kept in the database itself (bytea) rather than on the container's disk:
-- a redeploy wipes the disk, but the database is the one thing that survives every deploy.
-- The app serves them back through /api/img/<key>.

create table if not exists product_images (
  id          serial primary key,
  key         text not null unique,
  product_id  integer references products(id) on delete set null,
  variant_id  integer references product_variants(id) on delete set null,
  mime        text not null default 'image/jpeg',
  bytes       bytea not null,
  width       integer,
  height      integer,
  label       text,
  created_at  timestamptz not null default now()
);
create index if not exists product_images_product_idx on product_images(product_id);
create index if not exists product_images_variant_idx on product_images(variant_id);

-- A customer can ask to cancel. The shop accepts or declines, and the answer stays on the
-- order page for good, so nobody has to guess whether it was cancelled or not.
alter table orders add column if not exists cancel_state text;
alter table orders add column if not exists cancel_reason text;
alter table orders add column if not exists cancel_note text;
alter table orders add column if not exists cancel_requested_at timestamptz;
alter table orders add column if not exists cancel_decided_at timestamptz;

alter table orders drop constraint if exists orders_cancel_state_check;
alter table orders add constraint orders_cancel_state_check
  check (cancel_state is null or cancel_state in ('requested', 'accepted', 'rejected'));
