-- 005 — a real gallery per piece: the front, the back, the pocket, the cuff, the lining.
--
-- The shop asked for a bigger catalogue with photographs taken from more than one angle,
-- and a picture for each colour rather than one photograph cropped five ways. Those extra
-- photographs live here, in order, with the word that is printed under them.

create table if not exists product_gallery (
  id          serial primary key,
  product_id  integer not null references products(id) on delete cascade,
  variant_id  integer references product_variants(id) on delete cascade,
  url         text not null,
  label       text not null default 'Front',
  position    integer not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists product_gallery_product_idx on product_gallery(product_id, position);

-- A photograph may belong to one colour/design as well as to the piece.
alter table product_gallery add column if not exists variant_id integer references product_variants(id) on delete cascade;
