-- 003 — automatic TrxID checking.
--
-- Nobody can ask bKash for a TrxID without a merchant API, but the shop's own phone
-- already receives "You have received Tk 150.00 … TrxID 9F7A2KD10X" the moment the money
-- lands. That message is enough to release an order without anybody clicking.
--
-- This table is the inbox for forwarded messages, and the token is what the phone quotes
-- when it forwards. Both are safe to re-run.

create table if not exists payment_inbox (
  id            serial primary key,
  source        text not null default 'sms',          -- sms | statement | manual
  trx_id        text,
  amount        integer,
  sender_number text,
  paid_at       timestamptz,
  raw           text,
  matched_payment_id integer references payments(id) on delete set null,
  matched       boolean not null default false,
  note          text,
  created_at    timestamptz not null default now()
);

create index if not exists payment_inbox_trx_idx on payment_inbox (lower(trx_id));
create index if not exists payment_inbox_created_idx on payment_inbox (created_at desc);

-- One row of settings holds the forwarding token; the admin page shows it and can rotate it.
-- gen_random_uuid() is core Postgres, so this needs no extension beside it.
insert into settings (key, value)
values ('payment_sms_token', replace(gen_random_uuid()::text, '-', ''))
on conflict (key) do nothing;

-- How the payment was cleared, for the audit trail the shopkeeper may want later.
alter table payments add column if not exists verified_by text;   -- auto:sms | auto:statement | admin
