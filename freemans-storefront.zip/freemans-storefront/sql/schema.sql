-- Tailoring house — Postgres schema
-- Run with: npm run db:setup   (idempotent: creates, then seeds if empty)

create table if not exists users (
  id            serial primary key,
  email         text not null unique,
  password_hash text not null,
  name          text,
  phone         text,
  role          text not null default 'customer' check (role in ('customer','admin')),
  created_at    timestamptz not null default now()
);

create table if not exists measurements (
  id         serial primary key,
  user_id    integer not null references users(id) on delete cascade,
  label      text not null default 'Default',
  chest      numeric(5,1),
  waist      numeric(5,1),
  hip        numeric(5,1),
  shoulder   numeric(5,1),
  sleeve     numeric(5,1),
  length     numeric(5,1),
  inseam     numeric(5,1),
  collar     numeric(5,1),
  notes      text,
  updated_at timestamptz not null default now()
);
create index if not exists measurements_user_idx on measurements(user_id);

-- bilingual name column, added by scripts/catalogue-v2.js on existing databases
create table if not exists categories (
  id       serial primary key,
  slug     text not null unique,
  name     text not null,
  tagline  text,
  intro    text,
  position integer not null default 0
);

create table if not exists fabrics (
  id             serial primary key,
  code           text not null unique,
  name           text not null,
  colour         text not null,
  colour_hex     text not null default '#28333e',
  composition    text,
  price_per_yard integer not null check (price_per_yard >= 0),
  yards_in_stock numeric(8,2) not null default 0,
  reorder_level  numeric(8,2) not null default 0,
  active         boolean not null default true,
  updated_at     timestamptz not null default now()
);

create table if not exists products (
  id          serial primary key,
  slug        text not null unique,
  category_id integer not null references categories(id) on delete restrict,
  name        text not null,
  summary     text,
  description text,
  image       text,
  spec        text,
  active      boolean not null default true,
  position    integer not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists products_category_idx on products(category_id);

-- One row per buyable colour + design combination. This is where the price lives,
-- so the admin panel can change a price or a stock count per variant.
create table if not exists product_variants (
  id         serial primary key,
  product_id integer not null references products(id) on delete cascade,
  colour     text not null,
  colour_hex text not null default '#28333e',
  design     text not null default 'House style',
  fabric_id  integer references fabrics(id) on delete set null,
  price      integer not null check (price >= 0),
  stock      integer not null default 0 check (stock >= 0),
  image      text,
  sku        text,
  active     boolean not null default true,
  unique (product_id, colour, design)
);
create index if not exists variants_product_idx on product_variants(product_id);

create table if not exists orders (
  id               serial primary key,
  code             text not null unique,
  user_id          integer references users(id) on delete set null,
  status           text not null default 'placed'
                     check (status in ('placed','confirmed','in_production','ready','delivered','cancelled')),
  payment_option   text not null default 'advance' check (payment_option in ('advance','full')),
  payment_status   text not null default 'unpaid' check (payment_status in ('unpaid','partial','paid','refunded','failed')),
  customer_name    text not null,
  customer_phone   text not null,
  customer_email   text,
  area             text,
  delivery_zone    text not null default 'inside_dhaka' check (delivery_zone in ('inside_dhaka','outside_dhaka')),
  address          text,
  measurement_mode text not null default 'home_visit'
                     check (measurement_mode in ('home_visit','own_size','saved','discuss')),
  measurement_note text,
  wants_discussion boolean not null default false,
  discussion_topic text,
  cloth_choice     text,
  notes            text,
  subtotal         integer not null default 0,
  visit_fee        integer not null default 0,
  total            integer not null default 0,
  amount_due       integer not null default 0,
  amount_paid      integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists orders_user_idx on orders(user_id);
create index if not exists orders_status_idx on orders(status);

create table if not exists order_items (
  id            serial primary key,
  order_id      integer not null references orders(id) on delete cascade,
  product_id    integer references products(id) on delete set null,
  variant_id    integer references product_variants(id) on delete set null,
  title         text not null,
  colour        text,
  design        text,
  qty           integer not null default 1 check (qty > 0),
  unit_price    integer not null default 0,
  custom_brief  text,
  created_at    timestamptz not null default now()
);
create index if not exists order_items_order_idx on order_items(order_id);

create table if not exists payments (
  id         serial primary key,
  order_id   integer not null references orders(id) on delete cascade,
  provider   text not null default 'bkash_manual',
  tran_id    text not null unique,
  amount     integer not null,
  status     text not null default 'initiated'
               check (status in ('initiated','paid','on_hold','failed','cancelled')),
  val_id     text,
  payload    jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists payments_order_idx on payments(order_id);

-- Every change to fabric or variant stock is written here, so stock is auditable.
create table if not exists stock_movements (
  id         serial primary key,
  fabric_id  integer references fabrics(id) on delete cascade,
  variant_id integer references product_variants(id) on delete cascade,
  delta      numeric(10,2) not null,
  reason     text not null default 'adjustment',
  order_id   integer references orders(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists settings (
  key   text primary key,
  value text
);
